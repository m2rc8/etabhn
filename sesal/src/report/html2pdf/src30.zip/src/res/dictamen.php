<style type="text/Css">
<!--
#body{
	font-family:Arial, Helvetica, sans-serif;
	font-size:12px;
	font-weight:400;
	color:#000;
	line-height:25px;
}
.small_font{
	font-size:8px;
	color:#666;
}
.bg_img{
	background-color:#F5ECCE;
	border-radius:5px;
	height:20px;
}
.linea{
	border-width:1px;
	border-bottom:solid;
	border-color:#666;
}
.txt_title{
	font-size:16px;
	font-weight:bold;
}
.txt_titleheader{
	font-size:13px;
	font-weight:bold;
	color:#333;
}
.txt_titleheader_cotenido{
	font-size:10px;
}
-->
</style>
<page backtop="30mm" backimg="./res/img/logos/fondo.jpg" backbottom="30mm" backleft="6mm" backright="6mm" pagegroup="new" style="line-height:20px; text-align:justify; font-size:13px;">
<page_header>
<table align="center" cellpadding="3" cellspacing="3" style="border-color:#CCC; border-bottom-width:3px; border-style:solid">
  <tr>
    <td><img src="./res/img/logos/mp.jpg" /></td>
    <td bgcolor="#CCC"></td>
    <td align="center" width="380" style="font-size:16px;">
    DIRECCIÓN DE MEDICINA FORENSE <br />
	DEPARTAMENTO DE PATOLOGÍA FORENSE<br />
	<b>DICTAMEN<?php echo " ".$_REQUEST["tipo_dictamen"];?></b>
    </td>
    <td bgcolor="#CCC"></td>
    <td align="right" valign="bottom"><?php if(isset($_REQUEST["sregistro"])){echo $_REQUEST["sregistro"];}?></td>
  </tr>
</table>
</page_header>
<page_footer>
  <table align="center" cellpadding="3" cellspacing="3" border="0">
  <tr>
  <td colspan="5" style="font-size:12px;">El presente dictamen se entrega a la entidad solicitante exonerando al departamento de cualquier responsabilidad por la reproducción total o parcial del mismo.</td>
  </tr>
  <tr>
  <td colspan="5" bgcolor="#CCC"></td>
  </tr>
  <tr>
  <td colspan="5" style="font-size:12px;"><!--Este documento debe tener x líneas de contenido (x caracteres)--></td>
  </tr>
  <tr>
  <td colspan="5" bgcolor="#CCC"></td>
  </tr>
  <tr>
    <td align="center" valign="top" style="font-size:12px;"><b>FECHA  DE EMISIÓN<br />
    <?php echo date("Y.m.d");?></b>
    </td>
    <td bgcolor="#CCC"></td>
    <td align="right" width="480" style=" font-size:12px;">
    <b>DIRECCIÓN DE MEDICINA FORENSE <br />
	DEPARTAMENTO DE PATOLOGÍA FORENSE<br />
	Edificio Santa Ana, Contiguo al Hospital Escuela. Tegucigalpa M.D.C.</b>
    </td>
    <td bgcolor="#CCC"></td>
    <td align="center" valign="top" style="font-size:12px;"><b>Página<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[[page_cu]] de [[page_nb]]</b></td>
  </tr>
</table>
</page_footer>
  <table width="100%" border="0" align="center" cellpadding="10" cellspacing="10">
    <tr style="text-transform:uppercase">
      <td valign="top"><div style="width:20px">1</div></td>
      <td><b><?php if(isset($_REQUEST["slugar"])){echo $_REQUEST["slugar"].", ";}
			if(isset($_REQUEST["sfecharecibida"])){
				$date=explode("/",$_REQUEST["sfecharecibida"]);
				echo " ".$date[0]." de ";
                                switch ($date[1]) {
                                    case 1:
                                        echo "Enero";
                                        break;
                                    case 2:
                                        echo "Febrero";
                                        break;
                                    case 3:
                                        echo "Marzo";
                                        break;
                                    case 4:
                                        echo "Abril";
                                        break;
                                    case 5:
                                        echo "Mayo";
                                        break;
                                    case 6:
                                        echo "Junio";
                                        break;
                                    case 7:
                                        echo "Julio";
                                        break;
                                    case 8:
                                        echo "Agosto";
                                        break;
                                    case 9:
                                        echo "Septiembre";
                                        break;
                                    case 10:
                                        echo "Octubre";
                                        break;
                                    case 11:
                                        echo "Noviembre";
                                        break;
                                    case 12:
                                        echo "Diciembre";
                                        break;
                                }
                                echo " de ".$date[2];
				
		}?>
	</b></td>
    </tr>
    <tr style="text-transform:uppercase">
      <td valign="top">2</td>
      <td><b><?php if(isset($_REQUEST["stituloDestinatario"])){echo $_REQUEST["stituloDestinatario"];}?></b></td>
    </tr>
    <tr style="text-transform:uppercase">
      <td valign="top">3</td>
      <td><b><?php if(isset($_REQUEST["snombreDestinatario"])){echo $_REQUEST["snombreDestinatario"];}?></b></td>
    </tr>
    <tr style="text-transform:uppercase">
      <td valign="top">4</td>
      <td><b><?php if(isset($_REQUEST["scargo"])){echo $_REQUEST["scargo"];}?></b></td>
    </tr>
    <tr style="text-transform:uppercase">
      <td valign="top">5</td>
      <td><b><?php if(isset($_REQUEST["sdependenciaDestinatario"])){echo $_REQUEST["sdependenciaDestinatario"];}
            if(isset($_REQUEST["sunidad_dependencia"]) && $_REQUEST["sunidad_dependencia"] != ""){echo ", ".$_REQUEST["sunidad_dependencia"];}
      ?></b></td>
    </tr>
    <tr style="text-transform:uppercase">
      <td valign="top">6</td>
      <td><b><?php if(isset($_REQUEST["sciudad"])){echo $_REQUEST["sciudad"].", ";}?><?php if(isset($_REQUEST["sdepartamento"])){echo $_REQUEST["sdepartamento"];}?></b></td>
    </tr>
    <tr>
        <td valign="top">7<br/>8</td>
      <td><div style="width:650px">En atención a la solicitud recibida, el/la <b>doctor/a <?php if(isset($_REQUEST["sperito"])){echo $_REQUEST["sperito"];}?></b> del  departamento de Patología Forense emite el siguiente dictamen basado en la evolución  realizada y el estudio solicitado.</div></td>
    </tr>
    <tr>
    <td valign="middle">9</td>
    <td class="txt_title">1. Datos  generales</td>
    </tr>
  <tr>
    <td valign="top">10</td>
    <td>Registro de departamento:
      <?php if(isset($_REQUEST["sregistro"])){echo $_REQUEST["sregistro"];}?></td>
    </tr>
  <tr>
    <td valign="top">11</td>
    <td>Código del Solicitante:
      <?php if(isset($_REQUEST["scodigoSolicitante"])){echo $_REQUEST["scodigoSolicitante"];}?></td>
    </tr>
  <tr>
    <td valign="top">12</td>
    <td>Causa o Delito:
      <?php if(isset($_REQUEST["scausa"])){echo $_REQUEST["scausa"];}?></td>
    </tr>
  <tr>
    <td valign="top">13</td>
    <td>Dependencia Solicitante:
      <?php if(isset($_REQUEST["sdependenciaSolicitante"])){echo $_REQUEST["sdependenciaSolicitante"];}?></td>
    </tr>
  <tr>
    <td valign="top">
        <?php ?>
        14</td>
    <td><div style="width:650px; line-height: 20px;">Ofendido(s):
      <?php if(isset($_REQUEST["sofendidos"])){echo $_REQUEST["sofendidos"];}?></div></td>
    </tr>
  <tr>
    <td valign="top">15</td>
    <td><div style="width:650px; line-height: 20px;">Imputado(s):
      <?php if(isset($_REQUEST["simputados"])){echo $_REQUEST["simputados"];}?></div></td>
    </tr>
  <tr>
    <td valign="top">16</td>
    <td>Solicitud recibida en fecha:
      <?php if(isset($_REQUEST["sfecharecibida"])){echo $_REQUEST["sfecharecibida"];}?></td>
    </tr>
  <tr>
    <td valign="top">17</td>
    <td>Evaluación finalizada en fecha:
      <?php if(isset($_REQUEST["sfechaevafin"])){echo $_REQUEST["sfechaevafin"];}?><br /></td>
    </tr>
  <tr>
    <td valign="middle">18</td>
    <td class="txt_title">2. Registros referentes al cadáver</td>
  </tr>
  <tr>
    <td valign="top">19</td>
    <td>Nombre:
    <?php if(isset($_REQUEST["nombreFallecido"])){echo $_REQUEST["nombreFallecido"];}?></td>
  </tr>
  <tr>
    <td valign="top">20</td>
    <td>
        <?php 
         switch ($_REQUEST["dictamen"]) {
                                    case 1:
                                        echo "Exhumación Nº:";
                                        break;
                                    case 2:
                                        echo "Inspección Nº:";
                                        break;
                                    case 3:
                                        echo "Autopsia Nº:";
                                        break;
         }
        ?>
      <?php if(isset($_REQUEST["sregistro"])){echo $_REQUEST["sregistro"];}?>
    </td>
  </tr>
  <tr>
    <td valign="top">21</td>
    <td>Fecha de muerte:
    <?php if(isset($_REQUEST["fechaMuerte"])){echo $_REQUEST["fechaMuerte"];}?></td>
  </tr>
  <tr>
    <td valign="top">22</td>
    <td>Fecha y hora de exhumacion:
    <?php if(isset($_REQUEST["fechaExhumacion"])){echo $_REQUEST["fechaExhumacion"];} if(isset($_REQUEST["horaExhumacion"])){echo " ".$_REQUEST["horaExhumacion"];}?>
<br /></td>
  </tr>
  <tr>
    <td valign="top"><?php $i=23;
    $total = strlen($_REQUEST["historiaMedicoLegal"]);
    //echo $total;
    $lineas = $total/100;
    $decimal=explode(".",$lineas);
    $lineas = (integer)$lineas;
    $decimal_format="0.".$decimal[1];
    $decimal_format=(double)$decimal_format;
    //echo $decimal_format;
    if($decimal_format != 0 && $decimal_format <= 0.5){
       // echo$lineas;
        //$lineas=$lineas+1;;
        // echo$lineas;
    }
    if($lineas==0){
        echo $i."<br />";
        $i++;
    }
    $centinela = 0;
    while($centinela <= $lineas){
        echo $i."<br />";
        $i++;
        $centinela++;
    }
    ?></td>
    <td><div class="txt_title">3. Historia  médico legal</div>
     <div style="width:650px;"><?php if(isset($_REQUEST["historiaMedicoLegal"])){echo $_REQUEST["historiaMedicoLegal"];}?><br /></div>
    </td>
    </tr>
  <tr>
    <td valign="top"><?php echo $i;?></td>
    <td class="txt_title">4. Resultados</td>
    </tr>
  <tr>
      <td valign="top">
        <?php $i++;
    $total = strlen($_REQUEST["dic_ee"]);
    //echo $total;
    $lineas = $total/100;
    $decimal=explode(".",$lineas);
    $lineas = (integer)$lineas;
    $decimal_format="0.".$decimal[1];
    $decimal_format=(double)$decimal_format;
    //echo $decimal_format;
    if($decimal_format != 0 && $decimal_format <= 0.5){
       // echo$lineas;
        //$lineas=$lineas+1;;
        // echo$lineas;
    }
    if($lineas==0){
        echo $i."<br />";
        $i++;
    }
    $centinela = 0;
    while($centinela <= $lineas){
        echo $i."<br />";
        $i++;
        $centinela++;
    }
    ?>
      </td>
    <td><strong>4.1. Examen externo</strong><br />
   <div style="width:650px"><?php if(isset($_REQUEST["dic_ee"])){
       if($_REQUEST["dic_ee"] != ""){
            echo $_REQUEST["dic_ee"];
       }else{
           echo "NO HAY DESCRIPCION";
       }
   }?></div>
    </td>
    </tr>
  <tr>
      <td valign="top">
           <?php
    $total = strlen($_REQUEST["dic_le"]);
    //echo $total;
    $lineas = $total/100;
    $decimal=explode(".",$lineas);
    $lineas = (integer)$lineas;
    $decimal_format="0.".$decimal[1];
    $decimal_format=(double)$decimal_format;
    //echo $decimal_format;
    if($decimal_format != 0 && $decimal_format <= 0.5){
       // echo$lineas;
        //$lineas=$lineas+1;;
        // echo$lineas;
    }
    if($lineas==0){
        echo $i."<br />";
        $i++;
    }
    $centinela = 0;
    while($centinela <= $lineas){
        echo $i."<br />";
        $i++;
        $centinela++;
    }
    ?>
      </td>
    <td><strong>4.2. Lesiones encontradas</strong><br />
    <div style="width:650px"><?php if(isset($_REQUEST["dic_le"])){
        if($_REQUEST["dic_le"] != ""){
            echo $_REQUEST["dic_le"];
        }else{
           echo "NO HAY DESCRIPCION";
       }
        }?></div>
    </td>
  </tr>
   <tr>
       <td valign="top">
           <?php
    $total = strlen($_REQUEST["dic_ae"]);
    //echo $total;
    $lineas = $total/100;
    $decimal=explode(".",$lineas);
    $lineas = (integer)$lineas;
    $decimal_format="0.".$decimal[1];
    $decimal_format=(double)$decimal_format;
    //echo $decimal_format;
    if($decimal_format != 0 && $decimal_format <= 0.5){
       // echo$lineas;
        //$lineas=$lineas+1;;
        // echo$lineas;
    }
    if($lineas==0){
        echo $i."<br />";
        $i++;
    }
    $centinela = 0;
    while($centinela <= $lineas){
        echo $i."<br />";
        $i++;
        $centinela++;
    }
    ?>
       </td>
    <td><strong>4.3. Alteraciones encontradas</strong><br />
    <div style="width:650px"><?php if(isset($_REQUEST["dic_ae"])){
        if($_REQUEST["dic_ae"] != ""){
        echo $_REQUEST["dic_ae"];
        }else{
           echo "NO HAY DESCRIPCION";
       }
        }?></div>
    </td>
  </tr>
   <tr>
       <td valign="top">
           <?php
    $total = strlen($_REQUEST["dic_rc"]);
    //echo $total;
    $lineas = $total/100;
    $decimal=explode(".",$lineas);
    $lineas = (integer)$lineas;
    $decimal_format="0.".$decimal[1];
    $decimal_format=(double)$decimal_format;
    //echo $decimal_format;
    if($decimal_format != 0 && $decimal_format <= 0.5){
       // echo$lineas;
        //$lineas=$lineas+1;;
        // echo$lineas;
    }
    if($lineas==0){
        echo $i."<br />";
        $i++;
    }
    $centinela = 0;
    while($centinela <= $lineas){
        echo $i."<br />";
        $i++;
        $centinela++;
    }
    ?>
       </td>
    <td><strong>4.3. Resultados de laboratorio criminalística y de ciencias forenses.</strong><br />
    <div style="width:650px"><?php if(isset($_REQUEST["dic_rc"])){
        if($_REQUEST["dic_rc"] != ""){
        echo $_REQUEST["dic_rc"];
        }else{
           echo "NO HAY DESCRIPCION";
       }
        }?></div>
    </td>
  </tr>
  <tr>
      <td valign="top">
          <?php
    $total = strlen($_REQUEST["dic_com"]);
    //echo $total;
    $lineas = $total/100;
    $decimal=explode(".",$lineas);
    $lineas = (integer)$lineas;
    $decimal_format="0.".$decimal[1];
    $decimal_format=(double)$decimal_format;
    //echo $decimal_format;
    if($decimal_format != 0 && $decimal_format <= 0.5){
       // echo$lineas;
        //$lineas=$lineas+1;;
        // echo$lineas;
    }
    if($lineas==0){
        echo $i."<br />";
        $i++;
    }
    $centinela = 0;
    while($centinela <= $lineas){
        echo $i."<br />";
        $i++;
        $centinela++;
    }
    ?>
      </td>
    <td><div class="txt_title">5. Comentarios</div>
    <div style="width:650px"><?php if(isset($_REQUEST["dic_com"])){
        if($_REQUEST["dic_com"] != ""){
            echo $_REQUEST["dic_com"];
        }else{
           echo "NO HAY DESCRIPCION";
       }
        }?></div>
    </td>
  </tr>
  <tr>
      <td valign="top">
          <?php
          echo $i."<br/>";
          $x=0;
          while($x<2){
            $i++;echo $i."<br/>";
            $x++;
          }
    $total = strlen($_REQUEST["maneraMuerteDpvml"]);
    if($total >= 100){
       $i++;echo $i."<br/>";
    }
    
    ?>
      </td>
    <td><div class="txt_title">6. Conclusiones</div>
    <div style="width:650px">6.1. Causa de muerte: <?php if(isset($_REQUEST["causaUnoa"])){
                        echo " ".$_REQUEST["causaUnoa"];
		/*if(isset($_REQUEST["causaUnob"])){
			echo "<br />&nbsp;&nbsp;&nbsp;B) ".$_REQUEST["causaUnob"];
		}if(isset($_REQUEST["causaUnoc"])){
			echo "<br />&nbsp;&nbsp;&nbsp;C) ".$_REQUEST["causaUnoc"];
		}if(isset($_REQUEST["causaUnod"])){
			echo "<br />&nbsp;&nbsp;&nbsp;D) ".$_REQUEST["causaUnod"];
		}}
	if(isset($_REQUEST["causaDos"])){
			echo "<br />II. ".$_REQUEST["causaDos"];
		
	*/}?></div>
    <div style="width:650px">6.2. Manera de muerte: <?php if(isset($_REQUEST["maneraMuerteDpvml"])){echo $_REQUEST["maneraMuerteDpvml"].", desde el punto de vista médico legal.";}?></div>
    </td>
  </tr>
  <tr>
      <td valign="top">
          <?php $i++;
    $total = strlen($_REQUEST["dic_simb"]);
    //echo $total;
    $lineas = $total/100;
    $decimal=explode(".",$lineas);
    $lineas = (integer)$lineas;
    $decimal_format="0.".$decimal[1];
    $decimal_format=(double)$decimal_format;
    //echo $decimal_format;
    if($decimal_format != 0 && $decimal_format <= 0.5){
       // echo$lineas;
        //$lineas=$lineas+1;;
        // echo$lineas;
    }
    if($lineas==0){
        echo $i."<br />";
        $i++;
    }
    $centinela = 0;
    while($centinela <= $lineas){
        echo $i."<br />";
        $i++;
        $centinela++;
    }
    ?>
      </td>
    <td><div class="txt_title">7. Simbología y definiciones</div>
    <div style="width:650px"><?php if(isset($_REQUEST["dic_simb"])){
        if($_REQUEST["dic_simb"] != ""){
            echo $_REQUEST["dic_simb"];
        }else{
           echo "NO HAY DESCRIPCION";
       }
        }?></div>
    </td>
  </tr>
  <tr>
      <td valign="top">
           <?php 
    $total = strlen($_REQUEST["dic_obs"]);
    //echo $total;
    $lineas = $total/100;
    $decimal=explode(".",$lineas);
    $lineas = (integer)$lineas;
    $decimal_format="0.".$decimal[1];
    $decimal_format=(double)$decimal_format;
    //echo $decimal_format;
    if($decimal_format != 0 && $decimal_format <= 0.5){
       // echo$lineas;
        //$lineas=$lineas+1;;
        // echo$lineas;
    }
    if($lineas==0){
        echo $i."<br />";
        $i++;
    }
    $centinela = 0;
    while($centinela <= $lineas){
        echo $i."<br />";
        $i++;
        $centinela++;
    }
    ?>
      </td>
    <td><div class="txt_title">8. Observaciones</div>
    <div style="width:650px"><?php if(isset($_REQUEST["dic_obs"])){
        if($_REQUEST["dic_obs"] != ""){
            echo $_REQUEST["dic_obs"];
        }else{
           echo "NO HAY DESCRIPCION";
       }
        }?></div>
    </td>
  </tr>
   <tr>
       <td valign="top">
            <?php
    $total = strlen($_REQUEST["dic_oe"]);
    //echo $total;
    $lineas = $total/100;
    $decimal=explode(".",$lineas);
    $lineas = (integer)$lineas;
    $decimal_format="0.".$decimal[1];
    $decimal_format=(double)$decimal_format;
    //echo $decimal_format;
    if($decimal_format != 0 && $decimal_format <= 0.5){
       // echo$lineas;
        //$lineas=$lineas+1;;
        // echo$lineas;
    }
    if($lineas==0){
        echo $i."<br />";
        $i++;
    }
    $centinela = 0;
    while($centinela <= $lineas){
        echo $i."<br />";
        $i++;
        $centinela++;
    }
    ?>
       </td>
    <td><div class="txt_title">9. Objetos evaluados</div>
    <div style="width:650px"><?php if(isset($_REQUEST["dic_oe"])){
        if($_REQUEST["dic_oe"] != ""){
            echo $_REQUEST["dic_oe"];
        }else{
           echo "NO HAY DESCRIPCION";
       }
        }?></div>
    </td>
  </tr>
  <tr>
      <td valign="top">
           <?php
    $total = strlen($_REQUEST["dic_ref"]);
    //echo $total;
    $lineas = $total/100;
    $decimal=explode(".",$lineas);
    $lineas = (integer)$lineas;
    $decimal_format="0.".$decimal[1];
    $decimal_format=(double)$decimal_format;
    //echo $decimal_format;
    if($decimal_format != 0 && $decimal_format <= 0.5){
       // echo$lineas;
        //$lineas=$lineas+1;;
        // echo$lineas;
    }
    if($lineas==0){
        echo $i."<br />";
        $i++;
    }
    $centinela = 0;
    while($centinela <= $lineas){
        echo $i."<br />";
        $i++;
        $centinela++;
    }
    ?>
      </td>
    <td><div class="txt_title">10. Referencias</div>
    <div style="width:650px"><?php if(isset($_REQUEST["dic_ref"])){
        if($_REQUEST["dic_ref"] != ""){
            echo $_REQUEST["dic_ref"];
        }else{
           echo "NO HAY DESCRIPCION";
       }
        }?></div><br/><br/>
    </td>
    </tr>
    <tr>
        <td valign="top">
            <?php
            echo $i."<br/>";
            echo ($i+1)."<br/><br/><br/>";
            echo ($i+2)."<br/>";
            echo ($i+3)."<br/>";
          ?>
        </td>
    <td>
    <table border="0" cellpadding="0" cellspacing="0">
        <tr>
        <td><div style="width:400px">PERITO  RESPONSABLE DOCTOR/A: <strong><?php if(isset($_REQUEST["sperito"])){echo $_REQUEST["sperito"];}?></strong></div></td>
        <td align="center" class="linea"><div style="width:200px;">&nbsp;</div></td>
        </tr>
        <tr>
        <td valign="top">Departamento de patología forense</td>
        <td align="center" valign="top" class="small_font">Firma y Sello<br/><br/><br/></td>
        </tr>
        <tr>
        <td><strong>Ref. Dr(a). <?php if(isset($_REQUEST["jefe"])){echo $_REQUEST["jefe"];}?></strong></td>
        <td align="center" class="linea">&nbsp;</td>
        </tr>
        <tr>
        <td>Jefe de Patología forense</td>
        <td align="center" valign="top" class="small_font">Firma y Sello</td>
        </tr>
    </table>
    </td>
    </tr>
  </table>
</page>
