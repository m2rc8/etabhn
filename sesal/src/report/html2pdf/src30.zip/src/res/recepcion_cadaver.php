<style type="text/Css">
<!--
.small_font{
	font-size:8px;
	color:#666;
}
.bg_img{
	background-color:#F5ECCE;
	border-radius:5px;
	height:20px;
}
.linea{
	border-width:1px;
	border-bottom:solid;
	border-color:#666;
}
.txt_titleheader{
	font-size:13px;
	font-weight:bold;
	color:#333;
}
.txt_titleheader_cotenido{
	font-size:10px;
}
-->
</style>
<page backtop="25mm" backimg="./res/img/logos/fondo.jpg"  backbottom="30mm" backleft="0mm" backright="0mm" pagegroup="new" style="font-size: 12px; text-transform: uppercase;">
<page_header>
 <table border="0" align="center" cellpadding="10" cellspacing="0">
  <tr>
    <td rowspan="2"><img src="./res/img/logos/mp.jpg" /></td>
    <td rowspan="2" align="center"><img src="./res/img/logos/logo_fondo_small.jpg" /></td>
    <td colspan="2" align="right" class="txt_titleheader">DIRECCIÓN GENERAL DE MEDICINA FORENSE<br/>DEPARTAMENTO DE PATOLOGÍA FORENSE<br/>
    <strong>HOJA DE RECEPCIÓN DE CADAVER</strong></td>
  </tr>
  <tr>
    <td>Vigente desde 2010.10.07</td>
    <td align="right">PF-F115-1 V02 B02</td>
  </tr>
  <tr>
    <td colspan="4" valign="bottom" class="linea" height="10px"></td>
  </tr>
  <tr bgcolor="#E9E9E9">
    <td class="txt_titleheader_cotenido">Redactado por: L. Cruz, C. Martínez, E. López</td>
    <td align="right" class="txt_titleheader_cotenido" width="245">Editado por: T. Calidonio</td>
    <td align="right" class="txt_titleheader_cotenido">Revisado por: I. Raudales</td>
    <td align="right" class="txt_titleheader_cotenido">Aprobado por: J. Villanueva </td>
  </tr>
</table>
</page_header>
<page_footer>
  <table align="center" cellpadding="3" cellspacing="3" border="0">
  <tr>
    <td colspan="5" bgcolor="#CCC"></td>
  </tr>
  <tr>
  <td colspan="5" style="font-size:9px;">Cualquier  corrección o nota de ampliación en este documento es válida sólo con la firma  de la persona autorizada.</td>
  </tr>
  <tr>
  <td colspan="5" bgcolor="#CCC"></td>
  </tr>
  <tr>
    <td align="center" valign="top" style="font-size:12px;"><b>FECHA  DE EMISIÓN<br />
    <?php echo date("Y.m.d");?></b>
    </td>
    <td bgcolor="#CCC"></td>
    <td align="right" width="480" style=" font-size:10px;">
    <b>DIRECCIÓN DE MEDICINA FORENSE <br />
	DEPARTAMENTO DE PATOLOGÍA FORENSE<br />
	Edificio Santa Ana, Contiguo al Hospital Escuela. Tegucigalpa M.D.C.</b>
    </td>
    <td bgcolor="#CCC"></td>
    <td align="center" valign="top" style="font-size:12px;"><b>Página<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[[page_cu]] de [[page_nb]]</b></td>
  </tr>
</table>
</page_footer>
  <table width="100%" border="0" cellspacing="3" cellpadding="10" align="center">
    <tr>
      <td colspan="4" valign="middle" class="bg_img"><strong>RECEPCIÓN  DE CUERPO EN SEDE:</strong><div style="width:400px;" class="linea">&nbsp;
        <?php if(isset($_REQUEST["sede"])){echo $_REQUEST["sede"];}?>
      </div></td>
    </tr>
    <tr>
      <td colspan="4"><table>
        <tr>
        <td>LEVANTAMIENTO N°:</td>
            <td align="center" valign="bottom" class="linea"><span style="width:522px;">
            <?php if(isset($_REQUEST["cod_lev"])){echo substr($_REQUEST["cod_lev"],0,4);}?>
            </span></td>
            <td align="center" valign="bottom" class="linea"><span style="width:522px;">
            <?php if(isset($_REQUEST["cod_lev"])){echo substr($_REQUEST["cod_lev"],4,4);}?>
            </span></td>
            <td align="center" valign="bottom" class="linea"><span style="width:522px;">
            <?php if(isset($_REQUEST["cod_lev"])){echo substr($_REQUEST["cod_lev"],8,4);}?>
            </span></td>
            <td align="center" valign="bottom" class="linea"><span style="width:522px;">
            <?php if(isset($_REQUEST["cod_lev"])){echo substr($_REQUEST["cod_lev"],12,16);}?>
            </span></td>
            <td>&nbsp;&nbsp;&nbsp;MÉDICO LEVANTAMIENTO:<div class="linea" style="width:250px;">&nbsp;<?php if(isset($_REQUEST["medico_lev"])){echo $_REQUEST["medico_lev"];}?></div></td>
          </tr>
          <tr align="center" valign="top" class="small_font">
            <td>&nbsp;</td>
            <td>AÑO</td>
            <td>SEDE</td>
            <td>DEPTO</td>
            <td>CORRELATIVO</td>
            <td>&nbsp;</td>
          </tr>
        </table>
        </td>
    </tr>
    <tr>
      <td>FECHA DE  LEVANTAMIENTO:<div class="linea" style="width:100px; text-align:center">&nbsp;
        <?php if(isset($_REQUEST["fechalev"])){echo $_REQUEST["fechalev"];}?>
      </div></td>
      <td colspan="3">HORA DE ENTRADA:
      <div class="linea" style="width:100px; text-align:center">&nbsp;<?php if(isset($_REQUEST["hora_entrada"])){echo $_REQUEST["hora_entrada"];}?></div></td>
    </tr>
    <tr>
      <td align="center" valign="top" class="small_font"  style="padding-left:80px;">DD/MM/AAAA</td>
      <td colspan="3" align="center" valign="top" class="small_font" style="padding-right:45px;">Sistema de 24 horas</td>
    </tr>
    <tr>
      <td colspan="4" valign="middle" class="bg_img"><strong>DATOS DEL OCCISO/FALLECIDO</strong></td>
    </tr>
    <tr>
      <td colspan="4">1.1. <div style="width:580px;" class="linea">&nbsp;
        <?php if(isset($_REQUEST["oestado"])){
              if($_REQUEST["oestado"]=="C"){
                echo "CONOCIDO";
              }else if($_REQUEST["oestado"]=="D"){
                echo "DESCONOCIDO";
              }else if($_REQUEST["oestado"]=="S"){
                echo "SUPUESTO";
              }

            }?>
    </div></td>
    </tr>
    <tr>
      <td colspan="4">1.2. NOMBRE:<div style="width:520px;" class="linea">&nbsp;
        <?php if(isset($_REQUEST["nombre"])){echo $_REQUEST["nombre"];}?>
      </div></td>
    </tr>
    <tr>
      <td colspan="4">1.3. TIPO DE IDENTIFICACION:<div style="width:428px;" class="linea">&nbsp;
        <?php if(isset($_REQUEST["tipo_iden"])){echo $_REQUEST["tipo_iden"];}?>
      </div></td>
    </tr>
    <tr>
      <td colspan="4">1.4. NUMERO DE DOCUMENTO DE IDENTIFICACIÓN:<div style="width:302px;" class="linea">&nbsp;
        <?php if(isset($_REQUEST["numdoc_iden"])){echo $_REQUEST["numdoc_iden"];}?>
      </div></td>
    </tr>
    <tr>
      <td>1.5. EDAD:<div style="width:80px;" class="linea">&nbsp;
        <?php if(isset($_REQUEST["oedad"])){echo $_REQUEST["oedad"];}?>
      </div></td>
      <td colspan="2">1.7. SEXO:<div style="width:100px;" class="linea">&nbsp;
        <?php if(isset($_REQUEST["osexo"])){echo $_REQUEST["osexo"];}?>
      </div></td>
      <td>1.8.OTRO:<div style="width:100px;" class="linea">&nbsp;
        <?php if(isset($_REQUEST["var"])){echo $_REQUEST["var"];}?>
      </div></td>
    </tr>
    <tr>
      <td valign="middle" class="bg_img"><strong>2.LUGAR DE  LEVANTAMIENTO</strong></td>
      <td colspan="2" align="center" valign="bottom" class="linea">&nbsp;
        <?php if(isset($_REQUEST["lugarlev_dep"])){echo $_REQUEST["lugarlev_dep"];}?>
      </td>
      <td align="center" valign="bottom" class="linea"><?php if(isset($_REQUEST["lugarlev_mun"])){echo $_REQUEST["lugarlev_mun"];}?></td>
    </tr>
    <tr>
    <td>&nbsp;</td>
      <td colspan="2" align="center" valign="top" class="small_font">DEPARTAMENTO</td>
      <td align="center" valign="top" class="small_font">MUNICIPIO</td>
    </tr>
    <tr>
      <td colspan="2" align="center" class="linea">&nbsp;
	  <?php if(isset($_REQUEST["lugarlev_ciudad"])){echo $_REQUEST["lugarlev_ciudad"];}?></td>
      <td colspan="2" align="center" class="linea">
      <?php if(isset($_REQUEST["lugarlev_ba"])){echo $_REQUEST["lugarlev_ba"];}?></td>
    </tr>
    <tr>
      <td colspan="2" align="center" valign="top" class="small_font">CIUDAD,  PUEBLO, ALDEA, CASERIO</td>
      <td colspan="2" align="center" valign="top" class="small_font">BARRIO,  COLONIA</td>
    </tr>
    <tr>
      <td colspan="4" align="center" class="linea">&nbsp;
        <?php if(isset($_REQUEST["lugarlev_dir"])){echo $_REQUEST["lugarlev_dir"];}?>
    </td>
    </tr>
    <tr>
      <td colspan="4" align="center" valign="top" class="small_font">DIRECCION  ESPECIFICA</td>
    </tr>
    <tr>
      <td colspan="4" valign="middle" class="bg_img"><strong>CADAVER Y DOCUMENTACIÓN</strong></td>
    </tr>
    <tr>
      <td colspan="4">3. CONDICIÓN DEL CADAVER AL  MOMENTO DEL INGRESO A MORGUE:<div style="width:210px;" class="linea">
            &nbsp;<?php if(isset($_REQUEST["condicionCadaver"])){
              if($_REQUEST["condicionCadaver"]==1){
                echo "INTEGRO";
              }else if($_REQUEST["condicionCadaver"]==2){
                echo "INCOMPLETO";
              }else if($_REQUEST["condicionCadaver"]==3){
                echo "PUTREFACTO";
              }
            }?>
     </div></td>
    </tr>
    <tr>
      <td colspan="4">4. TIPO DE INGRESO:<div style="width:500px;" class="linea">
          &nbsp;<?php if(isset($_REQUEST["tipoIngreso"])){
            if($_REQUEST["tipoIngreso"]==1){
              echo "AUTOPSIA MEDICO LEGAL";
            }else if($_REQUEST["tipoIngreso"]==2){
              echo "DEPOSITO";
            }else if($_REQUEST["tipoIngreso"]==3){
              echo "RIESGO BIOLOGICO";
            }
          }?>
      </div></td>
    </tr>
    <tr>
      <td colspan="4">5. TIPO DE MUERTE:<div style="width:505px;" class="linea">
          &nbsp;<?php if(isset($_REQUEST["tipoMuerte"])){
            if($_REQUEST["tipoMuerte"]==1){
              echo "VIOLENTA";
            }else if($_REQUEST["tipoMuerte"]==2){
              echo "NATURAL";
            }else if($_REQUEST["tipoMuerte"]==3){
              echo "PENDIENTE DE INVESTIGACIÓN";
            }
        }?>
      </div></td>
    </tr>
    <tr>
      <td colspan="4">6. FISCAL QUE AUTORIZA LA  AUTOPSIA:<div style="width:390px;" class="linea">
          &nbsp;<?php if(isset($_REQUEST["fiscal"])){echo $_REQUEST["fiscal"];}?>
      </div></td>
    </tr>
    <tr>
      <td colspan="4">7. DOCUMENTACIÓN DE INGRESO:<div style="width:420px;" class="linea">
        &nbsp;<?php if(isset($_REQUEST["documento"])){
          if($_REQUEST["documento"]=="S"){
          echo "SI";
          }else if($_REQUEST["documento"]=="N"){
          echo "NO";
        }
        }?>
      </div></td>
    </tr>
    <tr>
      <td colspan="4" valign="middle" class="bg_img"><strong>MEDIO  DE TRANSPORTE PARA TRASLADO DE CADAVER A MORGUE:
      <?php
        if(isset($_REQUEST["transporteTraslado"])){
          if($_REQUEST["transporteTraslado"]==1){
            echo "MORGUERA";
          }else if($_REQUEST["transporteTraslado"]==2){
            echo "VEHICULO POLICIAL";
          }else if($_REQUEST["transporteTraslado"]==3){
            echo "VEHICULO PARTICULAR";
          }else if($_REQUEST["transporteTraslado"]==4){
            echo "OTRA INSTITUCIÓN";
          }
        }?>
      </strong></td>
    </tr>
    <tr>
      <td colspan="2" align="center" class="linea">
        &nbsp;<?php if(isset($_REQUEST["vehiculoPropietario"])){echo $_REQUEST["vehiculoPropietario"];}?>
      </td>
      <td align="center" class="linea">
        &nbsp;<?php if(isset($_REQUEST["marca"])){echo $_REQUEST["marca"];}?>
      </td>
      <td align="center" class="linea">
        &nbsp;<?php if(isset($_REQUEST["color"])){echo $_REQUEST["color"];}?>
     </td>
    </tr>
    <tr>
      <td colspan="2" align="center" valign="top" class="small_font">VEHICULO PERTENECE A</td>
      <td align="center" valign="top" class="small_font">MARCA</td>
      <td align="center" valign="top" class="small_font">COLOR</td>
    </tr>
    <tr>
      <td colspan="2" align="center" class="linea">&nbsp;
        <?php if(isset($_REQUEST["placa"])){echo $_REQUEST["placa"];}?>
      </td>
      <td align="center" class="linea">&nbsp;
        <?php if(isset($_REQUEST["vehiculoConductor"])){echo $_REQUEST["vehiculoConductor"];}?>
      </td>
    </tr>
    <tr>
      <td colspan="2" align="center" valign="top" class="small_font">PLACA</td>
      <td align="center" valign="top" class="small_font">NOMBRE DEL CONDUCTOR</td>
    </tr>
    <tr>
      <td colspan="4">8. PRENDAS  Y OBJETOS DEL CADAVER CORRESPONDEN CON LA DESCRIPCIÓN DE PERTENENCIAS DE  LEVANTAMIENTO:<strong>
<?php if(isset($_REQUEST["concidencia_prenda"])){
          if($_REQUEST["concidencia_prenda"]=="S"){
            echo "SI";
          }else if($_REQUEST["concidencia_prenda"]=="N"){
            echo "NO";
          }
		}
        ?>
      </strong></td>
    </tr>
    <tr>
      <td colspan="4"><div style="width:700px; text-height:20px; text-align:justify;">
	  <?php if(isset($_REQUEST["descripcionPrendas"])){echo $_REQUEST["descripcionPrendas"];}?></div></td>
    </tr>
    <tr>
      <td colspan="4" valign="middle" class="bg_img"><strong>9. DESTINO CADAVER:
      <?php if(isset($_REQUEST["destino"])){ 
        if($_REQUEST["destino"]==1){
          echo "SALA DE AUTOPSIA";
        }else if($_REQUEST["destino"]==2){
          echo "CUARTO FRIO";
        }
	  }
      ?>
      </strong></td>
    </tr>
    <tr>
      <td>FECHA DE MOVIMIENTO:
        <div class="linea" style="width:100px; text-align:center">&nbsp;<?php if(isset($_REQUEST["fecha_traslado"])){echo $_REQUEST["fecha_traslado"];}?></div>
       </td>
      <td colspan="3">HORA DE MOVIMIENTO:<div style="width:100px; text-align:center" class="linea">&nbsp;<?php if(isset($_REQUEST["hora_traslado"])){echo $_REQUEST["hora_traslado"];}?></div></td>
    </tr>
     <tr>
      <td align="center" valign="top" class="small_font" style="padding-left:30px;">DD/MM/AAAA</td>
      <td colspan="3" align="center" valign="top" class="small_font" style="padding-right:8px;">Sistema de 24 horas</td>
    </tr>
    <tr>
      <td colspan="4"><strong><br /><br>
      NOMBRE DE RECEPTOR DE  TURNO:</strong><div style="width:410px;" class="linea">&nbsp;</div></td>
    </tr>
    <tr>
      <td colspan="4" valign="middle"><br /><br /><br />
      <strong>FIRMA DE RECEPTOR DE TURNO:</strong><div style="width:424px;" class="linea">&nbsp;</div></td>
    </tr>
  </table>
</page>