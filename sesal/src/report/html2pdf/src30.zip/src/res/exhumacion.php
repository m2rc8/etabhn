<style type="text/Css">


#body{
	font-family:Arial, Helvetica, sans-serif;
	font-size:12px;
	font-weight:400;
	color:#000;
}

.table {
  border-collapse: separate;
  border-spacing:  3px;
}

.small_font{
	font-size:8px;
	color:#666;
}
.bg_img{
	background-color:#92cddc;
	border-radius:5px;
	height:20px;
}
.linea{
	border-width:1px;
	border-bottom:solid;
        border-color:#666;
}
.txt_title{
	font-size:14px;
	font-weight:bold;
}
.txt_titleheader{
	font-size:13px;
	font-weight:bold;
	color:#333;
}
.txt_titleheader_cotenido{
	font-size:10px;
}
.dr{
	
	}
-->
</style>

<page backtop="30mm" backimg="./res/img/logos/fondo.jpg" backbottom="30mm" backleft="6mm" backright="5mm" pagegroup="new" style=" font-size: 11px; text-transform: uppercase;">
<page_header>
<table border="0" align="center" cellpadding="10" cellspacing="0">
  <tr>
    <td rowspan="2"><img src="./res/img/logos/mp.jpg" /></td>
    <td rowspan="2" align="center"><img src="./res/img/logos/logo_fondo_small.jpg" /></td>
    <td colspan="2" align="right" class="txt_titleheader">DIRECCIÓN GENERAL DE MEDICINA FORENSE<br/>DEPARTAMENTO DE PATOLOGÍA FORENSE<br/>
    <strong>HOJA DE TRABAJO PARA EXHUMACIONES</strong></td>
  </tr>
  <tr>
    <td>En revisión</td>
    <td align="right">PF-F118-1 V01 B03</td>
  </tr>
  <tr>
    <td colspan="4" valign="bottom" class="linea" height="10px"></td>
  </tr>
  <tr bgcolor="#E9E9E9">
    <td class="txt_titleheader_cotenido">Redactado por: L. Cruz, C. Martínez, E. López</td>
    <td align="right" class="txt_titleheader_cotenido" width="220">Editado por: T. Calidonio</td>
    <td align="right" class="txt_titleheader_cotenido">Revisado por: I. Raudales</td>
    <td align="right" class="txt_titleheader_cotenido">Aprobado por: I. Raudales</td>
  </tr>
  <tr>
    <td colspan="4" align="right"><p style="margin-right:-20px">Página [[page_cu]] de [[page_nb]]</p></td>
  </tr>
</table>
</page_header>
<page_footer>
  <div><img src="./res/img/levantamiento/footer.jpg" ></div>  
</page_footer>
<br />
<table align="center"  width="100%"  cellpadding="10" cellspacing="0" bordercolor="#CCCCCC" style="border-width:1px; border-style:solid; border-color:#CCC; border-radius: 5px;">  
    <tr>
        <td colspan="2" valign="middle" class="txt_title" bgcolor="#F5D0A9">1. DATOS DE EXHUMACIÓN</td>
    </tr>
    <tr>
   <td align="left" valign="top"><div style="width:208px">EXHUMACIÓN N°:</div></td>
   <td align="left" valign="top">
       <table>
      <tr>
<td width="120" align="center" valign="bottom" class="linea"><span style="width:522px;">&nbsp;<?php if(isset($_REQUEST["anio"])){echo $_REQUEST["anio"];}?></span></td>
<td width="120" align="center" valign="bottom" class="linea"><span style="width:522px;">&nbsp;<?php if(isset($_REQUEST["sede"])){echo $_REQUEST["sede"];}?></span></td>
<td width="120" align="center" valign="bottom" class="linea" ><span style="width:522px;">&nbsp;<?php if(isset($_REQUEST["dep"])){echo $_REQUEST["dep"];}?></span></td>
<td width="120" align="center" valign="bottom" class="linea"><span style="width:522px;">&nbsp;<?php if(isset($_REQUEST["correlativo"])){echo $_REQUEST["correlativo"];}?></span></td>
</tr>
      <tr>
        <td class="small_font" align="center">AÑO</td>
        <td class="small_font" align="center">SEDE</td>
        <td class="small_font" align="center">DEPTO</td>
        <td class="small_font" align="center">CORRELATIVO</td>
        </tr>
   </table>
    </td>
  </tr>
</table>
<br />
<table width="100%" align="center" bordercolor="#CCCCCC" style="border-width:1px; border-style:solid; border-color:#CCC; border-radius: 5px;"> 
  <tr>
    <td>Fallecido:</td>
    <td class="linea"><?php if(isset($_REQUEST["estado_fallecido"])){
		switch($_REQUEST["estado_fallecido"])
		{	case 1: echo "DESCONOCIDO";
			break;
			case 2: echo "SUPUESTO";
			break;
			}}?></td>
      <td width="93" align="center" bgcolor="#F5D0A9" class="txt_title"><strong>Edad</strong></td>
    <td width="98" align="center" bgcolor="#F5D0A9" class="txt_title"><strong>Sexo</strong></td>
    <td width="93" align="center" bgcolor="#F5D0A9" class="txt_title"><strong>Talla</strong></td>
  </tr>
  <tr>
    <td>Nombre del Fallecido:</td>
    <td><div class="linea" style="width:280px">&nbsp;<?php if(isset($_REQUEST["nombre_fallecido"])){echo $_REQUEST["nombre_fallecido"];}?></div></td>
    <td align="center" class="linea"><?php if(isset($_REQUEST["edad"])){
        if($_REQUEST["edad"] >= 0){
            echo $_REQUEST["edad"];
        }else{
            echo"N/D";
        }
        }?></td>
    <td align="center" class="linea"><?php if(isset($_REQUEST["sexo"])){echo $_REQUEST["sexo"];} ?></td>
    <td align="center" class="linea"><?php if(isset($_REQUEST["talla"])){echo $_REQUEST["talla"];}?></td>

    </tr>
</table>
<br />
<table width="100%" align="center" bordercolor="#CCCCCC" style="border-width:1px; border-style:solid; border-color:#CCC; border-radius: 5px;"> 
  <tr class="txt_title">
    <td align="center" bgcolor="#F5D0A9" width="300"><strong>Fecha de Muerte</strong></td>
    <td colspan="2" align="center" bgcolor="#F5D0A9" width="420"><strong>Fecha y Hora de la EXHUMACIÓN</strong></td>
  </tr>
  <tr>
    <td class="linea" align="center"><?php if(isset($_REQUEST["fecha_muerte"])){echo $_REQUEST["fecha_muerte"];}?></td>
    <td  class="linea" align="center"><?php if(isset($_REQUEST["exh_fecha"])){echo $_REQUEST["exh_fecha"];}?></td>
    <td class="linea" align="center"><?php if(isset($_REQUEST["exh_hora"])){echo $_REQUEST["exh_hora"];}?></td>
  </tr>
  <tr>
    <td align="center" class="small_font">DD/MM/AAAA</td>
    <td align="center" class="small_font">DD/MM/AAAA</td>
    <td align="center" class="small_font">SISTEMA DE 24 HORAS</td>
  </tr>
</table>
<br />
<table width="100%" align="center"  bordercolor="#CCCCCC" style="border-width:1px; border-style:solid; border-color:#CCC; border-radius: 5px;"> 
  <tr>
  <td colspan="3" bgcolor="#F5D0A9" class="txt_title">2.Lugar de la EXHUMACIÓN:</td>
  </tr>
   <tr>
  <td>Tipo EXHUMACIÓN:
    <div style="width:210px;" class="linea">&nbsp;<?php 
	if(isset($_REQUEST["lugar_exh"])){ 
		switch($_REQUEST["lugar_exh"])
			{ 
				case 1: echo "Cementerio Publico";
				break;
				case 2: echo "Cementerio Privado";
				break;
				case 3: echo "Fosa/cementerio Clandestino";
				break;
				case 4: echo "EXHUMACIÓN Administrativa";
				break;
			}}
	?></div>
  </td>
  <td align="right">No. Muertos:</td>
  <td class="linea"><span style="width:50px;">
    <?php if(isset($_REQUEST["num_muertos"])){echo $_REQUEST["num_muertos"];}?>
  </span></td>
  </tr>
   <tr>
  <td>Departamento: 
    <div style="width:220px;" class="linea">&nbsp;<?php if(isset($_REQUEST["departamento"])){echo $_REQUEST["departamento"];}?></div></td>
  <td align="right">Municipio:</td>
  <td class="linea"><div style="width:220px;">&nbsp;
    <?php if(isset($_REQUEST["municipio"])){echo $_REQUEST["municipio"];}?>
  </div></td>
  </tr>
   <tr>
  <td>Aldea:<div style="width:250px;" class="linea">&nbsp;
    <?php if(isset($_REQUEST["aldea"])){echo $_REQUEST["aldea"];}?></div></td>
  <td>Latitud: 
    <div class="linea" style="width:90px;">&nbsp;<?php if(isset($_REQUEST["gps_lat"])){
        if($_REQUEST["gps_lat"] != ""){
            echo $_REQUEST["gps_lat"];
        }else{
            echo "N/D";
        }
    }?></div></td>
  <td>Longitud: 
    <div class="linea" style="width:170px;">&nbsp;<?php if(isset($_REQUEST["gps_long"])){
        if($_REQUEST["gps_long"] != ""){
            echo $_REQUEST["gps_long"];
        }else{
            echo "N/D";
        }
    }?></div></td>
  </tr>
   <tr>
  <td colspan="3">Direccion  Especifica:<div style="width:512px;" class="linea">&nbsp;
    <?php if(isset($_REQUEST["direccion_especifica"])){echo $_REQUEST["direccion_especifica"];}?></div></td>
  </tr>
   <tr>
  <td colspan="3">Institución Solicitante  de la EXHUMACIÓN:<div style="width:400px;" class="linea">&nbsp;
    <?php if(isset($_REQUEST["inst_solicitante"])){echo $_REQUEST["inst_solicitante"];}?></div></td>
  </tr>
   <tr>
     <td>Autoridad  Solicitante:<div style="width:200px;" class="linea">&nbsp;
     <?php if(isset($_REQUEST["autoridad_solicitante"])){echo $_REQUEST["autoridad_solicitante"];}?></div></td>
     <td align="right">Cargo:</td>
     <td class="linea"><?php if(isset($_REQUEST["cargo"])){echo $_REQUEST["cargo"];}?></td>
   </tr>
  </table>
<br />
<table width="100%" border="1" align="center" cellpadding="0" cellspacing="0"  bordercolor="#D8D8D8" style="border-radius: 5px;"> 
  <tr>
    <td  colspan="4" bgcolor="#F5D0A9" class="txt_title">3.NOMBRES DEL PERSONAL PRESENTE EN LA EXHUMACIÓN</td>
  </tr>
  <tr>
    <td width="120" align="right">Médico Forense:</td>
    <td colspan="3"><?php if(isset($_REQUEST["medico_forense"])){echo $_REQUEST["medico_forense"];}?></td>
  </tr>
  <tr>
    <td align="right">Odontologo Forense:</td>
    <td colspan="3"><?php if(isset($_REQUEST["odontologo_forense"])){echo $_REQUEST["odontologo_forense"];}?></td>
  </tr>
  <tr>
    <td align="right">Tecnico Disector:</td>
    <td colspan="3"><?php if(isset($_REQUEST["tecnico_disector"])){echo $_REQUEST["tecnico_disector"];}?></td>
  </tr>
  <tr>
    <td align="right">Juez:</td>
    <td colspan="3"><?php if(isset($_REQUEST["juez"])){
        if($_REQUEST["juez"] != ""){
            echo $_REQUEST["juez"];
        }else{
            echo "N/D";
        }
        }?></td>
  </tr>
  <tr>
    <td align="right">Fiscal:</td>
    <td colspan="3"><?php if(isset($_REQUEST["fiscal"])){echo $_REQUEST["fiscal"];}?></td>
  </tr>
  <tr>
    <td align="right">Defensor:</td>
    <td colspan="3"><?php if(isset($_REQUEST["defensor"])){
        if($_REQUEST["defensor"] != ""){
            echo $_REQUEST["defensor"];
        }else{
            echo "N/D";
        }
       }?></td>
  </tr>
  <tr>
    <td align="right">Investigador:</td>
    <td colspan="3"><?php if(isset($_REQUEST["investigador"])){
        if($_REQUEST["investigador"] != ""){
            echo $_REQUEST["investigador"];
        }else{
            echo "N/D";
        }
    }?></td>
  </tr>
  <tr>
    <td align="right">Otros:</td>
    <td colspan="3"><?php if(isset($_REQUEST["nombes_otros"])){
        if($_REQUEST["nombes_otros"] != ""){
            echo $_REQUEST["nombes_otros"];
        }else{
            echo "N/D";
        }
    }?></td>
  </tr>
  <tr>
    <td align="right">Caso Judicializado</td>
    <td colspan="3"><?php if(isset($_REQUEST["caso_judicializado"])){echo $_REQUEST["caso_judicializado"];}?></td>
  </tr>
  <tr>
    <td align="right">Estudio hecho en:</td>
    <td colspan="3"><?php if(isset($_REQUEST["estudio_hecho_en"])){
		switch($_REQUEST["estudio_hecho_en"])
		{
			case 1: echo "EL LUGAR";
			break;
			case 2: echo "MEDICINA FORENSE";
			break;
			}}?></td>
  </tr>
  <tr>
    <td>Fotografías:</td>
    <td><div style="width:50px;"><?php if(isset($_REQUEST["fotografias"])){echo $_REQUEST["fotografias"];}?></div></td>
    <td align="right" >Estudio Histopatologico:</td>
    <td><?php if(isset($_REQUEST["estudio_histopatologico"])){echo $_REQUEST["estudio_histopatologico"];}?></td>
  </tr>
  <tr>
    <td>Estudio Radiologico:</td>
    <td><?php if(isset($_REQUEST["estudio_radiologico"])){echo $_REQUEST["estudio_radiologico"];}?></td>
    <td align="right">Estudio Odontologico:</td>
    <td><?php if(isset($_REQUEST["estudio_odontologico"])){echo $_REQUEST["estudio_odontologico"];}?></td>
  </tr>
  <tr>
    <td>Otros estudios:</td>
    <td colspan="3"><div style="width:570px;">&nbsp;<?php if(isset($_REQUEST["otros_estudios"])){
         if($_REQUEST["otros_estudios"] != ""){
            echo $_REQUEST["otros_estudios"];
        }else{
            echo "No hay descripcion";
        }
    }?></div></td>
  </tr>
</table>
<br />

<table width="100%" align="center" bordercolor="#CCCCCC" style="border-width:1px; border-style:solid; border-color:#CCC; border-radius: 5px;"> 
  <tr>
    <td bgcolor="#F5D0A9" class="txt_title">4.HISTORIA MEDICO LEGAL</td>
  </tr>
  <tr>
    <td><div style="width:725px; line-height:20px; text-align:justify"><?php if(isset($_REQUEST["historia_medico_legal"])){echo $_REQUEST["historia_medico_legal"];}?></div></td>
  </tr>
</table>

<br />
<table width="100%" align="center" bordercolor="#CCCCCC" style="border-width:1px; border-style:solid; border-color:#CCC; border-radius: 5px;"> 
  <tr>
    <td bgcolor="#F5D0A9" class="txt_title">5.MOTIVO PARA REALIZAR LA EXHUMACIÓN</td>
  </tr>
  <tr>
    <td><div style="width:725px; line-height:20px; text-align:justify"><?php if(isset($_REQUEST["motivo_realizar_exh"])){echo $_REQUEST["motivo_realizar_exh"];}?></div></td>
  </tr>
</table>
<br />
<table width="100%" align="center" bordercolor="#CCCCCC" style="border-width:1px; border-style:solid; border-color:#CCC; border-radius: 5px;"> 
  <tr>
    <td bgcolor="#F5D0A9" class="txt_title">6.DESCRIPCION DEL LUGAR</td>
  </tr>
  <tr>
    <td><div style="width:725px; line-height:20px; text-align:justify"><?php if(isset($_REQUEST["descripcion_lugar"])){echo $_REQUEST["descripcion_lugar"];}?></div></td>
  </tr>
</table>
<table width="100%" align="center" bordercolor="#CCCCCC" style="border-width:1px; border-style:solid; border-color:#CCC; border-radius: 5px;"> 
  <tr>
    <td colspan="7" bgcolor="#F5D0A9" class="txt_title"><div style="width:725px;">ORIENTACIÓN DE LA SEPULTURA</div></td>
  </tr>
  <tr>
    <td>Rumbo:
      <div class="linea" style="width:150px;">&nbsp;<?php if(isset($_REQUEST["orientacion_rumbo"])){echo $_REQUEST["orientacion_rumbo"];}?></div></td>
    <td  align="right">Orientación:</td>
    <td width="100" class="linea"><?php if(isset($_REQUEST["orientacion_orientacion"])){echo $_REQUEST["orientacion_orientacion"];}?></td>
    <td  align="right">Lat</td>
    <td width="100" class="linea"><?php if(isset($_REQUEST["orientacion_lat"])){
        if($_REQUEST["orientacion_lat"] != ""){
            echo $_REQUEST["orientacion_lat"];
        }else{
            echo "N/D";
        }
    }?></td>
    <td align="right">Long</td>
    <td width="100" class="linea"><?php if(isset($_REQUEST["orientacion_long"])){
        if($_REQUEST["orientacion_long"] != ""){
            echo $_REQUEST["orientacion_long"];
        }else{
            echo "N/D";
        }
    }?></td>
  </tr>
</table>
<br />
<table width="100%" align="center" bordercolor="#CCCCCC" style="border-width:1px; border-style:solid; border-color:#CCC; border-radius: 5px;"> 
<tr>
    <td bgcolor="#F5D0A9" class="txt_title"><div style="width:725px;">7.CADAVER ENCONTRADO EN:
      <?php 
	if(isset($_REQUEST["encontrado_en"])){ 
		switch($_REQUEST["encontrado_en"])
			{ 
				case 1: echo "FERETRO";
				break;
				case 2: echo "BOLSA PLASTICA";
				break;
				case 3: echo "SACOS";
				break;
				case 4: echo "OTROS";
		        	break;
			}}
	?></div></td>
  </tr>
  <tr>
    <td><?php if($_REQUEST["encontrado_en"] == "2" || $_REQUEST["encontrado_en"] == "3" || $_REQUEST["encontrado_en"] == "4"){?>
Descripcion:<div style="width:725px; line-height:20px; text-align:justify">
      <?php if(isset($_REQUEST["encontrado_des"])){echo $_REQUEST["encontrado_des"];}?>
      </div>
<?php }?>
    </td>
  </tr>
</table>
<table width="100%" align="center" bordercolor="#CCCCCC" style="border-width:1px; border-style:solid; border-color:#CCC; border-radius: 5px;"> 
  <tr>
    <td bgcolor="#F5D0A9" class="txt_title">DESCRIPCION DE LA POSICION DEL CADAVER</td>
  </tr>
  <tr>
    <td><div style="width:725px; line-height:20px; text-align:justify"><?php if(isset($_REQUEST["des_posicion_cad"])){echo $_REQUEST["des_posicion_cad"];}?></div></td>
  </tr>
</table>
<br />
<table width="100%" align="center" bordercolor="#CCCCCC" style="border-width:1px; border-style:solid; border-color:#CCC; border-radius: 5px;"> 
  <tr>
    <td  bgcolor="#F5D0A9" class="txt_title">8.ROPAS Y PERTENENCIAS</td>
  </tr>
  <tr>
    <td><div style="width:725px; line-height:20px; text-align:justify"><?php if(isset($_REQUEST["ropas_pertenencias"])){echo $_REQUEST["ropas_pertenencias"];}?></div></td>
  </tr>
</table>
<br />
<table width="100%" align="center" bordercolor="#CCCCCC" style="border-width:1px; border-style:solid; border-color:#CCC; border-radius: 5px;"> 
<tr>
    <td bgcolor="#F5D0A9" class="txt_title"><div style="width:725px;">ESTADO EN QUE SE ENCONTRO EL CADAVER</div></td>
  </tr>
    <tr>
    <td>Estado: <?php 
	if(isset($_REQUEST["estado_cadaver"])){ 
		echo $_REQUEST["estado_cadaver"];
	}	
	?>
    </td>
  </tr>
  <tr>
    <td>
	<?php if($_REQUEST["idestado_cadaver"]=="7" || $_REQUEST["idestado_cadaver"]=="9"){?>
	DESCRIPCION:<br/>
      <div style="width:630px; line-height:20px; text-align:justify"><?php if(isset($_REQUEST["estado_cadaver_des"])){echo $_REQUEST["estado_cadaver_des"];}?></div>
<?php }?>
</td>
  </tr>
</table>
<table width="100%" align="center" bordercolor="#CCCCCC" style="border-width:1px; border-style:solid; border-color:#CCC; border-radius: 5px;"> 
  <tr>
    <td bgcolor="#F5D0A9" class="txt_title">EXAMEN EXTERNO DEL CUERPO</td>
  </tr>
  <tr>
    <td><div style="width:725px; line-height:20px; text-align:justify"><?php if(isset($_REQUEST["examen_externo"])){echo $_REQUEST["examen_externo"];}?></div></td>
  </tr>
<tr>
    <td bgcolor="#F5D0A9" class="txt_title">PIEL</td>
  </tr>
  <tr>
    <td><div style="width:725px; line-height:20px; text-align:justify"><?php if(isset($_REQUEST["piel"])){echo $_REQUEST["piel"];}?></div></td>
  </tr>
</table>
<br />
<table width="100%" align="center" bordercolor="#CCCCCC" style="border-width:1px; border-style:solid; border-color:#CCC; border-radius: 5px;"> 
  <tr>
    <td bgcolor="#F5D0A9" class="txt_title">9.EXAMEN INTERNO DEL CUERPO</td>
  </tr>
  <tr>
    <td class="txt_title">CABEZA:</td>
  </tr>
    <tr>
    <td><div style="width:725px; line-height:20px; text-align:justify"><?php if(isset($_REQUEST["cabeza"])){
        if($_REQUEST["cabeza"] != ""){
            echo $_REQUEST["cabeza"];
        }else{
                echo "No hay descripcion";
         }
        }?></div></td>
  </tr>
  <tr>
    <td class="txt_title">CUELLO:</td>
  </tr>
    <tr>
    <td><div style="width:725px; line-height:20px; text-align:justify"><?php if(isset($_REQUEST["cuello"])){       
        if($_REQUEST["cuello"] != ""){
            echo $_REQUEST["cuello"];
        }else{
                echo "No hay descripcion";
         }
    }?></div></td>
  </tr>
  <tr>
    <td class="txt_title">CARDIOVASCULAR:</td>
  </tr>
    <tr>
    <td><div style="width:725px; line-height:20px; text-align:justify"><?php if(isset($_REQUEST["cardiovascular"])){
        if($_REQUEST["cardiovascular"] != ""){
            echo $_REQUEST["cardiovascular"];
        }else{
                echo "No hay descripcion";
         }
        }?></div></td>
  </tr>
  <tr>
    <td class="txt_title">RESPIRATORIO:</td>
  </tr>
    <tr>
    <td><div style="width:725px; line-height:20px; text-align:justify"><?php if(isset($_REQUEST["respiratorio"])){
        if($_REQUEST["respiratorio"] != ""){
            echo $_REQUEST["respiratorio"];
        }else{
                echo "No hay descripcion";
         }
    }?></div></td>
  </tr>
  <tr>
    <td class="txt_title">ABDOMEN:</td>
  </tr>
    <tr>
    <td><div style="width:725px; line-height:20px; text-align:justify"><?php if(isset($_REQUEST["abdomen"])){
        if($_REQUEST["abdomen"] != ""){
            echo $_REQUEST["abdomen"];
        }else{
                echo "No hay descripcion";
         }
    }?></div></td>
  </tr>
  <tr>
    <td class="txt_title">GENITALES:</td>
  </tr>
    <tr>
    <td><div style="width:725px; line-height:20px; text-align:justify"><?php if(isset($_REQUEST["genitales"])){
         if($_REQUEST["genitales"] != ""){
            echo $_REQUEST["genitales"];
        }else{
                echo "No hay descripcion";
         }
    }?></div></td>
  </tr>
  <tr>
    <td class="txt_title">ENDOCRINO:</td>
  </tr>
    <tr>
    <td><div style="width:725px; line-height:20px; text-align:justify"><?php if(isset($_REQUEST["endocrino"])){
        if($_REQUEST["endocrino"] != ""){
            echo $_REQUEST["endocrino"];
        }else{
                echo "No hay descripcion";
         } 
    }?></div></td>
  </tr>
  <tr>
    <td class="txt_title" bgcolor="#F5D0A9">10.SISTEMA OSEO</td>
  </tr>
  <tr>
    <td class="txt_title">CRANEO</td>
  </tr>
  <tr>
    <td><div style="width:725px; line-height:20px; text-align:justify"><?php if(isset($_REQUEST["craneo"])){
        if($_REQUEST["craneo"] != ""){
            echo $_REQUEST["craneo"];
        }else{
                echo "No hay descripcion";
         }
    }?></div></td>
  </tr>
  <tr>
    <td class="txt_title">COLUMNA VERTEBRAL</td>
  </tr>
  <tr>
    <td><div style="width:725px; line-height:20px; text-align:justify"><?php if(isset($_REQUEST["columna_vertebral"])){
        if($_REQUEST["columna_vertebral"] != ""){
            echo $_REQUEST["columna_vertebral"];
        }else{
                echo "No hay descripcion";
         }
    }?></div></td>
  </tr>
  <tr class="txt_title">
    <td>TORAX</td>
  </tr>
  <tr>
    <td><div style="width:725px; line-height:20px; text-align:justify"><?php if(isset($_REQUEST["torax"])){
        if($_REQUEST["torax"] != ""){
            echo $_REQUEST["torax"];
        }else{
                echo "No hay descripcion";
         }
    }?></div></td>
  </tr>
  <tr class="txt_title">
    <td>MIEMBROS SUPERIORES</td>
  </tr>
   <tr>
    <td><div style="width:725px; line-height:20px; text-align:justify"><?php if(isset($_REQUEST["miembros_superiores"])){
        if($_REQUEST["miembros_superiores"] != ""){
            echo $_REQUEST["miembros_superiores"];
        }else{
            echo "No hay descripcion";
         }
    }?></div></td>
  </tr>
  <tr class="txt_title">
    <td>MIEMBROS INFERIORES</td>
  </tr>
  <tr>
    <td><div style="width:725px; line-height:20px; text-align:justify"><?php if(isset($_REQUEST["miembros_inferiores"])){
         if($_REQUEST["miembros_inferiores"] != ""){
            echo $_REQUEST["miembros_inferiores"];
        }else{
            echo "No hay descripcion";
         }
    }?></div></td>
  </tr>
  <tr class="txt_title">
    <td>PELVIS</td>
  </tr>
  <tr>
    <td><div style="width:725px; line-height:20px; text-align:justify"><?php if(isset($_REQUEST["pelvis"])){
        if($_REQUEST["pelvis"] != ""){
            echo $_REQUEST["pelvis"];
        }else{
            echo "No hay descripcion";
         }
    }?></div></td>
  </tr>
</table>
<br />
<table width="100%" align="center" bordercolor="#CCCCCC" style="border-width:1px; border-style:solid; border-color:#CCC; padding:10px">
  <tr>
  <td bgcolor="#F5D0A9" class="txt_title">11.Muestras Tomadas de: 
<?php if(isset($_REQUEST["muestra_sangre"]) && $_REQUEST["muestra_sangre"]=="SI"){echo "Sangre.";}?>
<?php if(isset($_REQUEST["muestra_orina"]) && $_REQUEST["muestra_orina"]=="SI"){echo " Orina.";}?>
<?php if(isset($_REQUEST["muestra_humor"]) && $_REQUEST["muestra_humor"]=="SI"){echo " Humor vítreo.";}?>
<?php if(isset($_REQUEST["muestra_bilis"]) && $_REQUEST["muestra_bilis"]=="SI"){echo " Bilis.";}?>
<?php if(isset($_REQUEST["muestra_hueso"]) && $_REQUEST["muestra_hueso"]=="SI"){echo " Hueso.";}?>
<?php if(isset($_REQUEST["muestra_contenido"]) && $_REQUEST["muestra_contenido"]=="SI"){echo " Contenido Gastrico.";}?>
</td>
 </tr>
  <tr class="txt_title">
    <td>TEJIDOS</td>
  </tr>
  <tr>
    <td><div style="width:725px; line-height:20px; text-align:justify"><?php if(isset($_REQUEST["tejidos"])){
        if($_REQUEST["tejidos"] != ""){
            echo $_REQUEST["tejidos"];
        }else{
            echo "No hay descripcion";
         }
    }?></div></td>
  </tr>
<tr class="txt_title">
    <td>OTROS</td>
  </tr>
  <tr>
    <td><div style="width:725px; line-height:20px; text-align:justify"><?php if(isset($_REQUEST["otros_sistema_oseo"])){
        if($_REQUEST["otros_sistema_oseo"] != ""){
            echo $_REQUEST["otros_sistema_oseo"];
        }else{
            echo "No hay descripcion";
         }
    }?></div></td>
  </tr>
</table>
  <br />

<table width="100%" align="center" bordercolor="#CCCCCC" style="border-width:1px; border-style:solid; border-color:#CCC; padding:10px"> 
  <tr>
    <td colspan="2" bgcolor="#F5D0A9" class="txt_title">12. CAUSA DE MUERTE</td>
  </tr>
  <tr>
    <td width="3">I.a) </td>
    <td><div style="width:700" class="linea">&nbsp;
      <?php if(isset($_REQUEST["causa_a"])){echo $_REQUEST["causa_a"];}?>
    </div></td>
  </tr>
   <tr>
    <td>I.b) </td>
    <td><div style="width:700" class="linea">&nbsp;
      <?php if(isset($_REQUEST["causa_b"])){
        if($_REQUEST["causa_b"] != ""){
            echo $_REQUEST["causa_b"];
        }else{
            echo "N/D";
        }
      }?>
    </div></td>
   </tr>
  <tr>
    <td>I.c)</td>
    <td><div style="width:700" class="linea">&nbsp;
	<?php if(isset($_REQUEST["causa_c"])){
         if($_REQUEST["causa_c"] != ""){
            echo $_REQUEST["causa_c"];
        }else{
            echo "N/D";
        }
        }?></div></td>
  </tr>
  <tr>
    <td>I.d)</td>
    <td><div style="width:700" class="linea">&nbsp;
	<?php if(isset($_REQUEST["causa_d"])){
        if($_REQUEST["causa_d"] != ""){
            echo $_REQUEST["causa_d"];
        }else{
            echo "N/D";
        }
        }?></div></td>
  </tr>
   <tr>
    <td>II) </td>
    <td><div style="width:700" class="linea">&nbsp;
      <?php if(isset($_REQUEST["causa_dos"])){
        if($_REQUEST["causa_dos"] != ""){
            echo $_REQUEST["causa_dos"];
        }else{
            echo "N/D";
        }
      }?>
    </div></td>
   </tr>
</table>
<table width="100%" align="center" bordercolor="#CCCCCC" style="border-width:1px; border-style:solid; border-color:#CCC; padding:10px"> 
  <tr>
    <td class="txt_title">Manera de Muerte(D.P.V.M.L.)</td>
  </tr>
  <tr>
    <td><div style="width:725px; line-height:20px; text-align:justify">
	<?php if(isset($_REQUEST["manera_muerte_dpvml"])){echo $_REQUEST["manera_muerte_dpvml"];}?></div></td>
  </tr>
</table>
<br />
<table width="100%" align="center" bordercolor="#CCCCCC" style="border-width:1px; border-style:solid; border-color:#CCC; padding:10px"> 
  <tr>
    <td bgcolor="#F5D0A9" class="txt_title">13.EVALUACIONES ADICIONALES</td>
  </tr>
 <tr>
    <td class="txt_title">Descripcion de Estudio Dactiloscópico:</td>
  </tr>
  <tr>
    <td><div style="width:725px; line-height:20px; text-align:justify">
	<?php if(isset($_REQUEST["des_estudio_dactiloscopico"])){
           if($_REQUEST["des_estudio_dactiloscopico"] != ""){
            echo $_REQUEST["des_estudio_dactiloscopico"];
        }else{
            echo "No hay descripcion";
         } 
        }?></div></td>
  </tr>
   <tr>
    <td class="txt_title" >Descripcion de Estudio Radiologico:</td>
  </tr>
  <tr>
    <td><div style="width:725px; line-height:20px; text-align:justify">
	<?php if(isset($_REQUEST["des_estudio_radiologico"])){
        if($_REQUEST["des_estudio_radiologico"] != ""){
            echo $_REQUEST["des_estudio_radiologico"];
        }else{
            echo "No hay descripcion";
         } 
        }?></div></td>
  </tr>
   <tr>
    <td class="txt_title">Descripcion de Estudio Odontológico:</td>
  </tr>
  <tr>
    <td><div style="width:725px; line-height:20px; text-align:justify">
	<?php if(isset($_REQUEST["des_estudio_odontologico"])){
        if($_REQUEST["des_estudio_odontologico"] != ""){
            echo $_REQUEST["des_estudio_odontologico"];
        }else{
            echo "No hay descripcion";
        }
        }?></div></td>
  </tr>
   <tr>
    <td class="txt_title">Descripcion de Estudio Histopatológico:</td>
  </tr>
  <tr>
    <td><div style="width:725px; line-height:20px; text-align:justify">
	<?php if(isset($_REQUEST["des_estudio_histopatologico"])){
        if($_REQUEST["des_estudio_histopatologico"] != ""){
            echo $_REQUEST["des_estudio_histopatologico"];
        }else{
            echo "No hay descripcion";
        }
        }?></div></td>
  </tr>
</table>
</page>
