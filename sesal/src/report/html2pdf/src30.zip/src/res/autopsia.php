<style type="text/Css">
<!--
#body{
	font-family:Arial, Helvetica, sans-serif;
	font-size:12px;
	font-weight:400;
	color:#000;
}
.small_font{
	font-size:8px;
	color:#666;
}
.bg_img{
	background-color:#F5ECCE;
	border-radius:5px;
	height:20px;
}
.linea{
	border-width:1px;
	border-bottom:solid;
	border-color:#CCC;
}
.txt_title{
	font-size:16px;
	font-weight:bold;
}
.txt_titleheader{
	font-size:13px;
	font-weight:bold;
	color:#333;
}
.txt_titleheader_cotenido{
	font-size:10px;
}
.tr{
     height:50px;
     text-align:left;
}
.table{
	border-width:1px;
	border-style:solid;
	border-color:#FAFAFA;
	padding:1px;
	border-radius:5px;
}
-->
</style>
<page backtop="30mm" backimg="./res/img/logos/fondo.jpg" backbottom="30mm" backleft="2mm" backright="2mm" pagegroup="new" style="font-size: 12px; text-transform: uppercase;">
<page_header>
<table border="0" align="center" cellpadding="10" cellspacing="0">
  <tr>
    <td rowspan="2"><img src="./res/img/logos/mp.jpg" /></td>
    <td rowspan="2" align="center"><img src="./res/img/logos/logo_fondo_small.jpg" /></td>
    <td colspan="2" align="right" class="txt_titleheader">DIRECCIÓN GENERAL DE MEDICINA FORENSE<br/>DEPARTAMENTO DE PATOLOGÍA FORENSE<br/>
    <strong>HOJA DE TRABAJO GENERAL PARA AUTOPSIA MÉDICO LEGAL</strong></td>
  </tr>
  <tr>
    <td>Vigente desde 2015.03.20Vigente </td>
    <td align="right">PF-F117-1 V04 B06</td>
  </tr>
  <tr>
    <td colspan="4" valign="bottom" class="linea" height="10px"></td>
  </tr>
  <tr bgcolor="#E9E9E9">
    <td class="txt_titleheader_cotenido">Redactado por: L. Cruz, C. Martínez, E. López</td>
    <td align="right" class="txt_titleheader_cotenido" width="120">Editado por: T. Calidonio</td>
    <td align="right" class="txt_titleheader_cotenido">Revisado por: I. Raudales</td>
    <td align="right" class="txt_titleheader_cotenido">Aprobado por: I. Raudales</td>
  </tr>
  <tr>
    <td colspan="4" align="right"><p style="margin-right:-20px">Página [[page_cu]] de [[page_nb]]</p></td>
  </tr>
</table>
</page_header>
<page_footer>
  <div><img src="./res/img/levantamiento/footer.jpg" ></div>  
</page_footer>
  <table width="100%" align="center" cellpadding="10" cellspacing="5"  class="table">
    <tr>
      <td colspan="11" bgcolor="#F5F6CE" class="txt_title">1. Datos de Autopsia</td>
    </tr>
    <tr>
      <td>Autopsia  N°:</td>
      <td align="center" class="linea">
        <?php if(isset($_REQUEST["Aanio"])){echo $_REQUEST["Aanio"];}?>
      </td>
      <td align="center" class="linea">
        <?php if(isset($_REQUEST["Asede"])){echo $_REQUEST["Asede"];}?>
      </td>
      <td align="center" class="linea">
        <?php if(isset($_REQUEST["Adep"])){echo $_REQUEST["Adep"];}?>
      </td>
      <td align="center" class="linea">
        <?php if(isset($_REQUEST["Acorr"])){echo $_REQUEST["Acorr"];}?>
      </td>
      <td>&nbsp;</td>
      <td>Levantamiento N°:</td>
      <td align="center" class="linea">
        <?php if(isset($_REQUEST["Lanio"])){echo $_REQUEST["Lanio"];}?>
      </td>
      <td align="center" class="linea">
        <?php if(isset($_REQUEST["Lsede"])){echo $_REQUEST["Lsede"];}?>
      </td>
      <td align="center" class="linea">
        <?php if(isset($_REQUEST["Ldep"])){echo $_REQUEST["Ldep"];}?>
      </td>
      <td align="center" class="linea">
        <?php if(isset($_REQUEST["Lcorr"])){echo $_REQUEST["Lcorr"];}?>
      </td>
    </tr>
    <tr class="small_font">
      <td align="center" valign="top">&nbsp;</td>
      <td align="center" valign="top">AÑO</td>
      <td align="center" valign="top">SEDE</td>
      <td align="center" valign="top">DEPTO</td>
      <td align="center" valign="top">CORRELATIVO</td>
      <td align="center" valign="top">&nbsp;</td>
      <td align="center" valign="top">&nbsp;</td>
      <td align="center" valign="top">AÑO</td>
      <td align="center" valign="top">SEDE</td>
      <td align="center" valign="top">DEPTO</td>
      <td align="center" valign="top">CORRELATIVO</td>
    </tr>
    <tr>
      <td colspan="6">Médico  Autopsiante:<div class="linea" style="width:235px">&nbsp;<?php if(isset($_REQUEST["medicoaut"])){echo $_REQUEST["medicoaut"];}?></div></td>
      <td colspan="5"> No de Colegiación:<div class="linea" style="width:190px">&nbsp;<?php if(isset($_REQUEST["ncolegiacion"])){echo $_REQUEST["ncolegiacion"];}?></div></td>
    </tr>
    <tr>
      <td colspan="6">Disector:<div class="linea" style="width:310px">&nbsp;<?php if(isset($_REQUEST["medicoDIC"])){echo $_REQUEST["medicoDIC"];}?></div></td>
      <td colspan="5"> Fotógrafo:<div class="linea" style="width:235px">&nbsp;<?php if(isset($_REQUEST["fotografo"])){echo $_REQUEST["fotografo"];}?></div></td>
    </tr>
    <tr>
      <td colspan="11">Fiscal que autorizo la autopsia:<div class="linea" style="width:480px">&nbsp;<?php if(isset($_REQUEST["fiscalaut"])){echo $_REQUEST["fiscalaut"];}?></div></td>
    </tr>
    <tr>
      <td colspan="11">Fecha de la Muerte:<div class="linea" style="width:565px">&nbsp;<?php if(isset($_REQUEST["fechaMuerte"])){echo $_REQUEST["fechaMuerte"];}?></div></td>
    </tr>
    <tr>
      <td colspan="11">Fecha de la autopsia:<div class="linea" style="width:554px">&nbsp;<?php if(isset($_REQUEST["fechaAutopsia"])){echo $_REQUEST["fechaAutopsia"];}?></div></td>
    </tr>
    <tr>
      <td colspan="6">Fecha de entrega:<div class="linea" style="width:200px">&nbsp;<?php if(isset($_REQUEST["fechaEntrega"])){echo $_REQUEST["fechaEntrega"];}?></div></td>
      <td colspan="5">Receptor(a):<div class="linea" style="width:238px">&nbsp;<?php if(isset($_REQUEST["receptor"])){echo $_REQUEST["receptor"];}?></div></td>
    </tr>
  </table>
<br />
<table width="100%" align="center" cellpadding="10" cellspacing="5" class="table">
    <tr>
      <td colspan="4" bgcolor="#F5F6CE" class="txt_title"><div class="txt_title" style="width:725px;">2. DATOS GENERALES</div></td>
    </tr>
    <tr>
      <td colspan="4">1.1.Nombre:
        <div class="linea" style="width:640px">&nbsp;<?php if(isset($_REQUEST["dgnombre"])){echo $_REQUEST["dgnombre"];}?></div></td>
    </tr>
    <tr>
      <td>1.2.Edad:
        <div class="linea" style="width:20px">&nbsp;<?php if(isset($_REQUEST["dgedad"])){echo $_REQUEST["dgedad"];}?></div></td>
      <td align="left">1.3.Rango Edad:
      <div class="linea" style="width:100px">&nbsp;<?php if(isset($_REQUEST["dgrangoEdad"])){echo $_REQUEST["dgrangoEdad"];}?></div></td>
      <td align="left">1.4.Sexo:
      <div class="linea" style="width:100px">&nbsp;<?php if(isset($_REQUEST["dgSexo"])){echo $_REQUEST["dgSexo"];}?></div></td>
      <td align="left">1.5.Raza:
      <div class="linea" style="width:110px">&nbsp;<?php if(isset($_REQUEST["dgRaza"])){echo $_REQUEST["dgRaza"];}?></div></td>
    </tr>
    <tr>
      <td colspan="4">1.6.Otros:<div class="linea" style="width:640px">&nbsp;<?php if(isset($_REQUEST["dgdescripcion"])){echo $_REQUEST["dgdescripcion"];}?></div></td>
    </tr>
  </table>
  <br />
  <table width="100%" align="center" cellpadding="10" cellspacing="5" class="table">
    <tr>
      <td colspan="2" bgcolor="#F5F6CE"><div class="txt_title" style="width:725px;">3.HISTORIA MÉDICO LEGAL:</div></td>
    </tr>
    <tr>
      <td colspan="2">
      <div style="width:720px; line-height:20px; text-align:justify"><?php if(isset($_REQUEST["HM"])){echo $_REQUEST["HM"];}?></div>
      </td>
    </tr>
    <tr>
      <td colspan="2">Ropa: <div style="width:650px" class="linea">&nbsp;<?php if(isset($_REQUEST["HropasPA"])){
	if($_REQUEST["HropasPA"]=="A"){
		echo "Ausente";
	}else if($_REQUEST["HropasPA"]=="P"){
		echo "Presente";	
	}		
	if($_REQUEST["HropasIR"]=="I"){
		echo " Integra";
	}else if($_REQUEST["HropasPA"]=="R"){
		echo " Rota";	
	}
	if($_REQUEST["HropasS"]=="S"){
		echo " Sucia";
	}
	if($_REQUEST["HropasM"]=="S"){
		echo " Con Manchas";
	}
	}?></div></td>
    </tr>
    <tr>
      <td colspan="2">Descripcion de la Ropa:
      </td>
    </tr>
    <tr>
      <td colspan="2">
      <div style="width:720px; line-height:20px; text-align:justify"><?php if(isset($_REQUEST["HropaD"])){echo $_REQUEST["HropaD"];}?></div>
      </td>
    </tr>
     <tr>
      <td colspan="2">Descripcion de las pertenencias:
      </td>
    </tr>
    <tr>
      <td colspan="2">
      <div style="width:720px; line-height:20px; text-align:justify"><?php if(isset($_REQUEST["HropaDP"])){echo $_REQUEST["HropaDP"];}?></div>
      </td>
    </tr>
    <tr>
      <td colspan="2">Radiografias realizadas: <div style="width:510px" class="linea">&nbsp;
	  <?php if(isset($_REQUEST["HradioC"])){
	 if($_REQUEST["HradioC"]=="C"){
		 echo "Craneo";}
	 if($_REQUEST["HradioU"]=="U"){
		  echo " Cuello";}
	if($_REQUEST["HradioT"]=="T"){
			echo " Torax";}
	if($_REQUEST["HradioA"]=="A"){
			echo " Abdomen";}
	if($_REQUEST["HradioE"]=="E"){
			echo " Extremidades";}
	}?></div>
    </td>
    </tr>
    <tr>
      <td>ODONTOGRAMA: <div style="width:200px" class="linea">&nbsp;<?php if(isset($_REQUEST["Hodo"])){
	if($_REQUEST["Hodo"]=="S"){
		echo "SI";		
	}else if($_REQUEST["Hodo"]=="N"){
		echo $_REQUEST["NO"];
	}
	}?></div></td>
      <td>NECRODACTILOSCOPÍA: <div style="width:190px" class="linea">&nbsp;<?php if(isset($_REQUEST["var"])){
	if($_REQUEST["Hnec"]=="S"){
		echo "SI";		
	}else if($_REQUEST["Hnec"]=="N"){
		echo $_REQUEST["NO"];
	}
	}?></div></td>
    </tr>
    <tr>
      <td colspan="2">FENÓMENOS CADAVÉRICOS:</td>
    </tr>
    <tr>
      <td colspan="2">2.1.1. PUPILAS:<div style="width:590px" class="linea">&nbsp;<?php if(isset($_REQUEST["FPu"])){
	if($_REQUEST["FPu"]=="N"){
		echo "Normal";		
	}else if($_REQUEST["FPu"]=="M"){
		echo " Miosis";
	}else if($_REQUEST["FPu"]=="I"){
		echo " Midrasis";
	}
	}?></div></td>
    </tr>
    <tr>
      <td colspan="2">CÓRNEAS:<div style="width:600px" class="linea">&nbsp;<?php if(isset($_REQUEST["FCo"])){
	if($_REQUEST["FCo"]=="N"){
		echo " Transparente";		
	}else if($_REQUEST["FCo"]=="M"){
		echo " Opacas";
	}
	}?></div></td>
    </tr>
    <tr>
      <td colspan="2">2.1.2. TENSIÓN OCULAR: <div style="width:510px" class="linea">&nbsp;<?php if(isset($_REQUEST["FTO"])){
	if($_REQUEST["FTO"]=="N"){
		echo " Normal";		
	}else if($_REQUEST["FTO"]=="H"){
		echo " Hipertonico";
	}	
}?></div></td>
    </tr>
    <tr>
      <td colspan="2">2.1.3. Signo de Sommer: <div style="width:510px" class="linea">&nbsp;<?php if(isset($_REQUEST["FSS"])){
	if($_REQUEST["FSS"]=="P"){
		echo " Presente";		
	}else if($_REQUEST["FSS"]=="A"){
		echo " Ausente";
	}	
}?></div></td>
    </tr>
    <tr>
      <td colspan="2">2.1.4. Stenon Louis: <div style="width:510px" class="linea">&nbsp;<?php if(isset($_REQUEST["FSL"])){
	if($_REQUEST["FSL"]=="P"){
		echo " Presente";		
	}else if($_REQUEST["FSL"]=="A"){
		echo " Ausente";
	}
	}?></div></td>
    </tr>
    <tr>
      <td colspan="2">Observaciones:</td>
    </tr>
    <tr>
      <td colspan="2">
      <div style="width:720px; line-height:20px; text-align:justify"><?php if(isset($_REQUEST["FOSL"])){echo $_REQUEST["FOSL"];}?></div>
      </td>
    </tr>
    <tr>
      <td colspan="2">2.1.5. LIVIDECES:<div style="width:510px" class="linea">&nbsp;<?php if(isset($_REQUEST["FLI"])){
	if($_REQUEST["FLI"]=="P"){
		echo " Presente";		
	}else if($_REQUEST["FLI"]=="A"){
		echo " Ausente";
	}else if($_REQUEST["FLI"]=="I"){
		echo " Incipientes";
	}
}?></div></td>
    </tr>
    <tr>
      <td colspan="2">Modificable:<div style="width:510px" class="linea">&nbsp;<?php if(isset($_REQUEST["FMO"])){
	if($_REQUEST["FMO"]=="S"){
		echo " SI";		
	}else if($_REQUEST["FMO"]=="N"){
		echo " NO";
	}
}?></div></td>
    </tr>
    <tr>
      <td colspan="2">Descripción de las livideces (localización, forma, tamaÑo):</td>
    </tr>
     <tr>
      <td colspan="2">
      <div style="width:720px; line-height:20px; text-align:justify"><?php if(isset($_REQUEST["FDL"])){echo $_REQUEST["FDL"];}?></div>
      </td>
    </tr>
    <tr>
      <td colspan="2">2.2. RIGIDEZ:<div style="width:510px" class="linea">&nbsp;<?php if(isset($_REQUEST["FRI"])){
	if($_REQUEST["FRI"]=="C"){
		echo " Completa";		
	}else if($_REQUEST["FRI"]=="I"){
		echo " Incompleta";
	}
	if($_REQUEST["FRM"]=="M"){
		echo " Mandibula";		
	}else if($_REQUEST["FRM"]=="C"){
		echo " Cuello";
	}else if($_REQUEST["FRM"]=="S"){
		echo " Miembro Superior";
	}else if($_REQUEST["FRM"]=="I"){
		echo " Miembro Inferior";
	}
	
	}?></div></td>
    </tr>
    <tr>
      <td valign="top">2.3. TEMPERATURA:</td>
      <td>
      <table border="0" cellpadding="0" cellspacing="0" align="left" width="100%">
      <tr><td>Conserva calor: <div style="width:50px" class="linea">&nbsp;<?php if(isset($_REQUEST["FCC"])){
	if($_REQUEST["FCC"]=="S"){
		echo " SI";		
	}else if($_REQUEST["FCC"]=="N"){
		echo " NO";
	}
}?></div></td>
      <td>&nbsp;&nbsp;&nbsp;&nbsp;Enfriamiento: <div style="width:50px" class="linea">&nbsp;<?php if(isset($_REQUEST["FNE"])){
	if($_REQUEST["FNE"]=="A"){
		echo " +";		
	}else if($_REQUEST["FNE"]=="B"){
		echo " ++";
	}else if($_REQUEST["FNE"]=="C"){
		echo " +++";
	}	
}?></div></td></tr></table>
      </td>
    </tr>
    <tr>
      <td colspan="2">2.4.Fenómenos cadavéricos modificados por causa externa:<div style="width:290px" class="linea">&nbsp;<?php if(isset($_REQUEST["FCE"])){
	if($_REQUEST["FCE"]=="R"){
		echo " Refrigeración";		
	}else if($_REQUEST["FCE"]=="T"){
		echo " Termicos (Sol, fuego, etc.)";
	}else if($_REQUEST["FCE"]=="A"){
		echo " Agua";
	}	
	}?></div></td>
    </tr>
   <tr>
      <td colspan="2">2.5.Fenómenos de conservación cadavérica:<div style="width:400px" class="linea">&nbsp;<?php if(isset($_REQUEST["var"])){echo $_REQUEST["var"];}?></div></td>
    </tr>
    <tr>
      <td colspan="2">2.6.ANTROPOFAGIA:
	</td>
    </tr>
    <tr>
      <td colspan="2">
	 <div style="width:720px; line-height:20px; text-align:justify"><?php if(isset($_REQUEST["FANT"])){echo $_REQUEST["FANT"];}?></div>
      </td>
    </tr>
    <tr>
      <td colspan="2">2.7.INTERVALO POSTMÓRTEM:</td>
    </tr>
 <tr>
      <td colspan="2">
	 <div style="width:720px; line-height:20px; text-align:justify"><?php if(isset($_REQUEST["FINT"])){echo $_REQUEST["FINT"];}?></div>
      </td>
    </tr>
  </table>
  <br />
   <table width="100%" align="center" cellpadding="10" cellspacing="5" class="table">
   <tr>
   <td bgcolor="#F5F6CE"><div class="txt_title" style="width:720px;">3. EXAMEN EXTERNO</div></td>
   </tr>
   <tr>
     <td><table border="0" cellpadding="0" cellspacing="0" width="100%"><tr><td>3.1. CADÁVER: <div style="width:300px" class="linea">&nbsp;<?php if(isset($_REQUEST["vcadaverCI"])){
	if($_REQUEST["vcadaverCI"]=="C"){
		echo " Completa";		
	}else if($_REQUEST["vcadaverCI"]=="I"){
		echo " Incompleta";
	}else if($_REQUEST["vcadaverCI"]=="P"){
		echo " Piezas Anatómicas";
	}else if($_REQUEST["vcadaverCI"]=="E"){
		echo " Áreas Esqueletizadas";
	}
	}?></div></td><td>&nbsp;&nbsp;Zonas: <div style="width:100px" class="linea">&nbsp;<?php if(isset($_REQUEST["zona"])){echo $_REQUEST["zona"];}?></div></td></tr></table>
    
    </td>
     </tr>
   <tr>
     <td>3.2. CONDICIONES DEL CUERPO:<div style="width:500px" class="linea">&nbsp;<?php if(isset($_REQUEST["vcondicion"])){echo $_REQUEST["vcondicion"];}?></div></td>
   </tr>
   <tr>
     <td>3.3. CADÁVER  CORRESPONDE:<div style="width:500px" class="linea">&nbsp;<?php if(isset($_REQUEST["dgCorresponde"])){echo $_REQUEST["dgCorresponde"];}?></div></td>
   </tr>
   <tr>
     <td>3.4. CARACTERÍSTICAS INDIVIDUALIZANTES (ALTERACIONES)</td>
   </tr>
   <tr>
     <td>3.4.1. Tatuajes:<div style="width:400px" class="linea">&nbsp;<?php if(isset($_REQUEST["vtatuaje"])){echo $_REQUEST["vtatuaje"];}?></div></td>
   </tr>
   <tr>
     <td>3.4.2. Cicatrices:<div style="width:400px" class="linea">&nbsp;<?php if(isset($_REQUEST["vcicatrices"])){echo $_REQUEST["vcicatrices"];}?></div></td>
   </tr>
   <tr>
     <td>3.4.3. Lunares:<div style="width:400px" class="linea">&nbsp;<?php if(isset($_REQUEST["vlunares"])){echo $_REQUEST["vlunares"];}?></div></td>
   </tr>
   <tr>
     <td>3.4.4. Marcas de nacimiento:<div style="width:400px" class="linea">&nbsp;<?php if(isset($_REQUEST["vmarcas"])){echo $_REQUEST["vmarcas"];}?></div></td>
   </tr>
   <tr>
     <td>3.4.5. Verrugas:<div style="width:400px" class="linea">&nbsp;<?php if(isset($_REQUEST["vverrugas"])){echo $_REQUEST["vverrugas"];}?></div></td>
   </tr>
   <tr>
     <td>3.4.6. Cirugías:<div style="width:400px" class="linea">&nbsp;<?php if(isset($_REQUEST["vcirugias"])){echo $_REQUEST["vcirugias"];}?></div></td>
   </tr>
   <tr>
     <td>3.4.7. Traumas:<div style="width:400px" class="linea">&nbsp;<?php if(isset($_REQUEST["vtraumas"])){echo $_REQUEST["vtraumas"];}?></div></td>
   </tr>
   <tr>
     <td>3.4.8. Prótesis:<div style="width:400px" class="linea">&nbsp;<?php if(isset($_REQUEST["vprotesis"])){echo $_REQUEST["vprotesis"];}?></div></td>
   </tr>
   <tr>
     <td>3.4.9. Amputaciones:<div style="width:400px" class="linea">&nbsp;<?php if(isset($_REQUEST["vamputaciones"])){echo $_REQUEST["vamputaciones"];}?></div></td>
   </tr>
   <tr>
     <td>3.4.10. Deformidades:<div style="width:400px" class="linea">&nbsp;<?php if(isset($_REQUEST["vdeformidades"])){echo $_REQUEST["vdeformidades"];}?></div></td>
   </tr>
   <tr>
     <td>3.4.11. Fracturas:<div style="width:400px" class="linea">&nbsp;<?php if(isset($_REQUEST["vfracturas"])){echo $_REQUEST["vfracturas"];}?></div></td>
   </tr>
   <tr>
     <td>3.4.12. Perforaciones/Percing:<div style="width:400px" class="linea">&nbsp;<?php if(isset($_REQUEST["vperforaciones"])){echo $_REQUEST["vperforaciones"];}?></div></td>
   </tr>
   <tr>
     <td>3.4.13. Otras:<div style="width:400px" class="linea">&nbsp;<?php if(isset($_REQUEST["votros"])){echo $_REQUEST["votros"];}?></div></td>
   </tr>
   <tr>
     <td>3.5. Particularidades del caso</td>
   </tr>
   <tr>
     <td>3.5.1. Empaquetado<div style="width:400px" class="linea">&nbsp;<?php if(isset($_REQUEST["var"])){echo $_REQUEST["var"];}?></div></td>
   </tr>
   <tr>
     <td>3.5.2. Envuelto en:<div style="width:400px" class="linea">&nbsp;<?php if(isset($_REQUEST["var"])){echo $_REQUEST["var"];}?></div></td>
   </tr>
   <tr>
     <td>3.5.3. Otro:<div style="width:400px" class="linea">&nbsp;<?php if(isset($_REQUEST["var"])){echo $_REQUEST["var"];}?></div></td>
   </tr>
   <tr>
     <td>3.5.4. Atadura: SI Describa:<div style="width:400px" class="linea">&nbsp;<?php if(isset($_REQUEST["var"])){echo $_REQUEST["var"];}?></div></td>
   </tr>
   <tr>
     <td>3.5.5. Descuartizado/ Desmembrado:<div style="width:300px" class="linea">&nbsp;<?php if(isset($_REQUEST["var"])){echo $_REQUEST["var"];}?></div></td>
   </tr>
   <tr>
     <td>3.5.6. Descripción del corte<div style="width:200px" class="linea">&nbsp;<?php if(isset($_REQUEST["var"])){echo $_REQUEST["var"];}?></div></td>
   </tr>
   <tr>
     <td>3.5.7. Otro:<div style="width:400px" class="linea">&nbsp;<?php if(isset($_REQUEST["var"])){echo $_REQUEST["var"];}?></div></td>
   </tr>
   <tr>
     <td>3.6. ROPAS:</td>
   </tr>
   <tr>
     <td>
     <div style="width:700px; line-height:20px; text-align:justify"><?php if(isset($_REQUEST["var"])){echo $_REQUEST["var"];}?></div>
      </td>
   </tr>
   <tr>
     <td>3.7. PERTENENCIAS</td>
   </tr>
   <tr>
     <td><div style="width:700px; line-height:20px; text-align:justify"><?php if(isset($_REQUEST["var"])){echo $_REQUEST["var"];}?></div></td>
   </tr>
   <tr>
     <td>3.8. COMPLEXIÓN:<div style="width:500px" class="linea">&nbsp;<?php if(isset($_REQUEST["dgComplexion"])){echo $_REQUEST["dgComplexion"];}?></div></td>
   </tr>
   <tr>
     <td><table border="0" cellpadding="0" cellspacing="0" width="100%">
     <tr><td>Talla (cm):<div style="width:60px" class="linea">&nbsp;<?php if(isset($_REQUEST["dgComplexionTalla"])){echo $_REQUEST["dgComplexionTalla"];}?></div></td>
     <td>Peso (Kg):<div style="width:60px" class="linea">&nbsp;<?php if(isset($_REQUEST["dgComplexionPeso"])){echo $_REQUEST["dgComplexionPeso"];}?>      </div></td>
      <td>IMC (Kg/m):<div style="width:60px" class="linea">&nbsp;<?php if(isset($_REQUEST["dgComplexionIMC"])){echo $_REQUEST["dgComplexionIMC"];}?>       </div></td>
      <td>PC:<div style="width:60px" class="linea">&nbsp;<?php if(isset($_REQUEST["dgComplexionPC"])){echo $_REQUEST["dgComplexionPC"];}?>
      </div></td>
      <td>PT:<div style="width:60px" class="linea">&nbsp;<?php if(isset($_REQUEST["dgComplexionPT"])){echo $_REQUEST["dgComplexionPT"];}?>
      </div></td>
      <td>PA:<div style="width:60px" class="linea">&nbsp;<?php if(isset($_REQUEST["dgComplexionPA"])){echo $_REQUEST["dgComplexionPA"];}?>
      </div></td></tr></table>
     </td>
     </tr>
   <tr>
     <td>3.9. PIEL:<div style="width:500px" class="linea">&nbsp;<?php if(isset($_REQUEST["dgPiel"])){echo $_REQUEST["dgPiel"];}?></div></td>
   </tr>
   <tr>
     <td>3.9.1. Alteraciones:<div style="width:400px" class="linea">&nbsp;<?php if(isset($_REQUEST["var"])){echo $_REQUEST["var"];}?></div></td>
   </tr>
   <tr>
     <td>DESCRIPCIÓN:<div style="width:500px" class="linea">&nbsp;<?php if(isset($_REQUEST["var"])){echo $_REQUEST["var"];}?></div></td>
   </tr>
   <tr>
     <td>3.10. UÑAS:<div style="width:500px" class="linea">&nbsp;<?php if(isset($_REQUEST["objUnas"])){echo $_REQUEST["objUnas"];}?></div></td>
   </tr>
   <tr>
     <td>3.11. CABEZA:<div style="width:500px" class="linea">&nbsp; 
	<?php if(isset($_REQUEST["dgCabeza"])){
	if($_REQUEST["dgCabeza"]=="S"){
		echo " Simétrica";		
	}else if($_REQUEST["dgCabeza"]=="A"){
		echo " Asimétrica";
	}
}?>
 </div>
 </td></tr>
 <tr>
 <td>
 DESCRIPCIÓN &nbsp;<?php if(isset($_REQUEST["dgCabezaD"])){echo $_REQUEST["dgCabezaD"];}?>
 </td>
   </tr>
   <tr>
     <td>3.11.1. Cara: <div style="width:500px" class="linea">&nbsp;<?php if(isset($_REQUEST["dgCara"])){
	if($_REQUEST["dgCara"]=="S"){
		echo " Simétrica";		
	}else if($_REQUEST["dgCara"]=="A"){
		echo " Asimétrica";
	}
}?></div></td></tr>
<tr><td>
DESCRIPCIÓN:&nbsp;<?php if(isset($_REQUEST["dgCaraD"])){echo $_REQUEST["dgCaraD"];}?>
</td></tr>
   <tr>
     <td>3.11.2. Cabello:<div style="width:600px" class="linea">&nbsp;<?php if(isset($_REQUEST["dgCabelloNegro"])){
	if($_REQUEST["dgCabelloNegro"]=="S"){echo "Negro, ";}
	if($_REQUEST["dgCabelloCafe"]=="S"){echo "Cafe, ";}
	if($_REQUEST["dgCabelloCastanio"]=="S"){echo "CastaÑo, ";}
	if($_REQUEST["dgCabelloRubio"]=="S"){echo "Rubio, ";}
	if($_REQUEST["dgCabelloRojizo"]=="S"){echo "Rojizo, ";}
	if($_REQUEST["dgCabelloCanoso"]=="S"){echo "Canoso, ";}
	if($_REQUEST["dgCabelloEntrecano"]=="S"){echo "Entrecano, ";}
	if($_REQUEST["dgCabelloTenido"]=="S"){echo "TeÑido, ";}
	if($_REQUEST["dgCabelloCorto"]=="S"){echo "Corto, ";}
	if($_REQUEST["dgCabelloMedio"]=="S"){echo "Medio, ";}
	if($_REQUEST["dgCabelloLargo"]=="S"){echo "Largo, ";}
	if($_REQUEST["dgCabelloRasurado"]=="S"){echo "Rasurado, ";}
	if($_REQUEST["dgCabelloLacio"]=="S"){echo "Lacio, ";}
	if($_REQUEST["dgCabelloOndulado"]=="S"){echo "Ondulado, ";}
	if($_REQUEST["dgCabelloCrespo"]=="S"){echo "Crespo, ";}
	if($_REQUEST["dgCabelloTotal"]=="S"){echo "Alopecia Total, ";}
	if($_REQUEST["dgCabelloParcial"]=="S"){echo "Alopecia Parcial. ";}

}?></div></td></tr>
<tr><td>
<table border="0" cellpadding="0" cellspacing="0">
<tr><td>Zona:<div style="width:300px" class="linea">&nbsp;<?php if(isset($_REQUEST["dgCabelloD"])){echo $_REQUEST["dgCabelloD"];}?></div></td><td>
Longitud(cm):<div style="width:100px" class="linea">&nbsp;<?php if(isset($_REQUEST["var"])){echo $_REQUEST["var"];}?></div></td></tr></table>
</td>
   </tr>
   <tr>
     <td>3.11.3. Pabellon auricular: <div style="width:500px" class="linea">&nbsp;<?php if(isset($_REQUEST["dgPabellon"])){
	if($_REQUEST["dgPabellon"]=="S"){echo "Simétrica";}
	else if($_REQUEST["dgPabellon"]=="A"){echo "Asimetrica";}
	}?></div></td></tr>
    <tr><td>
    DESCRIPCIÓN:&nbsp;<?php if(isset($_REQUEST["dgPabellonD"])){echo $_REQUEST["dgPabellonD"];}?></td>
   </tr>
   <tr>
     <td>Nivel de implantación: <div style="width:500px" class="linea">&nbsp;<?php if(isset($_REQUEST["dgPabellonDI"])){echo $_REQUEST["dgPabellonDI"];}?></div></td>
   </tr>
   <tr>
     <td>3.11.4. Ojos:<div style="width:500px" class="linea">&nbsp;<?php if(isset($_REQUEST["dgOjoCompleto"])){
	if($_REQUEST["dgOjoCompleto"]=="S"){
			echo "Completos: ";
		if($_REQUEST["dgOjoS"]=="S"){
			echo "SI. ";
		}else if($_REQUEST["dgOjoS"]=="N"){
			echo "NO. ";
		}//fin de else if
	}else{ echo "NO Completos ";}
	
	}?>
	<?php if(isset($_REQUEST["dgOjoNegros"])){
	if($_REQUEST["dgOjoNegros"]=="S"){echo "Negros, ";}
	if($_REQUEST["dgOjoCafe"]=="S"){echo "Cafes, ";}
	if($_REQUEST["dgOjoAzul"]=="S"){echo "Azules, ";}
	if($_REQUEST["dgOjoVerde"]=="S"){echo "Verdes, ";}
	if($_REQUEST["dgOjoMiel"]=="S"){echo "Miel, ";}
	if($_REQUEST["dgOjoGris"]=="S"){echo "Grises, ";}
	if($_REQUEST["dgOjoCatarata"]=="S"){echo "Catarata, ";}
	if($_REQUEST["dgOjoHalo"]=="S"){echo "Halo Senil, ";}
	}?></div>	
	</td>
   </tr>
   <tr>
   <td>
   <div style="width:720px; line-height:20px; text-align:justify">DESCRIPCIÓN: &nbsp;<?php if(isset($_REQUEST["dgOjoD"])){echo $_REQUEST["dgOjoD"];}?></div></td>
   </tr>
   <tr>
     <td>3.11.5. Nariz: <div style="width:500px" class="linea">&nbsp;<?php if(isset($_REQUEST["dgNarizL"])){
	if($_REQUEST["dgNarizL"]=="S"){echo "Larga, ";}
	if($_REQUEST["dgNarizC"]=="S"){echo "Corta, ";}
	if($_REQUEST["dgNarizAN"]=="S"){echo "Ancha, ";}
	if($_REQUEST["dgNarizAG"]=="S"){echo "AguileÑa, ";}
	if($_REQUEST["dgNarizA"]=="S"){echo "Afilada, ";}
	if($_REQUEST["dgNarizS"]=="S"){echo "Simetrica";
	}else if($_REQUEST["dgNarizS"]=="A"){echo "Asimetrica.";}	
}?></div></td>
   </tr>
   <tr>
     <td>3.11.6. Boca:<div style="width:500px" class="linea">&nbsp;<?php if(isset($_REQUEST["dgBocaT"])){
	if($_REQUEST["dgBocaT"]=="P"){echo "PequeÑa, ";}
	if($_REQUEST["dgBocaT"]=="M"){echo "Mediana, ";}
	if($_REQUEST["dgBocaT"]=="G"){echo "Grande. ";}
	if($_REQUEST["dgBocaS"]=="S"){echo "Simetrica";
	}else if($_REQUEST["dgBocaS"]=="A"){echo "Asimetrica.";}
	}?></div></td>
   </tr>
   <tr>
     <td>3.11.7. Labios: <div style="width:500px" class="linea">&nbsp;<?php if(isset($_REQUEST["dgLabioD"])){
	if($_REQUEST["dgLabioD"]=="S"){echo "Delgados ";}
	if($_REQUEST["dgLabioM"]=="S"){echo "Medianos ";}
	if($_REQUEST["dgLabioG"]=="S"){echo "Gruesos ";}
	if($_REQUEST["dgLabioP"]=="S"){echo "Palidos ";}
	if($_REQUEST["dgLabioC"]=="S"){echo "Cianoticos.";}
	}?></div></td>
   </tr>
   <tr>
     <td>3.11.8. Dientes: <div style="width:500px" class="linea">&nbsp;<?php if(isset($_REQUEST["dgDienteCI"])){
	if($_REQUEST["dgDienteCI"]=="C"){echo "Completa";}
	else if($_REQUEST["dgDienteCI"]=="I"){echo " Incompleta";}
	if($_REQUEST["dgDienteA"]=="S"){echo " Ausente";}
	if($_REQUEST["dgDienteL"]=="S"){echo " Lesiones ";}
	if($_REQUEST["dgDienteO"]=="S"){echo " Ortodoncia ";}
	if($_REQUEST["dgDienteTP"]=="T"){echo " Protesis Total.";}
	else if($_REQUEST["dgDienteTP"]=="P"){echo " Protesis Parcial. ";}
	if($_REQUEST["dgProtesisD"]!=""){echo $_REQUEST["dgProtesisD"];}	
	}?></div></td>
   </tr>
   <tr>
     <td>Coloración: <div style="width:500px" class="linea">&nbsp;<?php if(isset($_REQUEST["dgColoracionD"])){echo $_REQUEST["dgColoracionD"];}?></div></td>
   </tr>
   <tr>
     <td>3.12. CUELLO: <div style="width:500px" class="linea">&nbsp;<?php if(isset($_REQUEST["dgCuelloT"])){
	if($_REQUEST["dgCuelloT"]=="C"){echo " Corto";}
	if($_REQUEST["dgCuelloT"]=="M"){echo " Mediano";}
	if($_REQUEST["dgCuelloT"]=="L"){echo " Largo";}
	if($_REQUEST["dgCuelloG"]=="S"){echo " Grueso.";}
	if($_REQUEST["dgCuelloTU"]=="S"){echo " Tumoraciones";}
	if($_REQUEST["dgCuelloV"]=="S"){echo " Vias de Canalizacion ";}
	if($_REQUEST["dgCuelloL"]=="S"){echo " Lesiones. ";}
	}?></div></td>
   </tr>
   <tr>
     <td>3.13. TÓRAX: <div style="width:500px" class="linea">&nbsp;
	<?php if(isset($_REQUEST["dgToraxS"])){
	if($_REQUEST["dgToraxS"]=="S"){echo " Simetrica";}
	if($_REQUEST["dgToraxS"]=="A"){echo " Asimetrica";}		
	}if(isset($_REQUEST["dgToraxD"])){echo $_REQUEST["dgToraxD"];}?></div></td>
   </tr>
   <tr>
     <td>3.14. MAMAS <div style="width:500px" class="linea">&nbsp;<?php if(isset($_REQUEST["dgMamaS"])){
	if($_REQUEST["dgMamaS"]=="S"){echo " Sin Alteraciones";}
	if($_REQUEST["dgMamaT"]=="P"){echo " PequeÑas.";}
	if($_REQUEST["dgMamaT"]=="M"){echo " Medianas.";}
	if($_REQUEST["dgMamaT"]=="G"){echo " Grandes. ";}
	if($_REQUEST["dgMamaR"]=="S"){echo " Resecadas";}
	if($_REQUEST["dgMamaI"]=="S"){echo " Implantes";}
	if($_REQUEST["dgMamaP"]=="S"){echo " pigmentación de areolas";}
	if($_REQUEST["dgMamaSe"]=="S"){echo " Secreciones. ";}
	}?> </div></td></tr>
    <tr><td>
    <div style="width:720px; line-height:20px; text-align:justify">DESCRIPCIÓN: &nbsp;<?php if(isset($_REQUEST["dgMamasD"])){echo $_REQUEST["dgMamasD"];}?></div></td>
   </tr>
   <tr>
     <td>3.15. ABDOMEN: <div style="width:500px" class="linea">&nbsp;<?php if(isset($_REQUEST["dgAbdomenSA"])){
	if($_REQUEST["dgAbdomenSA"]=="S"){echo " Simetrica.";}
	if($_REQUEST["dgAbdomenSA"]=="A"){echo " Asimetrica.";}
	if($_REQUEST["dgAbdomenE"]=="S"){echo " Excavado";}
	if($_REQUEST["dgAbdomenP"]=="S"){echo " Plano ";}
	if($_REQUEST["dgAbdomenSe"]=="S"){echo " Semigloboso";}
	if($_REQUEST["dgAbdomenG"]=="S"){echo " Globoloso";}
	if($_REQUEST["dgAbdomenB"]=="S"){echo " Batracio";}
	}?></div></td>
   </tr>
   <tr>
     <td>3.16. DORSO: <div style="width:500px" class="linea">&nbsp;<?php if(isset($_REQUEST["dgDorsoS"])){
	if($_REQUEST["dgDorsoS"]=="S"){echo " Simetrica.";}
	if($_REQUEST["dgDorsoS"]=="A"){echo " Asimetrica.";}
	}?></div></td></tr>
    <tr><td>
    <div style="width:720px; line-height:20px; text-align:justify">Descripcion:&nbsp;<?php if(isset($_REQUEST["dgDorsoD"])){echo $_REQUEST["dgDorsoD"];}?></div></td>
   </tr>
   <tr>
     <td>3.17. EXTREMIDADES  SUPERIORES:<div style="width:500px" class="linea">&nbsp;<?php if(isset($_REQUEST["dgESA"])){
	if($_REQUEST["dgESA"]=="S"){echo " Amputacion";}
	if($_REQUEST["dgESS"]=="S"){echo " Simetrica.";}
	if($_REQUEST["dgESS"]=="A"){echo " Asimetrica";}
	if($_REQUEST["dgESN"]=="S"){echo " Normotrofico: SI ";}else{ echo " Normotrofico: NO ";}
	if($_REQUEST["dgESH"]=="S"){echo " Hipotrofico: SI ";}else{ echo " Hipotrofico: NO ";}
	if($_REQUEST["dgESV"]=="S"){echo " Vias de canalización: SI ";}else{ echo "Vias de canalización: NO ";}
	}?></div></td></tr>
    <tr><td>
    <div style="width:720px; line-height:20px; text-align:justify">Descripcion:&nbsp;<?php if(isset($_REQUEST["dgESD"])){echo $_REQUEST["dgESD"];}?></div></td>
   </tr>
   <tr>
     <td>3.18. EXTREMIDADES  INFERIORES:<div style="width:500px" class="linea">&nbsp;<?php if(isset($_REQUEST["dgEIA"])){
	if($_REQUEST["dgEIA"]=="S"){echo " Amputacion: SI";}else {echo "Amputacion: NO";}
	if($_REQUEST["dgEIS"]=="S"){echo " Simetrica.";}
	if($_REQUEST["dgEIS"]=="A"){echo " Asimetrica";}
	if($_REQUEST["dgEIN"]=="S"){echo " Normotrofico: SI ";}else{ echo " Normotrofico: NO ";}
	if($_REQUEST["dgEIH"]=="S"){echo " Hipotrofico: SI ";}else{ echo " Hipotrofico: NO ";}
	if($_REQUEST["dgEIV"]=="S"){echo " Vias de canalización: SI ";}else{ echo "Vias de canalización: NO ";}
	}?></div></td></tr>
    <tr><td>
    <div style="width:720px; line-height:20px; text-align:justify">Descripcion:&nbsp;<?php if(isset($_REQUEST["dgEID"])){echo $_REQUEST["dgEID"];}?></div></td>
   </tr>
   <tr>
     <td>3.19. GENITALES EXTERNOS: <div style="width:500px" class="linea">&nbsp;<?php if(isset($_REQUEST["dgVPA"])){
	if($_REQUEST["dgVPA"]=="S"){echo " Androide: SI";}else {echo " Androide: NO";}
	if($_REQUEST["dgVPG"]=="S"){echo " Ginecoide: SI";}else {echo " Ginecoide: NO";}
	if($_REQUEST["dgVPAB"]=="S"){echo " Abundante: SI";}else {echo " Abundante: NO";}
	if($_REQUEST["dgVPE"]=="S"){echo " Escaso";}else {echo " Escaso: NO";}
	if($_REQUEST["dgVPAU"]=="S"){echo " Ausente: SI";}else {echo " Ausente: NO";}
	if($_REQUEST["dgVPC"]=="S"){echo " Canoso: SI";}else {echo " Canoso: NO";}
	if($_REQUEST["dgVPEN"]=="S"){echo " Entrecano: SI";}else {echo " Entrecano: NO";}
	if($_REQUEST["dgVPR"]=="A"){echo " Entrecano: SI";}else {echo " Entrecano: NO";}
	}?></div></td></tr>
    <tr><td>
    <div style="width:720px; line-height:20px; text-align:justify">Descripcion:&nbsp;<?php if(isset($_REQUEST["dgVPD"])){echo $_REQUEST["dgVPD"];}?></div></td>
   </tr>
   <tr>
     <td>3.19.1. Vello púbico:<div style="width:500px" class="linea">&nbsp;<?php if(isset($_REQUEST["var"])){echo $_REQUEST["var"];}?></div></td>
   </tr>
   <tr>
     <td>3.19.2. Pene: <div style="width:500px" class="linea">&nbsp;<?php if(isset($_REQUEST["dgPAL"])){
	if($_REQUEST["dgPAL"]=="S"){echo " Alteraciones: SI";}else {echo " Alteraciones: NO";}
	if($_REQUEST["dgPLE"]=="S"){echo " Lesiones: SI";}else {echo " Lesiones: NO";}
	}?></div></td></tr>
    <tr><td>
    <div style="width:720px; line-height:20px; text-align:justify">Descripcion:&nbsp;<?php if(isset($_REQUEST["dgPENED"])){echo $_REQUEST["dgPENED"];}?></div></td>
   </tr>
   <tr>
     <td>3.19.3. Escroto:<div style="width:500px" class="linea">&nbsp;<?php if(isset($_REQUEST["dgEAL"])){
	if($_REQUEST["dgEAL"]=="S"){echo " Alteraciones: SI";}else {echo " Alteraciones: NO";}
	if($_REQUEST["dgELE"]=="S"){echo " Lesiones: SI";}else {echo " Lesiones: NO";}
	}?></div></td></tr>
    <tr><td>
    <div style="width:720px; line-height:20px; text-align:justify">Descripcion:&nbsp;<?php if(isset($_REQUEST["dgESCROTOD"])){echo $_REQUEST["dgESCROTOD"];}?></div></td>
   </tr>
   <tr>
     <td>3.19.4. Vulva:<div style="width:500px" class="linea">&nbsp;<?php if(isset($_REQUEST["var"])){
	if($_REQUEST["dgVAL"]=="S"){echo " Alteraciones: SI";}else {echo " Alteraciones: NO";}
	if($_REQUEST["dgVLE"]=="S"){echo " Lesiones: SI";}else {echo " Lesiones: NO";}
	}?></div></td></tr>
    <tr><td>
    <div style="width:720px; line-height:20px; text-align:justify">Descripcion:&nbsp;<?php if(isset($_REQUEST["dgVULVAD"])){echo $_REQUEST["dgVULVAD"];}?></div></td>
   </tr>
   <tr>
     <td>3.19.5. Himen:<div style="width:500px" class="linea">&nbsp;<?php if(isset($_REQUEST["var"])){
	if($_REQUEST["var"]=="S"){echo " Alteraciones: SI";}else {echo " Alteraciones: NO";}
	if($_REQUEST["var"]=="S"){echo " Lesiones: SI";}else {echo " Lesiones: NO";}
	}?></div></td></tr>
    <tr><td>
    <div style="width:720px; line-height:20px; text-align:justify">Descripcion:&nbsp;<?php if(isset($_REQUEST["dgPENED"])){echo $_REQUEST["dgPENED"];}?></div></td>
   </tr>
   <tr>
     <td>3.20. ANO:<div style="width:500px" class="linea">&nbsp;<?php if(isset($_REQUEST["var"])){
	if($_REQUEST["dgACA"]=="S"){echo " Con Alteraciones";}
	if($_REQUEST["dgASA"]=="S"){echo " Sin Alteraciones";}
	if($_REQUEST["dgALA"]=="S"){echo " Lesiones Antiguas";}
	}?></div></td></tr>
    <tr><td>
    <div style="width:720px; line-height:20px; text-align:justify">Descripcion:&nbsp;<?php if(isset($_REQUEST["dgANOD"])){echo $_REQUEST["dgANOD"];}?>
    </div>
    </td>
   </tr>
   </table>
   <br />
      <table width="100%" align="center" cellpadding="10" cellspacing="5" class="table">
      <tr>
      <td colspan="6" bgcolor="#F5F6CE"><div class="txt_title" style="width:720px">4. EXAMEN INTERNO</div></td>
      </tr>
      <tr>
        <td colspan="6">4.1. INCISIÓN:</td>
        </tr>
      <tr>
        <td colspan="6">4.2. CABEZA:</td>
        </tr>
      <tr>
        <td colspan="6">4.2.1. Lesiones traumáticas en cuero cabelludo:</td>
        </tr>
      <tr>
        <td colspan="6">4.2.2. Cráneo:xx Grosor (cm):</td>
        </tr>
      <tr>
        <td colspan="6">4.2.3. Etmoides y peÑascos:</td>
        </tr>
      <tr>
        <td colspan="6">4.2.4. Duramadre:</td>
        </tr>
      <tr>
        <td colspan="6">4.2.5. Leptomeninges:</td>
        </tr>
      <tr>
        <td colspan="6">4.2.6. CEREBRO</td>
        </tr>
      <tr>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
      </tr>
      <tr>
        <td colspan="6">Masa o tumor localizado en:</td>
        </tr>
      <tr>
        <td colspan="6">4.2.7. Surcos: </td>
        </tr>
      <tr>
        <td colspan="6">4.2.8. Circunvoluciones:</td>
        </tr>
      <tr>
        <td colspan="6">4.2.9. Corteza cerebral:</td>
        </tr>
      <tr>
        <td colspan="6">4.2.10. Ventrículos cerebrales:</td>
        </tr>
      <tr>
        <td colspan="6">4.2.11. Sustancia blanca:</td>
        </tr>
      <tr>
        <td colspan="6">4.2.12. Cerebelo:</td>
        </tr>
      <tr>
        <td colspan="6">4.2.13. Amígdalas cerebelosas:</td>
        </tr>
      <tr>
        <td colspan="6">4.2.14. Protuberancia</td>
        </tr>
      <tr>
        <td colspan="6">4.2.15. Bulbo raquídeo: </td>
        </tr>
      <tr>
        <td colspan="6">4.2.16. Médula espinal:</td>
        </tr>
      <tr>
        <td colspan="6">4.2.17. Hipófisis:</td>
        </tr>
      <tr>
        <td colspan="6">4.2.18. Polígono de Willis:</td>
        </tr>
      <tr>
        <td colspan="6">4.3. CUELLO: </td>
        </tr>
      <tr>
        <td colspan="6">4.3.1. Partes blandas: </td>
        </tr>
      <tr>
        <td colspan="6">Describa</td>
        </tr>
      <tr>
        <td colspan="6">4.3.2. Paquete vasculo nervioso:</td>
        </tr>
      <tr>
        <td colspan="6">Describa</td>
        </tr>
      <tr>
        <td colspan="6">4.3.3. Timo: </td>
        </tr>
      <tr>
        <td colspan="6">4.3.4. Laringe:</td>
        </tr>
      <tr>
        <td colspan="6">Describa:</td>
        </tr>
      <tr>
        <td colspan="6">4.3.5. Amígdalas palatinas: </td>
        </tr>
      <tr>
        <td colspan="6">4.3.6. Hueso hioides:</td>
        </tr>
      <tr>
        <td colspan="6">4.3.7. Tráquea:</td>
        </tr>
      <tr>
        <td colspan="6">4.3.8. Bronquios:</td>
        </tr>
      <tr>
        <td colspan="6">4.3.9. Faringe:</td>
        </tr>
      <tr>
        <td colspan="6">4.4. TÓRAX: </td>
        </tr>
      <tr>
        <td colspan="6">4.4.1. Pleura parietal izquierda:</td>
        </tr>
      <tr>
        <td colspan="6">4.4.2. Pleura parietal derecha:</td>
        </tr>
      <tr>
        <td colspan="5">4.4.3. Contenido de cavidad torácica izquierda:</td>
        <td>Cantidad (ml):</td>
        </tr>
      <tr>
        <td colspan="5">4.4.4. Contenido de cavidad torácica derecha:Cantidad (ml):</td>
        <td>Cantidad (ml):</td>
        </tr>
      <tr>
        <td colspan="6">4.4.5. Cúpula diafragmática izquierda: </td>
        </tr>
      <tr>
        <td colspan="6">4.4.6. Cúpula diafragmática derecha:</td>
        </tr>
      <tr>
        <td colspan="6">Nivel de cúpula diafragmática:<div class="linea" style="width:300px">&nbsp;</div></td>
      </tr>
      <tr>
        <td colspan="6">4.5. RESPIRATORIO:</td>
      </tr>
      <tr>
        <td colspan="6">4.5.1. PULMÓN DERECHO: </td>
      </tr>
      <tr>
        <td colspan="6">Superficie externa: </td>
      </tr>
      <tr>
        <td colspan="6">Coloración:</td>
      </tr>
      <tr>
        <td colspan="6">A la palpación: </td>
      </tr>
      <tr>
        <td colspan="6">Al corte: </td>
      </tr>
      <tr>
        <td colspan="6">Ramificaciones bronquiales:</td>
      </tr>
      <tr>
        <td colspan="6">4.5.2. PULMÓN IZQUIERDO:</td>
      </tr>
      <tr>
        <td colspan="6">Superficie externa: </td>
      </tr>
      <tr>
        <td colspan="6">Coloración:</td>
      </tr>
      <tr>
        <td colspan="6">A la palpación:</td>
      </tr>
      <tr>
        <td colspan="6">Al corte: </td>
      </tr>
      <tr>
        <td colspan="6">Ramificaciones bronquiales:</td>
      </tr>
      <tr>
        <td colspan="6">4.6. VASOS SANGUÍNEOS: </td>
      </tr>
      <tr>
        <td colspan="6">Ganglios linfáticos: </td>
      </tr>
      <tr>
        <td colspan="6">Consistencia:</td>
      </tr>
      <tr>
        <td colspan="6">4.6.1. Corazón: </td>
      </tr>
      <tr>
        <td colspan="6">a) Pericardio: </td>
      </tr>
      <tr>
        <td colspan="6">Superficie epicárdica: </td>
      </tr>
      <tr>
        <td colspan="5">Contenido en cavidad pericárdica:</td>
        <td>cantidad (ml)</td>
        </tr>
      <tr>
        <td colspan="6">b) Arterias coronarias:</td>
      </tr>
      <tr>
        <td colspan="6">b.1)Descendente anterior:</td>
      </tr>
      <tr>
        <td colspan="6">b.2)Circunfleja:</td>
      </tr>
      <tr>
        <td colspan="6">b.3)Derecha: </td>
      </tr>
      <tr>
        <td colspan="6">c) Aurícula derecha:</td>
      </tr>
      <tr>
        <td colspan="6">d) Aurícula izquierda:</td>
      </tr>
      <tr>
        <td colspan="6">e) Ventrículo derecho: </td>
      </tr>
      <tr>
        <td colspan="6">f) Ventrículo izquierdo: </td>
      </tr>
      <tr>
        <td colspan="6">g) Válvulas cardíacas: </td>
      </tr>
      <tr>
        <td colspan="6">g.1)Mitral: </td>
      </tr>
      <tr>
        <td colspan="6">g.2)Aórtica:</td>
      </tr>
      <tr>
        <td colspan="6">g.3)Pulmonar:</td>
      </tr>
      <tr>
        <td colspan="6">g.4)Tricúspide:</td>
        </tr>
      <tr>
        <td colspan="6">Cuerdas tendinosas: </td>
        </tr>
      <tr>
        <td colspan="6">h) Miocardio:</td>
        </tr>
      <tr>
        <td colspan="6">Descripción:</td>
        </tr>
      <tr>
        <td colspan="6">4.6.2. Arteria pulmonar:</td>
      </tr>
      <tr>
        <td colspan="6">4.6.3. Arteria aorta: </td>
      </tr>
      <tr>
        <td colspan="6">4.6.4. Arterias renales:</td>
      </tr>
      <tr>
        <td colspan="6">4.6.5. Arterias ilíacas: </td>
      </tr>
      <tr>
        <td colspan="6">Descripción del sistema vascular (cantidad, ulceradas, calcificadas):</td>
      </tr>
      <tr>
        <td colspan="6">4.7. ABDOMEN:</td>
      </tr>
      <tr>
        <td colspan="6">4.7.1. Peritoneo</td>
      </tr>
      <tr>
        <td colspan="6">4.7.2. Tejido ectópico, describa:</td>
      </tr>
      <tr>
        <td colspan="6">Líquido peritoneal (ml):</td>
      </tr>
      <tr>
        <td colspan="6">4.7.3. Vena cava inferior: </td>
      </tr>
      <tr>
        <td colspan="6">4.7.4. Hígado:</td>
      </tr>
      <tr>
        <td colspan="6">TamaÑo:</td>
      </tr>
      <tr>
        <td colspan="6">Superficie capsular: </td>
      </tr>
      <tr>
        <td colspan="6">Consistencia:</td>
      </tr>
      <tr>
        <td colspan="6">Bordes:</td>
      </tr>
      <tr>
        <td colspan="6">Parénquima: </td>
      </tr>
      <tr>
        <td colspan="6">Descripción:__</td>
      </tr>
      <tr>
        <td colspan="6">4.7.5. Vesícula biliar:</td>
      </tr>
      <tr>
        <td colspan="6">Contenido:</td>
      </tr>
      <tr>
        <td colspan="6">Vías biliares extra hepáticas: </td>
      </tr>
      <tr>
        <td colspan="6">4.7.6. Bazo:</td>
      </tr>
      <tr>
        <td colspan="6">Superficie capsular:</td>
      </tr>
      <tr>
        <td colspan="6">Consistencia:</td>
      </tr>
      <tr>
        <td colspan="6">Parénquima:</td>
      </tr>
      <tr>
        <td colspan="6">4.7.7. Páncreas:</td>
      </tr>
      <tr>
        <td colspan="6">4.7.8. RiÑón derecho:</td>
      </tr>
      <tr>
        <td colspan="6">Cápsula: </td>
      </tr>
      <tr>
        <td colspan="6">Superficie cortical:</td>
      </tr>
      <tr>
        <td colspan="6">Parénquima: </td>
      </tr>
      <tr>
        <td colspan="6">Describa:</td>
      </tr>
      <tr>
        <td colspan="6">4.7.9. RiÑón izquierdo: </td>
      </tr>
      <tr>
        <td colspan="6">Cápsula: </td>
      </tr>
      <tr>
        <td colspan="6">Superficie cortical:</td>
      </tr>
      <tr>
        <td colspan="6">Parénquima:</td>
      </tr>
      <tr>
        <td colspan="6">Cáliz y pelvis:</td>
      </tr>
      <tr>
        <td colspan="6">4.8. DIGESTIVO:</td>
      </tr>
      <tr>
        <td colspan="6">4.8.1. Mucosa oral: </td>
      </tr>
      <tr>
        <td colspan="6">4.8.2. Esófago:</td>
      </tr>
      <tr>
        <td colspan="6">4.8.3. Estómago </td>
      </tr>
      <tr>
        <td colspan="6">Contenido gástrico (característico)</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>Olor:</td>
        <td>&nbsp;</td>
        <td>Cantidad (ml):</td>
      </tr>
      <tr>
        <td colspan="6">4.8.4. Intestino delgado: </td>
      </tr>
      <tr>
        <td colspan="6">4.8.5. Intestino grueso:</td>
      </tr>
      <tr>
        <td colspan="6">4.8.6. Apéndice: </td>
      </tr>
      <tr>
        <td colspan="6">4.8.7. Vasos mesentéricos:</td>
      </tr>
      <tr>
        <td colspan="6">4.8.8. Mesenterio: </td>
      </tr>
      <tr>
        <td colspan="6">4.9. GENITALES:</td>
      </tr>
      <tr>
        <td colspan="6">GENITALES FEMENINOS</td>
      </tr>
      <tr>
        <td colspan="6">4.9.1. Útero:</td>
      </tr>
      <tr>
        <td colspan="6">Forma: </td>
      </tr>
      <tr>
        <td colspan="6">TamaÑo:</td>
      </tr>
      <tr>
        <td colspan="6">4.9.2.</td>
      </tr>
      <tr>
        <td>Sexo________ </td>
        <td>Peso (g)________</td>
        <td>Talla (cm)____________ </td>
        <td>PC_________ </td>
        <td>PT__________ </td>
        <td>PA___________</td>
      </tr>
      <tr>
        <td colspan="6">4.9.3. Cordón umbilical (longitud en  cm):</td>
        </tr>
      <tr>
        <td colspan="5">4.9.4. Placenta:</td>
        <td>Diámetro</td>
        </tr>
      <tr>
        <td colspan="6">Longitud</td>
      </tr>
      <tr>
        <td colspan="6">Describa</td>
      </tr>
      <tr>
        <td colspan="5">Cavidad endometrial:</td>
        <td>Restos placentarios:</td>
        </tr>
      <tr>
        <td colspan="6">Canal endocervical:</td>
      </tr>
      <tr>
        <td colspan="6">Orificio cervical externo: </td>
      </tr>
      <tr>
        <td colspan="6">4.9.5. Ovarios: </td>
      </tr>
      <tr>
        <td colspan="6">4.9.6. Trompas de Falopio:</td>
      </tr>
      <tr>
        <td colspan="6">GENITALES MASCULINOS</td>
      </tr>
      <tr>
        <td colspan="6">4.9.7. Próstata </td>
      </tr>
      <tr>
        <td colspan="6">4.9.8. Testículos</td>
      </tr>
      <tr>
        <td colspan="6">Cordón espermático:</td>
      </tr>
      <tr>
        <td colspan="6">Anillos inguinales: </td>
      </tr>
      <tr>
        <td colspan="6">4.10. SISTEMA ENDOCRINO: </td>
      </tr>
      <tr>
        <td colspan="6">4.10.1. Tiroides</td>
      </tr>
      <tr>
        <td colspan="6">4.10.2. Glándulas suprarrenales:</td>
      </tr>
      <tr>
        <td colspan="6">4.11. Sistema músculo esquelético:</td>
      </tr>
      <tr>
        <td colspan="6">Disección por planos: </td>
      </tr>
      <tr>
        <td colspan="6">DESCRIPCIÓN:</td>
      </tr>
  </table><br />
  <table width="100%" align="center" cellpadding="10" cellspacing="5" class="table">
  <tr>
  <td colspan="4" bgcolor="#F5F6CE"><div class="txt_title" style="width:720px">5. PESOS Y MEDIDAS DE ORGANOS</div></td>
  </tr>
  <tr>
    <td>5.1.1. CEREBRO</td>
    <td>Peso(gr):<div style="width:50px;" class="linea">&nbsp;<?php if(isset($_REQUEST["pcerebro"])){echo $_REQUEST["pcerebro"]; }?></div></td>
    <td>ST(g):<div style="width:50px;" class="linea">&nbsp;<?php if(isset($_REQUEST["stcerebro"])){echo $_REQUEST["stcerebro"]; }?></div></td>
    <td>IT(G):<div style="width:50px;" class="linea">&nbsp;<?php if(isset($_REQUEST["itcerebro"])){echo $_REQUEST["itcerebro"]; }?></div></td>
    </tr>
  <tr>
    <td>5.1.2. TRAQUEA</td>
    <td>Longitud (cm): <div style="width:50px;" class="linea">&nbsp;<?php if(isset($_REQUEST["longtraquea"])){echo $_REQUEST["longtraquea"]; }?></div></td>
    <td colspan="2">Diámetro (cm): <div style="width:50px;" class="linea">&nbsp;<?php if(isset($_REQUEST["diatraquea"])){echo $_REQUEST["diatraquea"]; }?></div></td>
  </tr>
  <tr>
    <td>5.1.3. BRONQUIOS </td>
    <td colspan="3">Diámetro(cm):<div style="width:50px;" class="linea">&nbsp;<?php if(isset($_REQUEST["diabronquio"])){echo $_REQUEST["diabronquio"]; }?></div></td>
  </tr>
  <tr>
    <td>5.1.4. PULMON </td>
    <td>DERECHO Peso(gr):<div style="width:50px;" class="linea">&nbsp;<?php if(isset($_REQUEST["derppulmon"])){echo $_REQUEST["derppulmon"]; }?></div></td>
    <td colspan="2">IZQUIERDO Peso(gr):<div style="width:50px;" class="linea">&nbsp;<?php if(isset($_REQUEST["izqppulmon"])){echo $_REQUEST["izqppulmon"]; }?></div></td>
  </tr>
  <tr>
    <td>5.1.5. CORAZON </td>
    <td colspan="3">Peso(gr): <div style="width:50px;" class="linea">&nbsp;<?php if(isset($_REQUEST["pcorazon"])){echo $_REQUEST["pcorazon"]; }?></div></td>
  </tr>
  <tr>
    <td>5.1.5.1.Ventrículo izq:</td>
    <td>Grosor(cm):<div style="width:50px;" class="linea">&nbsp;<?php if(isset($_REQUEST["izqgventriculo"])){echo $_REQUEST["izqgventriculo"]; }?></div></td>
    <td>Entrada(cm):<div style="width:50px;" class="linea">&nbsp;<?php if(isset($_REQUEST["izqeventriculo"])){echo $_REQUEST["izqeventriculo"]; }?></div></td>
    <td>Salida(cm):<div style="width:50px;" class="linea">&nbsp;<?php if(isset($_REQUEST["izqsventriculo"])){echo $_REQUEST["izqsventriculo"]; }?></div></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>Válvula mitral (cm):<div style="width:50px;" class="linea">&nbsp;<?php if(isset($_REQUEST["izqvventriculo"])){echo $_REQUEST["izqvventriculo"]; }?></div></td>
    <td colspan="2">Válvula aórtica (cm):<div style="width:50px;" class="linea">&nbsp;<?php if(isset($_REQUEST["izqpventriculo"])){echo $_REQUEST["izqpventriculo"]; }?></div></td>
    </tr>
  <tr>
    <td>5.1.5.2. Ventrículo der:</td>
    <td>Grosor(cm):<div style="width:50px;" class="linea">&nbsp;<?php if(isset($_REQUEST["dergventriculo"])){echo $_REQUEST["dergventriculo"]; }?></div></td>
    <td>Entrada(cm):<div style="width:50px;" class="linea">&nbsp;<?php if(isset($_REQUEST["dereventriculo"])){echo $_REQUEST["dereventriculo"]; }?></div></td>
    <td>Salida(cm):<div style="width:50px;" class="linea">&nbsp;<?php if(isset($_REQUEST["dersventriculo"])){echo $_REQUEST["dersventriculo"]; }?></div></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>Válvula tricúspide (cm):<div style="width:50px;" class="linea">&nbsp;<?php if(isset($_REQUEST["dervventriculo"])){echo $_REQUEST["dervventriculo"]; }?></div></td>
    <td colspan="2">Válvula pulmonar (cm):<div style="width:50px;" class="linea">&nbsp;<?php if(isset($_REQUEST["derpventriculo"])){echo $_REQUEST["derpventriculo"]; }?></div></td>
    </tr>
  <tr>
    <td colspan="2">5.1.6. DIÁMETRO DE ARTERIA PULMONAR (cm):<div style="width:50px;" class="linea">&nbsp;<?php if(isset($_REQUEST["diaartp"])){echo $_REQUEST["diaartp"]; }?></div></td>
    <td colspan="2">DIÁMETRO DE ARTERIA AORTA (cm):<div style="width:50px;" class="linea">&nbsp;<?php if(isset($_REQUEST["diaarto"])){echo $_REQUEST["diaarto"]; }?></div></td>
  </tr>
  <tr>
    <td>5.1.7. HIGADO</td>
    <td>Peso(gr):<div style="width:50px;" class="linea">&nbsp;<?php if(isset($_REQUEST["phigado"])){echo $_REQUEST["phigado"]; }?></div></td>
    <td colspan="2">Dimensiones (cm):<div style="width:50px;" class="linea">&nbsp;<?php if(isset($_REQUEST["dhigado"])){echo $_REQUEST["dhigado"]; }?></div></td>
  </tr>
  <tr>
    <td>5.1.8. BAZO</td>
    <td>Peso(gr):<div style="width:50px;" class="linea">&nbsp;<?php if(isset($_REQUEST["pbazo"])){echo $_REQUEST["pbazo"]; }?></div></td>
    <td colspan="2">TamaÑo(cm):<div style="width:50px;" class="linea">&nbsp;<?php if(isset($_REQUEST["tbazo"])){echo $_REQUEST["tbazo"]; }?></div></td>
    </tr>
  <tr>
    <td>5.1.9. PANCREAS </td>
    <td colspan="3">Peso(gr):<div style="width:50px;" class="linea">&nbsp;<?php if(isset($_REQUEST["ppancreas"])){echo $_REQUEST["ppancreas"]; }?></div></td>
  </tr>
  <tr>
    <td>5.1.10. RIÑON DERECHO</td>
    <td>Peso(gr):<div style="width:50px;" class="linea">&nbsp;<?php if(isset($_REQUEST["derprin"])){echo $_REQUEST["derprin"]; }?></div></td>
     <td colspan="2">TamaÑo (cm):<div style="width:50px;" class="linea">&nbsp;<?php if(isset($_REQUEST["dertrin"])){echo $_REQUEST["dertrin"]; }?></div></td>
 </tr>
  <tr>
    <td>5.1.11. RIÑON IZQUIERDO </td>
    <td>Peso(gr):<div style="width:50px;" class="linea">&nbsp;<?php if(isset($_REQUEST["izqprin"])){echo $_REQUEST["izqprin"]; }?></div></td>
     <td colspan="2">TamaÑo(cm):<div style="width:50px;" class="linea">&nbsp;<?php if(isset($_REQUEST["izqtrin"])){echo $_REQUEST["izqtrin"]; }?>
     </div></td>
 </tr>
  <tr>
    <td>5.1.12. UTERO:</td>
    <td>Peso(gr):<div style="width:50px;" class="linea">&nbsp;
    <?php if(isset($_REQUEST["p_utero"])){echo $_REQUEST["p_utero"]; }?></div></td>
    <td colspan="2">Ancho(cm):<div style="width:50px;" class="linea">&nbsp;
    <?php if(isset($_REQUEST["a_utero"])){echo $_REQUEST["a_utero"]; }?></div></td>
    </tr>
  <tr>
    <td>&nbsp;</td>
    <td>longitud(cm):<div style="width:50px;" class="linea">&nbsp;
    <?php if(isset($_REQUEST["l_utero"])){echo $_REQUEST["l_utero"]; }?></div></td>
    <td colspan="2">Espesor(cm):<div style="width:50px;" class="linea">&nbsp;
    <?php if(isset($_REQUEST["e_utero"])){echo $_REQUEST["e_utero"]; }?></div></td>
  </tr>
  <tr>
    <td>5.1.13. OVARIOS DERECHO</td>
    <td>Peso(gr):<div style="width:50px;" class="linea">&nbsp;<?php if(isset($_REQUEST["p_od"])){echo $_REQUEST["p_od"]; }?></div></td>
    <td colspan="2">Medida:<div style="width:50px;" class="linea">&nbsp;<?php if(isset($_REQUEST["m_od"])){echo $_REQUEST["m_od"]; }?></div></td>
  </tr>
  <tr>
    <td>5.1.14. OVARIOS IZQUIERDO</td>
    <td>Peso(gr):<div style="width:50px;" class="linea">&nbsp;<?php if(isset($_REQUEST["p_oi"])){echo $_REQUEST["p_oi"]; }?></div></td>
    <td colspan="2">Medida:<div style="width:50px;" class="linea">&nbsp;<?php if(isset($_REQUEST["m_oi"])){echo $_REQUEST["m_oi"]; }?></div></td>
  </tr>
  <tr>
    <td>5.1.15. TESTICULO</td>
    <td>Peso(gr):<div style="width:50px;" class="linea">&nbsp;<?php if(isset($_REQUEST["derp_t"])){echo $_REQUEST["derp_t"]; }?></div></td>
    <td colspan="2">IZQUIERDO Peso(gr):<div style="width:50px;" class="linea">&nbsp;<?php if(isset($_REQUEST["izqp_t"])){echo $_REQUEST["izqp_t"]; }?></div></td>
  </tr>
  <tr>
    <td>5.1.16. PROSTATA</td>
    <td colspan="3">Peso(gr):<div style="width:50px;" class="linea">&nbsp;<?php if(isset($_REQUEST["pprostata"])){echo $_REQUEST["pprostata"]; }?>
    </div></td>
  </tr>
  <tr>
    <td>5.1.17. TIROIDES </td>
    <td colspan="3">Peso(gr):<div style="width:50px;" class="linea">&nbsp;<?php if(isset($_REQUEST["ptiroide"])){echo $_REQUEST["ptiroide"]; }?><</div></td>
  </tr>
  <tr>
    <td>5.1.18. SUPRARRENALES DER</td>
    <td colspan="3">Peso(gr):<div style="width:50px;" class="linea">&nbsp;<?php if(isset($_REQUEST["p_suprader"])){echo $_REQUEST["p_suprader"]; }?></div></td>
  </tr>
  <tr>
    <td>5.1.19. SUPRARRENALES IZQ</td>
    <td colspan="3">Peso(gr):<div style="width:50px;" class="linea">&nbsp;<?php if(isset($_REQUEST["p_supraizq"])){echo $_REQUEST["p_supraizq"]; }?></div></td>
  </tr>
  </table>
  <br />
  <table width="100%" align="center" cellpadding="10" cellspacing="5" class="table">
  <tr>
  <td bgcolor="#F5F6CE" class="txt_title">6. CAUSAS DE MUERTE</td>
  </tr>
  <tr>
    <td>1-a) <div class="linea" style="width:690px">&nbsp;<?php if(isset($_REQUEST["CMDA"])){echo $_REQUEST["CMDA"]; }?></div></td>
  </tr>
  <tr>
    <td>1-b) <div class="linea" style="width:690px">&nbsp;<?php if(isset($_REQUEST["CMDB"])){echo $_REQUEST["CMDB"]; }?></div></td>
  </tr>
  <tr>
    <td>1-c) <div class="linea" style="width:690px">&nbsp;<?php if(isset($_REQUEST["CMDC"])){echo $_REQUEST["CMDC"]; }?></div></td>
  </tr>
  <tr>
    <td>1-d) <div class="linea" style="width:690px">&nbsp;<?php if(isset($_REQUEST["CMDD"])){echo $_REQUEST["CMDD"]; }?></div></td>
  </tr>
  <tr>
    <td>6.2 <div class="linea" style="width:690px">&nbsp;<?php if(isset($_REQUEST["var"])){echo $_REQUEST["var"]; }?></div></td>
  </tr>
  <tr>
    <td>AGENTE O INSTRUMENTO<div class="linea" style="width:560px">&nbsp;<?php if(isset($_REQUEST["var"])){echo $_REQUEST["var"]; }?></div></td>
  </tr>
  </table>
  <br />
  <table width="100%" align="center" cellpadding="10" cellspacing="5" class="table">
  <tr>
  <td bgcolor="#F5F6CE"><div style="width:720px;" class="txt_title">7. MANERA DE MUERTE (d.p.m.l.)</div></td>
  </tr>
   <tr>
  <td><div style="width:720px; line-height:20px; text-align:justify"><?php if(isset($_REQUEST["MMDESC"])){echo $_REQUEST["MMDESC"];}?></div></td>
  </tr>
  </table>
   <br />
  <table width="100%" align="center" cellpadding="10" cellspacing="5" class="table">
  <tr>
  <td bgcolor="#F5F6CE"><div style="width:720px;" class="txt_title">8. DIAGNÓSTICO FISIOPATOLÓGICO</div></td>
  </tr>
   <tr>
  <td><div style="width:720px; line-height:20px; text-align:justify"><?php if(isset($_REQUEST["DFIDESC"])){echo $_REQUEST["DFIDESC"];}?></div></td>
  </tr>
  </table>
  <br />
  <table width="100%" align="center" cellpadding="10" cellspacing="5" class="table">
  <tr>
  <td bgcolor="#F5F6CE"><div style="width:720px;" class="txt_title">9. DIAGNÓSTICOS FINALES</div></td>
  </tr>
   <tr>
  <td><div style="width:720px; line-height:20px; text-align:justify"><?php if(isset($_REQUEST["DFDESC"])){echo $_REQUEST["DFDESC"];}?></div></td>
  </tr>
  </table>
    <br />
  <table width="100%" align="center" cellpadding="10" cellspacing="5" class="table">
  <tr>
  <td colspan="2" bgcolor="#F5F6CE"><div class="txt_title" style="width:720px">10. ESTUDIOS COMPLEMENTARIOS SOLICITADOS</div></td>
  </tr>
  <tr>
  <td>10.1.	Histopatología:&nbsp;<?php if(isset($_REQUEST["var"])){echo $_REQUEST["var"];}?></td>
  <td>10.2. Informes adicionales: &nbsp;<?php if(isset($_REQUEST["var"])){echo $_REQUEST["var"];}?></td>
  </tr>
  <tr>
  <td colspan="2">
  <table border="1" cellpadding="0" cellspacing="0" bordercolor="#CCCCCC" width="100%" align="center">
  <tr>
  <td><div style="width:330px; text-align:center">MATERIAL ENVIADO</div></td>
  <td><div style="width:330px; text-align:center">ESTUDIOS SOLICITADOS</div></td>
  </tr>
  <?php for ($i = 1; $i <= 5; $i++) {?>
  <tr>
  <td>&nbsp;x<?php if(isset($_REQUEST["var"])){echo $_REQUEST["var"];}?></td>
  <td>&nbsp;x<?php if(isset($_REQUEST["var"])){echo $_REQUEST["var"];}?></td>
  </tr>
  <?php }?>
  </table>
  </td>
  </tr>
  </table>
</page>
