<style type="text/Css">

#body{
	font-family:Arial, Helvetica, sans-serif;
	font-size:12px;
	font-weight:400;
	color:#000;
}
.small_font{
	font-size:8px;
	color:#666;
}
.bg_img{
	background-color:#92cddc;
	border-radius:5px;
	height:20px;
}
.linea{
	border-width:1px;
	border-bottom:solid;
        border-color: #666;

}
.txt_title{
	font-size:14px;
	font-weight:bold;
}
.txt_titleheader{
	font-size:13px;
	font-weight:bold;
	color:#333;
}
.txt_titleheader_cotenido{
	font-size:10px;
}
.tr{
     height:50px;
     text-align:left;
            }
.tr:nth-child(2n+1){
    background-color:#EFF8FB;
 }
-->
</style>

<page backtop="30mm" backimg="./res/img/logos/fondo.jpg" backbottom="30mm" backleft="0mm" backright="0mm" pagegroup="new" style="font-size: 11px; text-transform: uppercase;">
<page_header>
<table border="0" align="center" cellpadding="10" cellspacing="0">
  <tr>
    <td rowspan="2"><img src="./res/img/logos/mp.jpg" /></td>
    <td rowspan="2" align="center"><img src="./res/img/logos/logo_fondo_small.jpg" /></td>
    <td colspan="2" align="right" class="txt_titleheader">DIRECCIÓN GENERAL DE MEDICINA FORENSE<br/>DEPARTAMENTO DE PATOLOGÍA FORENSE<br/>
    <strong>HOJA DE TRABAJO PARA INSPECCIÓN ÓSEA</strong></td>
  </tr>
  <tr>
    <td>En revisión</td>
    <td align="right">PF-F118-1 V01 B03</td>
  </tr>
  <tr>
    <td colspan="4" valign="bottom" class="linea" height="10px"></td>
  </tr>
  <tr bgcolor="#E9E9E9">
    <td class="txt_titleheader_cotenido">Redactado por: L. Cruz, C. Martínez, E. López</td>
    <td align="right" class="txt_titleheader_cotenido" width="220">Editado por: T. Calidonio</td>
    <td align="right" class="txt_titleheader_cotenido">Revisado por: I. Raudales</td>
    <td align="right" class="txt_titleheader_cotenido">Aprobado por: I. Raudales</td>
  </tr>
  <tr>
    <td colspan="4" align="right"><p style="margin-right:-20px">Página [[page_cu]] de [[page_nb]]</p></td>
  </tr>
</table>
</page_header>
<page_footer>
  <div><img src="./res/img/levantamiento/footer.jpg" ></div>  
</page_footer>
<br />
<table width="100%" align="center" cellpadding="10" cellspacing="3" style="border-width:1px; border-style:solid; border-color:#CCC;">
    <tr>
        <td colspan="11" bgcolor="#92cddc" class="txt_title" style="border-radius:5px;">1. Datos de INSPECCIÓN</td>
    </tr>
    <tr>
      <td>Inspeccion N°:</td>
      <td align="center" class="linea"><?php if(isset($_REQUEST["i_anio"])){echo $_REQUEST["i_anio"];}?></td>
      <td align="center" class="linea"><?php if(isset($_REQUEST["i_sede"])){echo $_REQUEST["i_sede"];}?></td>
      <td align="center" class="linea"><?php if(isset($_REQUEST["i_coddep"])){echo $_REQUEST["i_coddep"];}?></td>
      <td align="center" class="linea"><?php if(isset($_REQUEST["i_corr"])){echo $_REQUEST["i_corr"];}?></td>
      <td>&nbsp;</td>
      <td>Levantamiento N°:</td>
      <td align="center" class="linea"><?php if(isset($_REQUEST["l_anio"])){echo $_REQUEST["l_anio"];}?></td>
      <td align="center" class="linea"><?php if(isset($_REQUEST["l_sede"])){echo $_REQUEST["l_sede"];}?></td>
      <td align="center" class="linea"><?php if(isset($_REQUEST["l_coddep"])){echo $_REQUEST["l_coddep"];}?></td>
      <td align="center" class="linea"><?php if(isset($_REQUEST["l_corr"])){echo $_REQUEST["l_corr"];}?></td>
    </tr>
    <tr class="small_font">
      <td align="center" valign="top">&nbsp;</td>
      <td align="center" valign="top">AÑO</td>
      <td align="center" valign="top">SEDE</td>
      <td align="center" valign="top">DEPTO</td>
      <td align="center" valign="top">CORRELATIVO</td>
      <td align="center" valign="top">&nbsp;</td>
      <td align="center" valign="top">&nbsp;</td>
      <td align="center" valign="top">AÑO</td>
      <td align="center" valign="top">SEDE</td>
      <td align="center" valign="top">DEPTO</td>
      <td align="center" valign="top">CORRELATIVO</td>
    </tr>
<tr>
<td colspan="2">Hora<div class="linea" style="width:100px">&nbsp;<?php if(isset($_REQUEST["i_hora"])){echo $_REQUEST["i_hora"];}?></div></td>
<td colspan="3">Fecha<div class="linea" style="width:130px">&nbsp;<?php if(isset($_REQUEST["i_fecha"])){echo $_REQUEST["i_fecha"];}?></div></td>
<td>&nbsp;</td>
<td colspan="2">Hora<div class="linea" style="width:100px">&nbsp;<?php if(isset($_REQUEST["l_hora"])){echo $_REQUEST["l_hora"];}?></div></td>
<td colspan="3">Fecha<div class="linea" style="width:100px">&nbsp;<?php if(isset($_REQUEST["l_fecha"])){echo $_REQUEST["l_hora"];}?></div></td>
</tr>
    <tr>
      <td colspan="6">Medico Inspeccion:<div class="linea" style="width:200px">&nbsp;<?php if(isset($_REQUEST["idMedico"])){echo $_REQUEST["idMedico"];}?></div></td>
      <td colspan="5"> N° de Colegiacion:<div class="linea" style="width:205px">&nbsp;<?php if(isset($_REQUEST["n_colegiacion"])){echo $_REQUEST["n_colegiacion"];}?></div></td>
    </tr>
    <tr>
      <td colspan="6">Disector:<div class="linea" style="width:255px">&nbsp;<?php if(isset($_REQUEST["disector"])){echo $_REQUEST["disector"];}?></div></td>
      <td colspan="5"> Fotografo:<div class="linea" style="width:248px">&nbsp;<?php if(isset($_REQUEST["fotografo"])){echo $_REQUEST["fotografo"];}?></div></td>
    </tr>
    <tr>
      <td colspan="11">Fiscal que autorizo la inspeccion:<div class="linea" style="width:500px">&nbsp;<?php if(isset($_REQUEST["fiscal"])){echo $_REQUEST["fiscal"];}?></div></td>
    </tr>
    <tr>
      <td colspan="11">Fecha de la Muerte:<div class="linea" style="width:590px">&nbsp;<?php if(isset($_REQUEST["fechaMuerte"])){echo $_REQUEST["fechaMuerte"];}?></div></td>
    </tr>
    <tr>
      <td colspan="11">Fecha de inspeccion:<div class="linea" style="width:585px">&nbsp;<?php if(isset($_REQUEST["fechainspeccion"])){echo $_REQUEST["fechainspeccion"];}?></div></td>
    </tr>
    <tr>
      <td colspan="6">Fecha de emision del dictamen:<div class="linea" style="width:200px">&nbsp;<?php if(isset($_REQUEST["fechaEntrega"])){echo $_REQUEST["fechaEntrega"];}?></div></td>
      <td colspan="5">Receptor(a):<div class="linea" style="width:240px">&nbsp;<?php if(isset($_REQUEST["receptor"])){echo $_REQUEST["receptor"];}?></div></td>
    </tr>
</table>
<br />
<table width="100%" align="center" cellpadding="10" cellspacing="3" style="border-width:1px; border-style:solid; border-color:#CCC;">
    <tr>
      <td colspan="4" bgcolor="#92cddc" class="txt_title" style="border-radius:5px;">2. DATOS GENERALES</td>
    </tr>
    <tr>
      <td colspan="4">2.1. Nombre:
        <div class="linea" style="width:650px">&nbsp;<?php if(isset($_REQUEST["nombreFallecido"])){echo $_REQUEST["nombreFallecido"];}?></div></td>
    </tr>
    <tr>
      <td>2.2 Edad:
        <div class="linea" style="width:70px">&nbsp;<?php if(isset($_REQUEST["edadFallecido"]) && $_REQUEST["edadFallecido"] >= "0"){echo $_REQUEST["edadFallecido"];}else{ echo "N/D";}?></div></td>
      <td align="left">2.3. Rango Edad:
      <div class="linea" style="width:70px">&nbsp;<?php if(isset($_REQUEST["rangoEdadFallecido"])){echo $_REQUEST["rangoEdadFallecido"];}?></div></td>
      <td align="left">2.4. Sexo:
      <div class="linea" style="width:120px">&nbsp;<?php if(isset($_REQUEST["sexoFallecido"])){echo $_REQUEST["sexoFallecido"];}?></div></td>
      <td align="left">2.5. Raza:
      <div class="linea" style="width:120px">&nbsp;<?php if(isset($_REQUEST["rangoFallecido"])){echo $_REQUEST["rangoFallecido"];}?></div></td>
    </tr>
    <tr>
      <td colspan="4">2.6. Otros:<div class="linea" style="width:660px">&nbsp;<?php if(isset($_REQUEST["otrosFallecido"])){echo $_REQUEST["otrosFallecido"];}?></div></td>
    </tr>
</table>
  <br />
<table width="100%" align="center" bordercolor="#CCCCCC" style="border-width:1px; border-style:solid; border-color:#CCC; border-radius: 5px;"> 
  <tr>
    <td bgcolor="#92cddc" class="txt_title">3.HISTORIA MEDICO LEGAL</td>
  </tr>
  <tr>
    <td><div style="width:725px; line-height:20px; text-align:justify"><?php if(isset($_REQUEST["hml"])){echo $_REQUEST["hml"];}?></div></td>
  </tr>
</table>
<br />
<table width="100%" align="center" bordercolor="#CCCCCC" style="border-width:1px; border-style:solid; border-color:#CCC; border-radius: 5px;"> 
  <tr>
    <td bgcolor="#92cddc" class="txt_title">4. CARACTERISTICAS DENTLES, FRACTURAS</td>
  </tr>
  <tr>
    <td><div style="width:725px; line-height:20px; text-align:justify"><?php if(isset($_REQUEST["caracteristicasDentales"])){echo $_REQUEST["caracteristicasDentales"];}?></div></td>
  </tr>
</table>

<br/>

<table width="100%" border="1" align="center" cellpadding="10" cellspacing="0" bordercolor="#CCCCCC" style="border-width:1px; border-style:solid; border-color:#CCC; padding:5px">  <tr>

    <td colspan="4" bgcolor="#92cddc"><div class="txt_title" style="width:725px;">5. INVENTARIO ÓSEO</div></td>
  </tr>
  <tr>
    <td align="center" bgcolor="#F8F8F8"><strong>Hueso</strong></td>
    <td align="center" bgcolor="#F8F8F8"><strong>Presente/Ausente</strong></td>
    <td align="center" bgcolor="#F8F8F8"><strong>Completo/Incompleto</strong></td>
    <td align="center" bgcolor="#F8F8F8"><strong>Cantidad</strong></td>
  </tr>
  <tr>
    <td height="20">5.1 CRÁNEO</td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["0P"])){if($_REQUEST["0P"]=="P"){echo "PRESENTE"; }if($_REQUEST["0P"]=="A") { echo "AUSENTE"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["0C"])){if($_REQUEST["0C"]=="C"){echo "COMPLETO"; }if($_REQUEST["0C"]=="I") { echo "INCOMPLETO"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
          <?php if(isset($_REQUEST["0Ct"])){echo $_REQUEST["0Ct"]; }?>
    </span></td>
  </tr>
  <tr>
    <td height="20">5.2 CUERPO DE LA MANDÍBULA</td>
  <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["1P"])){if($_REQUEST["1P"]=="P"){echo "PRESENTE"; }if($_REQUEST["1P"]=="A") { echo "AUSENTE"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["1C"])){if($_REQUEST["1C"]=="C"){echo "COMPLETO"; }if($_REQUEST["1C"]=="I") { echo "INCOMPLETO"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
          <?php if(isset($_REQUEST["1Ct"])){echo $_REQUEST["1Ct"]; }?>
    </span></td>
  </tr>
  <tr>
    <td height="20">5.3 RAMAS MANDIBULARES</td>
   <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["2P"])){if($_REQUEST["2P"]=="P"){echo "PRESENTE"; }if($_REQUEST["2P"]=="A") { echo "AUSENTE"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["2C"])){if($_REQUEST["2C"]=="C"){echo "COMPLETO"; }if($_REQUEST["2C"]=="I") { echo "INCOMPLETO"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
          <?php if(isset($_REQUEST["2Ct"])){echo $_REQUEST["2Ct"]; }?>
    </span></td>
  </tr>
  <tr>
    <td height="20">5.4 HUESO HIOIDES</td>
   <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["3P"])){if($_REQUEST["3P"]=="P"){echo "PRESENTE"; }if($_REQUEST["3P"]=="A") { echo "AUSENTE"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["3C"])){if($_REQUEST["3C"]=="C"){echo "COMPLETO"; }if($_REQUEST["3C"]=="I") { echo "INCOMPLETO"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
          <?php if(isset($_REQUEST["3Ct"])){echo $_REQUEST["3Ct"]; }?>
    </span></td>
  </tr>
  <tr>
    <td height="20">5.5 CLAVÍCULA IZQUIERDA</td>
   <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["4P"])){if($_REQUEST["4P"]=="P"){echo "PRESENTE"; }if($_REQUEST["4P"]=="A") { echo "AUSENTE"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["4C"])){if($_REQUEST["4C"]=="C"){echo "COMPLETO"; }if($_REQUEST["4C"]=="I") { echo "INCOMPLETO"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
          <?php if(isset($_REQUEST["4Ct"])){echo $_REQUEST["4Ct"]; }?>
    </span></td>
  </tr>
  <tr>
    <td height="20">5.6 CLAVÍCULA DERECHA</td>
   <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["5P"])){if($_REQUEST["5P"]=="P"){echo "PRESENTE"; }if($_REQUEST["5P"]=="A") { echo "AUSENTE"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["5C"])){if($_REQUEST["5C"]=="C"){echo "COMPLETO"; }if($_REQUEST["5C"]=="I") { echo "INCOMPLETO"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
          <?php if(isset($_REQUEST["5Ct"])){echo $_REQUEST["5Ct"]; }?>
    </span></td>
  </tr>
  <tr>
    <td height="20">5.7 ESCAPULA IZQUIERDA</td>
   <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["6P"])){if($_REQUEST["6P"]=="P"){echo "PRESENTE"; }if($_REQUEST["6P"]=="A") { echo "AUSENTE"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["6C"])){if($_REQUEST["6C"]=="C"){echo "COMPLETO"; }if($_REQUEST["6C"]=="I") { echo "INCOMPLETO"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
          <?php if(isset($_REQUEST["6Ct"])){echo $_REQUEST["6Ct"]; }?>
    </span></td>
  </tr>
  <tr>
    <td height="20">5.8 ESCAPULA DERECHA</td>
  <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["7P"])){if($_REQUEST["7P"]=="P"){echo "PRESENTE"; }if($_REQUEST["7P"]=="A") { echo "AUSENTE"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["7C"])){if($_REQUEST["7C"]=="C"){echo "COMPLETO"; }if($_REQUEST["7C"]=="I") { echo "INCOMPLETO"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
          <?php if(isset($_REQUEST["7Ct"])){echo $_REQUEST["7Ct"]; }?>
    </span></td>
  </tr>
  <tr>
    <td height="20">5.9 HUMERO IZQUIERDO</td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["8P"])){if($_REQUEST["8P"]=="P"){echo "PRESENTE"; }if($_REQUEST["8P"]=="A") { echo "AUSENTE"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["8C"])){if($_REQUEST["8C"]=="C"){echo "COMPLETO"; }if($_REQUEST["8C"]=="I") { echo "INCOMPLETO"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
          <?php if(isset($_REQUEST["8Ct"])){echo $_REQUEST["8Ct"]; }?>
    </span></td>
  </tr>  
  <tr>
    <td height="20">5.10 HUMERO DERECHO</td>
   <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["9P"])){if($_REQUEST["9P"]=="P"){echo "PRESENTE"; }if($_REQUEST["9P"]=="A") { echo "AUSENTE"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["9C"])){if($_REQUEST["9C"]=="C"){echo "COMPLETO"; }if($_REQUEST["9C"]=="I") { echo "INCOMPLETO"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
          <?php if(isset($_REQUEST["9Ct"])){echo $_REQUEST["9Ct"]; }?>
    </span></td>
  </tr>
  <tr>
    <td height="20">5.11 RADIO IZQUIERDO</td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["10P"])){if($_REQUEST["10P"]=="P"){echo "PRESENTE"; }if($_REQUEST["10P"]=="A") { echo "AUSENTE"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["10C"])){if($_REQUEST["10C"]=="C"){echo "COMPLETO"; }if($_REQUEST["10C"]=="I") { echo "INCOMPLETO"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
          <?php if(isset($_REQUEST["10Ct"])){echo $_REQUEST["10Ct"]; }?>
    </span></td>
  </tr>
  <tr>
    <td height="20">5.12 RADIO DERECHO</td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["11P"])){if($_REQUEST["11P"]=="P"){echo "PRESENTE"; }if($_REQUEST["11P"]=="A") { echo "AUSENTE"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["11C"])){if($_REQUEST["11C"]=="C"){echo "COMPLETO"; }if($_REQUEST["11C"]=="I") { echo "INCOMPLETO"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
          <?php if(isset($_REQUEST["11Ct"])){echo $_REQUEST["11Ct"]; }?>
    </span></td>
  </tr>

  <tr>
    <td height="20">5.13 CUBITO (ULNA IZQUIERDA)</td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["12P"])){if($_REQUEST["12P"]=="P"){echo "PRESENTE"; }if($_REQUEST["12P"]=="A") { echo "AUSENTE"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["12C"])){if($_REQUEST["12C"]=="C"){echo "COMPLETO"; }if($_REQUEST["12C"]=="I") { echo "INCOMPLETO"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
          <?php if(isset($_REQUEST["12Ct"])){echo $_REQUEST["12Ct"]; }?>
    </span></td>
  </tr>
  <tr>
    <td height="20">5.14 CUBITO (ULNA DERECHA)</td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["13P"])){if($_REQUEST["13P"]=="P"){echo "PRESENTE"; }if($_REQUEST["13P"]=="A") { echo "AUSENTE"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["13C"])){if($_REQUEST["13C"]=="C"){echo "COMPLETO"; }if($_REQUEST["13C"]=="I") { echo "INCOMPLETO"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
          <?php if(isset($_REQUEST["13Ct"])){echo $_REQUEST["13Ct"]; }?>
    </span></td>
  </tr>

  <tr>
    <td height="20">5.15 HUESOS DEL CARPO DERECHO</td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["14P"])){if($_REQUEST["14P"]=="P"){echo "PRESENTE"; }if($_REQUEST["14P"]=="A") { echo "AUSENTE"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["14C"])){if($_REQUEST["14C"]=="C"){echo "COMPLETO"; }if($_REQUEST["14C"]=="I") { echo "INCOMPLETO"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
          <?php if(isset($_REQUEST["14Ct"])){echo $_REQUEST["14Ct"]; }?>
    </span></td>
  </tr>
  <tr>
    <td height="20">5.16 HUESOS DEL CARPO IZQUIERDO</td>
   <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["15P"])){if($_REQUEST["15P"]=="P"){echo "PRESENTE"; }if($_REQUEST["15P"]=="A") { echo "AUSENTE"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["15C"])){if($_REQUEST["15C"]=="C"){echo "COMPLETO"; }if($_REQUEST["15C"]=="I") { echo "INCOMPLETO"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
          <?php if(isset($_REQUEST["15Ct"])){echo $_REQUEST["15Ct"]; }?>
    </span></td>
  </tr>
  <tr>
    <td height="20">5.17 HUESOS DEL METACARPO DERECHO</td>
   <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["16P"])){if($_REQUEST["16P"]=="P"){echo "PRESENTE"; }if($_REQUEST["16P"]=="A") { echo "AUSENTE"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["16C"])){if($_REQUEST["16C"]=="C"){echo "COMPLETO"; }if($_REQUEST["16C"]=="I") { echo "INCOMPLETO"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
          <?php if(isset($_REQUEST["16Ct"])){echo $_REQUEST["16Ct"]; }?>
    </span></td>
  </tr>
  <tr>
    <td height="20">5.18 HUESOS DEL METACARPO IZQUIERDO</td>
  <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["17P"])){if($_REQUEST["17P"]=="P"){echo "PRESENTE"; }if($_REQUEST["17P"]=="A") { echo "AUSENTE"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["17C"])){if($_REQUEST["17C"]=="C"){echo "COMPLETO"; }if($_REQUEST["17C"]=="I") { echo "INCOMPLETO"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
          <?php if(isset($_REQUEST["17Ct"])){echo $_REQUEST["17Ct"]; }?>
    </span></td>
  </tr>
  <tr>
    <td height="20">5.19 FALANGES DERECHA</td>
  <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["18P"])){if($_REQUEST["18P"]=="P"){echo "PRESENTE"; }if($_REQUEST["18P"]=="A") { echo "AUSENTE"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["18C"])){if($_REQUEST["18C"]=="C"){echo "COMPLETO"; }if($_REQUEST["18C"]=="I") { echo "INCOMPLETO"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
          <?php if(isset($_REQUEST["18Ct"])){echo $_REQUEST["18Ct"]; }?>
    </span></td>
  </tr>
  <tr>
    <td height="20">5.20 FALANGES IZQUIERDA</td>
   <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["19P"])){if($_REQUEST["19P"]=="P"){echo "PRESENTE"; }if($_REQUEST["19P"]=="A") { echo "AUSENTE"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["19C"])){if($_REQUEST["19C"]=="C"){echo "COMPLETO"; }if($_REQUEST["19C"]=="I") { echo "INCOMPLETO"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
          <?php if(isset($_REQUEST["19Ct"])){echo $_REQUEST["19Ct"]; }?>
    </span></td>
  </tr>
      
  <tr>
    <td height="20">5.21 ESTERNÓN</td>
  <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["20P"])){if($_REQUEST["20P"]=="P"){echo "PRESENTE"; }if($_REQUEST["20P"]=="A") { echo "AUSENTE"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["20C"])){if($_REQUEST["20C"]=="C"){echo "COMPLETO"; }if($_REQUEST["20C"]=="I") { echo "INCOMPLETO"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
          <?php if(isset($_REQUEST["20Ct"])){echo $_REQUEST["20Ct"]; }?>
    </span></td>
  </tr>
  <tr>
    <td height="20">5.22 COSTILLAS DERECHA</td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["21P"])){if($_REQUEST["21P"]=="P"){echo "PRESENTE"; }if($_REQUEST["21P"]=="A") { echo "AUSENTE"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["21C"])){if($_REQUEST["21C"]=="C"){echo "COMPLETO"; }if($_REQUEST["21C"]=="I") { echo "INCOMPLETO"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
          <?php if(isset($_REQUEST["21Ct"])){echo $_REQUEST["21Ct"]; }?>
    </span></td>
  </tr>
  <tr>
    <td height="20">5.23 COSTILLAS IZQUIERDA</td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["22P"])){if($_REQUEST["22P"]=="P"){echo "PRESENTE"; }if($_REQUEST["22P"]=="A") { echo "AUSENTE"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["22C"])){if($_REQUEST["22C"]=="C"){echo "COMPLETO"; }if($_REQUEST["22C"]=="I") { echo "INCOMPLETO"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
          <?php if(isset($_REQUEST["22Ct"])){echo $_REQUEST["22Ct"]; }?>
    </span></td>
  </tr>
  <tr>
    <td height="20">5.24 ATLAS (PRIMERA VERTEBRA)</td>
   <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["23P"])){if($_REQUEST["23P"]=="P"){echo "PRESENTE"; }if($_REQUEST["23P"]=="A") { echo "AUSENTE"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["23C"])){if($_REQUEST["23C"]=="C"){echo "COMPLETO"; }if($_REQUEST["23C"]=="I") { echo "INCOMPLETO"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
          <?php if(isset($_REQUEST["23Ct"])){echo $_REQUEST["23Ct"]; }?>
    </span></td>
  </tr>
  <tr>
    <td height="20">5.25 AXIS (SEGUNDA VERTEBRA)</td>
   <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["24P"])){if($_REQUEST["24P"]=="P"){echo "PRESENTE"; }if($_REQUEST["24P"]=="A") { echo "AUSENTE"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["24C"])){if($_REQUEST["24C"]=="C"){echo "COMPLETO"; }if($_REQUEST["24C"]=="I") { echo "INCOMPLETO"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
          <?php if(isset($_REQUEST["24Ct"])){echo $_REQUEST["24Ct"]; }?>
    </span></td>
  </tr>
  <tr>
    <td height="20">5.26 CERVICALES (3-7)</td>
  <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["25P"])){if($_REQUEST["25P"]=="P"){echo "PRESENTE"; }if($_REQUEST["25P"]=="A") { echo "AUSENTE"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["25C"])){if($_REQUEST["25C"]=="C"){echo "COMPLETO"; }if($_REQUEST["25C"]=="I") { echo "INCOMPLETO"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
          <?php if(isset($_REQUEST["25Ct"])){echo $_REQUEST["25Ct"]; }?>
    </span></td>
  </tr>
  <tr>
    <td height="20">5.27 TORÁCICAS (1-12)</td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["26P"])){if($_REQUEST["26P"]=="P"){echo "PRESENTE"; }if($_REQUEST["26P"]=="A") { echo "AUSENTE"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["26C"])){if($_REQUEST["26C"]=="C"){echo "COMPLETO"; }if($_REQUEST["26C"]=="I") { echo "INCOMPLETO"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
          <?php if(isset($_REQUEST["26Ct"])){echo $_REQUEST["26Ct"]; }?>
    </span></td>
  </tr>
  <tr>
    <td height="20">5.28 LUMBARES (1-5)</td>
   <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["27P"])){if($_REQUEST["27P"]=="P"){echo "PRESENTE"; }if($_REQUEST["27P"]=="A") { echo "AUSENTE"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["27C"])){if($_REQUEST["27C"]=="C"){echo "COMPLETO"; }if($_REQUEST["27C"]=="I") { echo "INCOMPLETO"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
          <?php if(isset($_REQUEST["27Ct"])){echo $_REQUEST["27Ct"]; }?>
    </span></td>
  </tr>
  <tr>
    <td height="20">5.29 SACRO</td>
   <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["28P"])){if($_REQUEST["28P"]=="P"){echo "PRESENTE"; }if($_REQUEST["28P"]=="A") { echo "AUSENTE"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["28C"])){if($_REQUEST["28C"]=="C"){echo "COMPLETO"; }if($_REQUEST["28C"]=="I") { echo "INCOMPLETO"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
          <?php if(isset($_REQUEST["28Ct"])){echo $_REQUEST["28Ct"]; }?>
    </span></td>
  </tr>
  <tr>
    <td height="20">5.30 ILIUM DERECHO</td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["29P"])){if($_REQUEST["29P"]=="P"){echo "PRESENTE"; }if($_REQUEST["29P"]=="A") { echo "AUSENTE"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["29C"])){if($_REQUEST["29C"]=="C"){echo "COMPLETO"; }if($_REQUEST["29C"]=="I") { echo "INCOMPLETO"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
          <?php if(isset($_REQUEST["29Ct"])){echo $_REQUEST["29Ct"]; }?>
    </span></td>
  </tr>
  <tr>
    <td height="20">5.31 ILIUM IZQUIERDO</td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["30P"])){if($_REQUEST["30P"]=="P"){echo "PRESENTE"; }if($_REQUEST["30P"]=="A") { echo "AUSENTE"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["30C"])){if($_REQUEST["30C"]=="C"){echo "COMPLETO"; }if($_REQUEST["30C"]=="I") { echo "INCOMPLETO"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
          <?php if(isset($_REQUEST["30Ct"])){echo $_REQUEST["30Ct"]; }?>
    </span></td>
  </tr>
  <tr>
       <td height="20">5.32 ISQUION DERECHO</td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["31P"])){if($_REQUEST["31P"]=="P"){echo "PRESENTE"; }if($_REQUEST["31P"]=="A") { echo "AUSENTE"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["31C"])){if($_REQUEST["31C"]=="C"){echo "COMPLETO"; }if($_REQUEST["31C"]=="I") { echo "INCOMPLETO"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
          <?php if(isset($_REQUEST["31Ct"])){echo $_REQUEST["31Ct"]; }?>
    </span></td>
  </tr>
  <tr>
    <td height="20">5.33 ISQUION IZQUIERDO</td>
  <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["32P"])){if($_REQUEST["32P"]=="P"){echo "PRESENTE"; }if($_REQUEST["32P"]=="A") { echo "AUSENTE"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["32C"])){if($_REQUEST["32C"]=="C"){echo "COMPLETO"; }if($_REQUEST["32C"]=="I") { echo "INCOMPLETO"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
          <?php if(isset($_REQUEST["32Ct"])){echo $_REQUEST["32Ct"]; }?>
    </span></td>
  </tr>
  <tr>
    <td height="20">5.34 PUBIS DERECHO</td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["33P"])){if($_REQUEST["33P"]=="P"){echo "PRESENTE"; }if($_REQUEST["33P"]=="A") { echo "AUSENTE"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["33C"])){if($_REQUEST["33C"]=="C"){echo "COMPLETO"; }if($_REQUEST["33C"]=="I") { echo "INCOMPLETO"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
          <?php if(isset($_REQUEST["33Ct"])){echo $_REQUEST["33Ct"]; }?>
    </span></td>
  </tr>
  <tr>
    <td height="20">5.35 PUBIS IZQUIERDO</td>
  <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["34P"])){if($_REQUEST["34P"]=="P"){echo "PRESENTE"; }if($_REQUEST["34P"]=="A") { echo "AUSENTE"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["34C"])){if($_REQUEST["34C"]=="C"){echo "COMPLETO"; }if($_REQUEST["34C"]=="I") { echo "INCOMPLETO"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
          <?php if(isset($_REQUEST["34Ct"])){echo $_REQUEST["34Ct"]; }?>
    </span></td>
  </tr>
  <tr>
    <td height="20">5.36 FEMUR IZQUIERDO</td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["35P"])){if($_REQUEST["35P"]=="P"){echo "PRESENTE"; }if($_REQUEST["35P"]=="A") { echo "AUSENTE"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["35C"])){if($_REQUEST["35C"]=="C"){echo "COMPLETO"; }if($_REQUEST["35C"]=="I") { echo "INCOMPLETO"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
          <?php if(isset($_REQUEST["35Ct"])){echo $_REQUEST["35Ct"]; }?>
    </span></td>
  </tr>
  <tr>
    <td height="20">5.37 FEMUR DERECHO</td>
   <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["36P"])){if($_REQUEST["36P"]=="P"){echo "PRESENTE"; }if($_REQUEST["36P"]=="A") { echo "AUSENTE"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["36C"])){if($_REQUEST["36C"]=="C"){echo "COMPLETO"; }if($_REQUEST["36C"]=="I") { echo "INCOMPLETO"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
          <?php if(isset($_REQUEST["36Ct"])){echo $_REQUEST["36Ct"]; }?>
    </span></td>
  </tr>
  <tr>
    <td height="20">5.38 ROTALA (PATELA IZQUIERDA)</td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["37P"])){if($_REQUEST["37P"]=="P"){echo "PRESENTE"; }if($_REQUEST["37P"]=="A") { echo "AUSENTE"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["37C"])){if($_REQUEST["37C"]=="C"){echo "COMPLETO"; }if($_REQUEST["37C"]=="I") { echo "INCOMPLETO"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
          <?php if(isset($_REQUEST["37Ct"])){echo $_REQUEST["37Ct"]; }?>
    </span></td>
  </tr>
  <tr>
    <td height="20">5.39 ROTALA (PATELA DERECHA)</td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["38P"])){if($_REQUEST["38P"]=="P"){echo "PRESENTE"; }if($_REQUEST["38P"]=="A") { echo "AUSENTE"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["38C"])){if($_REQUEST["38C"]=="C"){echo "COMPLETO"; }if($_REQUEST["38C"]=="I") { echo "INCOMPLETO"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
          <?php if(isset($_REQUEST["38Ct"])){echo $_REQUEST["38Ct"]; }?>
    </span></td>
  </tr>
  <tr>
    <td height="20">5.40 TIBIA IZQUIERDA</td>
   <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["39P"])){if($_REQUEST["39P"]=="P"){echo "PRESENTE"; }if($_REQUEST["39P"]=="A") { echo "AUSENTE"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["39C"])){if($_REQUEST["39C"]=="C"){echo "COMPLETO"; }if($_REQUEST["39C"]=="I") { echo "INCOMPLETO"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
          <?php if(isset($_REQUEST["39Ct"])){echo $_REQUEST["39Ct"]; }?>
    </span></td>
  </tr>
  <tr>
    <td height="20">5.41 TIBIA DERECHA</td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["40P"])){if($_REQUEST["40P"]=="P"){echo "PRESENTE"; }if($_REQUEST["40P"]=="A") { echo "AUSENTE"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["40C"])){if($_REQUEST["40C"]=="C"){echo "COMPLETO"; }if($_REQUEST["40C"]=="I") { echo "INCOMPLETO"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
          <?php if(isset($_REQUEST["40Ct"])){echo $_REQUEST["40Ct"]; }?>
    </span></td>
  </tr>
  <tr>
    <td height="20">5.42 PERONE (FÍBULA IZQUIERDA)</td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["41P"])){if($_REQUEST["41P"]=="P"){echo "PRESENTE"; }if($_REQUEST["41P"]=="A") { echo "AUSENTE"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["41C"])){if($_REQUEST["41C"]=="C"){echo "COMPLETO"; }if($_REQUEST["41C"]=="I") { echo "INCOMPLETO"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
          <?php if(isset($_REQUEST["41Ct"])){echo $_REQUEST["41Ct"]; }?>
    </span></td>
  </tr>
  <tr>
    <td height="20">5.43 PERONE (FÍBULA DERECHA)</td>
   <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["42P"])){if($_REQUEST["42P"]=="P"){echo "PRESENTE"; }if($_REQUEST["42P"]=="A") { echo "AUSENTE"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["42C"])){if($_REQUEST["42C"]=="C"){echo "COMPLETO"; }if($_REQUEST["42C"]=="I") { echo "INCOMPLETO"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
          <?php if(isset($_REQUEST["42Ct"])){echo $_REQUEST["42Ct"]; }?>
    </span></td>
  </tr>
  <tr>
    <td height="20">5.44 TARSO IZQUIERDO</td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["43P"])){if($_REQUEST["43P"]=="P"){echo "PRESENTE"; }if($_REQUEST["43P"]=="A") { echo "AUSENTE"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["43C"])){if($_REQUEST["43C"]=="C"){echo "COMPLETO"; }if($_REQUEST["43C"]=="I") { echo "INCOMPLETO"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
          <?php if(isset($_REQUEST["43Ct"])){echo $_REQUEST["43Ct"]; }?>
    </span></td>
  </tr>
  <tr>
    <td height="20">5.45 TARSO DERECHO</td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["44P"])){if($_REQUEST["44P"]=="P"){echo "PRESENTE"; }if($_REQUEST["44P"]=="A") { echo "AUSENTE"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["44C"])){if($_REQUEST["44C"]=="C"){echo "COMPLETO"; }if($_REQUEST["44C"]=="I") { echo "INCOMPLETO"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
          <?php if(isset($_REQUEST["44Ct"])){echo $_REQUEST["44Ct"]; }?>
    </span></td>
  </tr>
  <tr>
    <td height="20">5.46 METATARSO IZQUIERDO</td>
   <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["45P"])){if($_REQUEST["45P"]=="P"){echo "PRESENTE"; }if($_REQUEST["45P"]=="A") { echo "AUSENTE"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["45C"])){if($_REQUEST["45C"]=="C"){echo "COMPLETO"; }if($_REQUEST["45C"]=="I") { echo "INCOMPLETO"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
          <?php if(isset($_REQUEST["45Ct"])){echo $_REQUEST["45Ct"]; }?>
    </span></td>
  </tr>
  <tr>
    <td height="20">5.47 METATARSO DERECHO</td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["46P"])){if($_REQUEST["46P"]=="P"){echo "PRESENTE"; }if($_REQUEST["46P"]=="A") { echo "AUSENTE"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
           <?php if(isset($_REQUEST["46C"])){if($_REQUEST["46C"]=="C"){echo "COMPLETO"; }if($_REQUEST["46C"]=="I") { echo "INCOMPLETO"; }}?>
    </span></td>
    <td align="center" valign="bottom" ><span style="width:400px;">
          <?php if(isset($_REQUEST["46Ct"])){echo $_REQUEST["46Ct"]; }?>
    </span></td>
  </tr>
</table>

<br />
<table width="62%" border="1" align="center" cellpadding="10" cellspacing="0" bordercolor="#CCCCCC" style="border-width:1px; border-style:solid; border-color:#999; padding:5px">  <tr>

    <td colspan="2" bgcolor="#92cddc"><div class="txt_title" style="width:725px">6. MEDICION DE HUESOS LARGO(CM)</div></td>
  </tr>
  <tr>
    <td height="20">6.1 Humero Izquierdo:
      <div style="width:100px;">&nbsp;<?php if(isset($_REQUEST["0M"])){echo $_REQUEST["0M"];}?></div></td>
    <td >6.2 Humero Derecho:&nbsp;<?php if(isset($_REQUEST["1M"])){echo $_REQUEST["1M"];}?></td>
  </tr>
  <tr>
    <td height="20">6.3 Radio Izquierdo:&nbsp;<?php if(isset($_REQUEST["2M"])){echo $_REQUEST["2M"];}?></td>
    <td>6.4 Radio Derecho&nbsp;<?php if(isset($_REQUEST["3M"])){echo $_REQUEST["3M"];}?>:</td>
  </tr>
  <tr>
    <td height="20">6.5 Cubito/Ulna Izquierda:&nbsp;<?php if(isset($_REQUEST["4M"])){echo $_REQUEST["4M"];}?></td>
    <td>6.6 Cubito Ulna Derecha:&nbsp;<?php if(isset($_REQUEST["5M"])){echo $_REQUEST["5M"];}?></td>
  </tr>
  <tr>
    <td height="20">6.7 Femur Izquierdo:&nbsp;<?php if(isset($_REQUEST["6M"])){echo $_REQUEST["6M"];}?></td>
    <td>6.8 Femur Derecho:&nbsp;<?php if(isset($_REQUEST["7M"])){echo $_REQUEST["7M"];}?></td>
  </tr>
  <tr>
    <td height="20">6.9 Tibia Izquierda:&nbsp;<?php if(isset($_REQUEST["8M"])){echo $_REQUEST["8M"];}?></td>
    <td>6.10 Tibia Derecha:&nbsp;<?php if(isset($_REQUEST["9M"])){echo $_REQUEST["9M"];}?></td>
  </tr>
  <tr>
    <td height="20">6.11 Perone/Fibula Izquierda:&nbsp;<?php if(isset($_REQUEST["10M"])){echo $_REQUEST["10M"];}?></td>
    <td>6.12 Perone/Fibula Derecha:&nbsp;<?php if(isset($_REQUEST["11M"])){echo $_REQUEST["11M"];}?></td>
  </tr>
</table>
<br />
<table width="100%" align="center" bordercolor="#CCCCCC" style="border-width:1px; border-style:solid; border-color:#CCC; border-radius: 5px;">
  <tr>
    <td bgcolor="#92cddc" class="txt_title">7. DESCRIPCION DE ROPAS Y PERTENENCIAS</td>
  </tr>
  <tr>
    <td><div style="width:725px; line-height:20px; text-align:justify"><?php if(isset($_REQUEST["ropasPertenencias"])){echo $_REQUEST["ropasPertenencias"];}?></div></td>
  </tr>
</table>
<br />
<table width="100%" border="1" align="center" cellpadding="10" cellspacing="0" bordercolor="#CCCCCC">  <tr>
    <td colspan="3" bgcolor="#92cddc"><div class="txt_title" style="width:725px">8. DETERMINACION DE SEXO</div></td>
  </tr>
  <tr>
    <td rowspan="5">8.1 CRANEO</td>
    <td >8.1.1 Tamaño:</td>
    <td  valign="bottom"><div style="width:200px;">&nbsp;<?php if(isset($_REQUEST["craneoTamanio"])){echo $_REQUEST["craneoTamanio"];}?></div></td>
  </tr>
  <tr>
    <td>8.1.2 Eminencias Supraciliares:</td>
    <td  valign="bottom" ><div style="width:200px;">&nbsp;<?php if(isset($_REQUEST["craneoEminencias"])){echo $_REQUEST["craneoEminencias"];}?></div></td>
  </tr>
  <tr>
    <td>8.1.3 Glabela:</td>
    <td  valign="bottom" ><div style="width:200px;">&nbsp;<?php if(isset($_REQUEST["craneoGlabela"])){echo $_REQUEST["craneoGlabela"];}?></div></td>
  </tr>
  <tr>
    <td>8.1.4 Proceso Mastoides:</td>
    <td  valign="bottom" ><div style="width:200px;">&nbsp;<?php if(isset($_REQUEST["craneoProceso"])){echo $_REQUEST["craneoProceso"];}?></div></td>
  </tr>
  <tr>
    <td>8.1.5 Proceso Estiloide:</td>
    <td  valign="bottom" ><div style="width:200px;">&nbsp;<?php if(isset($_REQUEST["craneoEstiloide"])){echo $_REQUEST["craneoEstiloide"];}?></div></td>
  </tr>
  <tr>
    <td rowspan="2">8.2 MANDIBULA</td>
    <td>8.2.1 Angulo Mandibular:</td>
    <td valign="bottom" ><div style="width:200px;">&nbsp;<?php if(isset($_REQUEST["mandibulaAngulo"])){echo $_REQUEST["mandibulaAngulo"];}?></div></td>
  </tr>
  <tr>
    <td>8.2.2 Proceso Coronoides:</td>
    <td  valign="bottom" ><div style="width:200px;">&nbsp;<?php if(isset($_REQUEST["mandibulaProceso"])){echo $_REQUEST["mandibulaProceso"];}?></div></td>
  </tr>
  <tr>
    <td rowspan="3">8.3 PELVIS</td>
    <td>8.3.1 Hueso Pubis:</td>
    <td valign="bottom" ><div style="width:200px;">&nbsp;<?php if(isset($_REQUEST["pelvisHueso"])){echo $_REQUEST["pelvisHueso"];}?></div></td>
  </tr>
  <tr>
    <td>8.3.2 Foramen Obturación:</td>
    <td  valign="bottom" ><div style="width:200px;">&nbsp;<?php if(isset($_REQUEST["pelvisForamen"])){echo $_REQUEST["pelvisForamen"];}?></div></td>
  </tr>
  <tr>
    <td>8.3.3 Escotadura Clatica:</td>
    <td  valign="bottom" ><div style="width:200px;">&nbsp;<?php if(isset($_REQUEST["pelvisEscotadura"])){echo $_REQUEST["pelvisEscotadura"];}?></div></td>
  </tr>
  <tr>
      <td colspan="3">8.4 SEXO:<?php if(isset($_REQUEST["deterSexo"])){echo $_REQUEST["deterSexo"];}?></td>
  </tr>
  <tr>
    <td colspan="3">8.5 OBSERVACIONES</td>
  </tr>
  <tr>
   <td colspan="3"><div style="width:725px; line-height:20px; text-align:justify"><?php if(isset($_REQUEST["deterObservaciones"])){echo $_REQUEST["deterObservaciones"];}?></div></td>
  </tr>
</table>
  <br />
  <table width="100%" border="1" align="center" cellpadding="10" cellspacing="0" bordercolor="#CCCCCC" style="border-width:1px; border-style:solid; border-color:#CCC;">
  <tr>
    <td colspan="2" bgcolor="#92cddc" class="txt_title"><div style="width:725px">9. Determinacion de Raza:</div></td>
  </tr>
  <tr>
    <td>9.1 FORMA DE LA FRENTE:</td>
     <td valign="bottom" ><div style="width:480px">
          <?php if(isset($_REQUEST["razaFormaFrente"])){echo $_REQUEST["razaFormaFrente"];}?>
    </div></td>
  </tr>
  <tr>
    <td>9.2 ARCOS SUPRA ORBITARIO:</td>
    <td  valign="bottom" ><div style="width:480px">
          <?php if(isset($_REQUEST["razaSupra"])){echo $_REQUEST["razaSupra"];}?>
    </div></td>
  </tr>
  <tr>
  <td>9.3 MALARES:</td>
     <td valign="bottom" ><div style="width:480px">
          <?php if(isset($_REQUEST["razaMalares"])){echo $_REQUEST["razaMalares"];}?>
    </div></td>
  </tr>
  <tr>
  <td>9.4 ANGULO FACIAL:</td>
     <td valign="bottom" ><div style="width:480px">
          <?php if(isset($_REQUEST["razaAnguloFacial"])){echo $_REQUEST["razaAnguloFacial"];}?>
    </div></td>
  </tr>
  <tr>
  <td>9.5 PUENTE NASAL:</td>
     <td valign="bottom" ><div style="width:480px">
          <?php if(isset($_REQUEST["razaPuenteNasal"])){echo $_REQUEST["razaPuenteNasal"];}?>
    </div></td>
  </tr>
  <tr>
  <td>9.6 REGIÓN OCCIPITAL (PROMINENCIA):</td>
     <td valign="bottom" ><div style="width:480px">
          <?php if(isset($_REQUEST["razaProminencia"])){echo $_REQUEST["razaProminencia"];}?>
    </div></td>
  </tr>
  <tr>
  <td>9.7 SUTURAS CRANEALES:</td>
     <td valign="bottom" ><div style="width:480px">
          <?php if(isset($_REQUEST["razaSuturas"])){echo $_REQUEST["razaSuturas"];}?>
    </div></td>
  </tr>
  <tr>
  <td>9.8 PALADAR:</td>
     <td valign="bottom" ><div style="width:480px">
          <?php if(isset($_REQUEST["razaPaladar"])){echo $_REQUEST["razaPaladar"];}?>
    </div></td>
  </tr>
  <tr>
  <td>9.9 Raza:</td>
     <td valign="bottom" ><div style="width:480px">
          <?php if(isset($_REQUEST["razaDeterminacion"])){echo $_REQUEST["razaDeterminacion"];}?>
    </div></td>
  </tr>
</table>
<br />
<table width="100%" border="1" align="center" cellpadding="10" cellspacing="0" bordercolor="#CCCCCC" style="border-width:1px; border-style:solid; border-color:#CCC;">
  <tr>
    <td colspan="2" bgcolor="#92cddc" class="txt_title"><div style="width:725px">10. ESTIMACION DE EDAD:</div></td>
  </tr>
  <tr>
    <td>10.1 Fusion de Epifisis:</td>
     <td valign="bottom" ><div style="width:450px">
          <?php if(isset($_REQUEST["estimacionFusion"])){echo $_REQUEST["estimacionFusion"];}?>
    </div></td>
  </tr>
  <tr>
    <td>10.2 Erupcion de Terceros Molares:</td>
    <td  valign="bottom" ><div style="width:450px">
          <?php if(isset($_REQUEST["estimacionErupcion"])){echo $_REQUEST["estimacionErupcion"];}?>
    </div></td>
  </tr>
  <tr>
    <td>10.3 Suturas de Craneo:</td>
     <td valign="bottom" ><div style="width:450px">
          <?php if(isset($_REQUEST["estimacionSuturas"])){echo $_REQUEST["estimacionSuturas"];}?>
    </div></td>
  </tr>
 <tr>
    <td colspan="2">10.4 Observaciones:</td>
  </tr>
  <tr>
  <td colspan="2"><div style="width:725px; line-height:20px; text-align:justify"><?php if(isset($_REQUEST["estiObservaciones"])){echo $_REQUEST["estiObservaciones"];}?></div></td>
  </tr>
</table>
<br />
<table width="100%" border="1" align="center" cellpadding="10" cellspacing="0" bordercolor="#CCCCCC" style="border-width:1px; border-style:solid; border-color:#999; padding:5px">
  <tr>
    <td colspan="2" bgcolor="#92cddc" class="txt_title"><div style="width:725px">11. ESTIMACION DE TALLA (Segun Formula de Troter y Gleser)</div></td>
  </tr>
  <tr>
    <td>11.1 Hombre:</td>
    <td valign="bottom" ><div style="width:500px">
      <?php if(isset($_REQUEST["tallaHombre"])){echo $_REQUEST["tallaHombre"];}?>
    </div></td>
  </tr>
  <tr>
    <td>11.2 Mujer:</td>
    <td valign="bottom" ><div>
      <?php if(isset($_REQUEST["tallaMujer"])){echo $_REQUEST["tallaMujer"];}?>
    </div></td>
  </tr>
</table>
<br />
<table width="100%" align="center" bordercolor="#CCCCCC" style="border-width:1px; border-style:solid; border-color:#CCC; border-radius: 5px;">
  <tr>
    <td bgcolor="#92cddc" class="txt_title">12. EVIDENCIAS ASOCIADAS</td>
  </tr>
  <tr>
    <td><div style="width:725px; line-height:20px; text-align:justify"><?php if(isset($_REQUEST["evidenciasAsociadas"])){echo $_REQUEST["evidenciasAsociadas"];}?></div></td>
  </tr>
</table>
<br />
<table width="100%" align="center" bordercolor="#CCCCCC" style="border-width:1px; border-style:solid; border-color:#CCC; border-radius: 5px;">
  <tr>
    <td bgcolor="#92cddc" class="txt_title">13. ESTUDIO RADIOLÓGICO</td>
  </tr>
  <tr>
    <td><div style="width:725px; line-height:20px; text-align:justify"><?php if(isset($_REQUEST["estudioRadiologico"])){echo $_REQUEST["estudioRadiologico"];}?></div></td>
  </tr>
</table>
<br />
<table width="100%" align="center" bordercolor="#CCCCCC" style="border-width:1px; border-style:solid; border-color:#CCC; border-radius: 5px;">
  <tr>
    <td bgcolor="#92cddc" class="txt_title">14. ESTUDIO ODONTOLÓGICO</td>
  </tr>
  <tr>
    <td><div style="width:725px; line-height:20px; text-align:justify"><?php if(isset($_REQUEST["estudioOdontologico"])){echo $_REQUEST["estudioOdontologico"];}?></div></td>
  </tr>
</table>
<br />
<table width="100%" align="center" bordercolor="#CCCCCC" style="border-width:1px; border-style:solid; border-color:#CCC; border-radius: 5px;">
  <tr>
    <td bgcolor="#92cddc" class="txt_title">15. EVIDENCIA DE TRAUMA</td>
  </tr>
  <tr>
    <td><div style="width:725px; line-height:20px; text-align:justify"><?php if(isset($_REQUEST["evidenciaTrauma"])){echo $_REQUEST["evidenciaTrauma"];}?></div></td>
  </tr>
</table>
<br />
<table width="100%" align="center" bordercolor="#CCCCCC" style="border-width:1px; border-style:solid; border-color:#CCC; border-radius: 5px;">
  <tr>
    <td bgcolor="#92cddc" class="txt_title">16. Estudios Solicitados</td>
  </tr>
    <tr>
    <td>
        16.1 Estudio ADN:<br /><div style="width:725px; line-height:20px; text-align:justify">
    <?php if(isset($_REQUEST["estudioADN"])){
    if($_REQUEST["estudioADN"] != ""){
            echo $_REQUEST["estudioADN"];
    }
    }?></div>
    </td>
    </tr>
    <tr>
    <td>
        16.2 Estudio Dactiloscopia:<br /><div style="width:725px; line-height:20px; text-align:justify">
    <?php if(isset($_REQUEST["estudioDactiloscopia"])){
    if($_REQUEST["estudioDactiloscopia"] != ""){
            echo $_REQUEST["estudioDactiloscopia"];
    }
    }?></div>
    </td>
    </tr>
  <tr>
      <td>16.3 Otros:<br />
        <div style="width:725px; line-height:20px; text-align:justify"><?php if(isset($_REQUEST["estudioOtros"])){echo $_REQUEST["estudioOtros"];}?></div></td>
  </tr>
</table>
<br />
<table width="100%" align="center" bordercolor="#CCCCCC" style="border-width:1px; border-style:solid; border-color:#CCC; border-radius: 5px;">
  <tr>
    <td bgcolor="#92cddc" class="txt_title">17. SEÑAS PARTICULARES</td>
  </tr>
  <tr>
    <td><div style="width:725px; line-height:20px; text-align:justify"><?php if(isset($_REQUEST["seniasParticulares"])){echo $_REQUEST["seniasParticulares"];}?></div></td>
  </tr>
</table>
<br />
<table width="100%" align="center" bordercolor="#CCCCCC" style="border-width:1px; border-style:solid; border-color:#CCC; border-radius: 5px;">
  <tr>
    <td bgcolor="#92cddc" class="txt_title">18. CONCLUSIONES</td>
  </tr>
  <tr>
    <td><div style="width:725px; line-height:20px; text-align:justify"><?php if(isset($_REQUEST["conclusiones"])){echo $_REQUEST["conclusiones"];}?></div></td>
  </tr>
</table>
<br />
</page>
