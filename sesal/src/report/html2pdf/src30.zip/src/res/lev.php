<style type="text/Css">
<!--
#body{
	font-family:Arial, Helvetica, sans-serif;
	font-size:11px;
	font-weight:400;
	color:#000;
        Text-transform: uppercase;
}
.small_font{
	font-size:8px;
	color:#666;
}
.bg_img{
	background-color:#F5ECCE;
	border-radius:5px;
	height:20px;
}
.linea{
	border-width:1px;
	border-bottom:solid;
	border-color:#666;
}
.txt_title{
	font-size:16px;
	font-weight:bold;
}
.txt_titleheader{
	font-size:13px;
	font-weight:bold;
	color:#333;
}
.txt_titleheader_cotenido{
	font-size:10px;
}
-->
</style>
<page backtop="30mm" backimg="./res/img/logos/fondo.jpg" backbottom="30mm" backleft="6mm" backright="5mm" pagegroup="new" style=" font-size: 11px;">
<page_header>
<table width="100%" border="0" align="center" cellpadding="10" cellspacing="0">
  <tr>
    <td rowspan="2"><img src="./res/img/logos/mp.jpg" /></td>
    <td rowspan="2" align="center"><img src="./res/img/logos/logo_fondo_small.jpg" /></td>
    <td colspan="2" align="right" class="txt_titleheader">DIRECCIÓN GENERAL DE MEDICINA FORENSE<br/>DEPARTAMENTO DE PATOLOGÍA FORENSE<br/>
    HOJA DE TRABAJO DE  LEVANTAMIENTO CADAVÉRICO</td>
  </tr>
  <tr>
    <td>En revisión</td>
    <td align="right">PF-F116-1 V04 B08</td>
  </tr>
  <tr>
    <td colspan="4" valign="bottom" class="linea" height="10px"></td>
  </tr>
  <tr bgcolor="#E9E9E9">
    <td class="txt_titleheader_cotenido">Redactado por: L. Cruz, C. Martínez, E. López</td>
    <td align="right" class="txt_titleheader_cotenido" width="170">Editado por: T. Calidonio</td>
    <td align="right" class="txt_titleheader_cotenido">Revisado por: I. Raudales</td>
    <td align="right" class="txt_titleheader_cotenido">Aprobado por: J. Villanueva</td>
  </tr>
  <tr>
    <td colspan="4" align="right"><p style="margin-right:-20px">Página [[page_cu]] de [[page_nb]]</p></td>
  </tr>
</table>
</page_header>
<page_footer>
  <div><img src="./res/img/levantamiento/footer.jpg" ></div>  
</page_footer>
    <table width="100%" align="center" border="0" cellspacing="3" cellpadding="10">
  <tr>
    <td colspan="6" valign="middle" class="txt_title">1. DATOS DEL  LEVANTAMIENTO</td>
    </tr>
  <tr>
    <td>1.1 LEVANTAMIENTO Nº: </td>
    <td align="center" class="linea"><?php if(isset($_REQUEST["anio"])){echo $_REQUEST["anio"];}?></td>
    <td align="center" class="linea"><?php if(isset($_REQUEST["sede"])){echo $_REQUEST["sede"];}?></td>
    <td align="center" class="linea"><?php if(isset($_REQUEST["dep"])){echo $_REQUEST["dep"];}?></td>
    <td colspan="2" align="center" class="linea"><?php if(isset($_REQUEST["correlativo"])){echo $_REQUEST["correlativo"];}?></td>
    </tr>
  <tr>
    <td>&nbsp;</td>
    <td align="center" valign="top"><strong class="small_font">AÑO</strong></td>
    <td align="center" valign="top"><strong class="small_font">SEDE</strong></td>
    <td align="center" valign="top"><strong class="small_font">CÓDIGO DE DEPARTAMENTO,<br />SECCIÓN O UNIDAD  PERICIAL</strong></td>
    <td colspan="2" align="center" valign="top"><strong class="small_font">CORRELATIVO</strong></td>
    </tr>
  <tr>
    <td colspan="2">1.2 REPORTADO POR:<div style="width:245px" class="linea">
     &nbsp;<?php if(isset($_REQUEST["reportadopor"])){echo $_REQUEST["reportadopor"];}?>
    </div></td>
    <td align="right">HORA:</td>
    <td align="center" class="linea"><?php if(isset($_REQUEST["horareporte"])){echo $_REQUEST["horareporte"];}?></td>
    <td align="right">Fecha:</td>
    <td align="center" class="linea"><?php if(isset($_REQUEST["fechareporte"])){echo $_REQUEST["fechareporte"];}?></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td align="center" valign="top"><strong class="small_font">SISTEMA  DE 24 HORA</strong></td>
    <td>&nbsp;</td>
    <td align="center" valign="top" class="small_font">DD/MM/AAAA</td>
  </tr>
  <tr>
    <td>1.3. FECHA DE LEVANTAMIENTO:</td>
    <td colspan="3" align="center" class="linea"><?php if(isset($_REQUEST["fechalev"])){echo $_REQUEST["fechalev"];}?></td>
    <td align="right">HORA DE INICIO:</td>
    <td align="center" class="linea"><?php if(isset($_REQUEST["horalev"])){echo $_REQUEST["horalev"];}?></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td colspan="3" align="center" valign="top" class="small_font">DD/MM/AAAA</td>
    <td>&nbsp;</td>
    <td align="center" valign="top" class="small_font">SISTEMA DE 24 HORAS</td>
  </tr>
  <tr>
    <td colspan="6">1.4. AUTORIDAD FISCAL/JUEZ DE PAZ:<div style="width:400px" class="linea">&nbsp;
      <?php if(isset($_REQUEST["autoridadfiscal"])){echo $_REQUEST["autoridadfiscal"];}?>
    </div></td>
    </tr>
  <tr>
    <td colspan="3">1.5. INVESTIGADOR:<div style="width:200px" class="linea">&nbsp;
      <?php if(isset($_REQUEST["investigador"])){echo $_REQUEST["investigador"];}?>
    </div></td>
    <td align="right">TELF:</td>
    <td colspan="2" align="center" class="linea">&nbsp;<?php if(isset($_REQUEST["investigadortel"])){echo $_REQUEST["investigadortel"];}?></td>
    </tr>
  <tr>
    <td colspan="6">1.6. INSPECTOR OCULAR:<div style="width:480px" class="linea">&nbsp;
      <?php if(isset($_REQUEST["inspectorocular"])){echo $_REQUEST["inspectorocular"];}?>
    </div></td>
    </tr>
  <tr>
    <td colspan="6">1.7. MEDICO FORENSE:<div style="width:495px" class="linea">&nbsp;
      <?php if(isset($_REQUEST["medicoforence"])){echo $_REQUEST["medicoforence"];}?>
    </div></td>
    </tr>
  <tr>
    <td colspan="6">1.8. DACTILOSCOPISTA:<div style="width:490px" class="linea">&nbsp;
      <?php if(isset($_REQUEST["dactiloscopista"])){echo $_REQUEST["dactiloscopista"];}?>
    </div></td>
    </tr>
  <tr>
    <td colspan="6">1.9. AUXILIAR /RECEPTOR:<div style="width:475px" class="linea">&nbsp;
      <?php if(isset($_REQUEST["auxiliarreceptor"])){echo $_REQUEST["auxiliarreceptor"];}?>
    </div></td>
    </tr>
  <tr>
    <td colspan="6">1.10. MOTORISTA:<div style="width:525px" class="linea">&nbsp;
      <?php if(isset($_REQUEST["motorista"])){echo $_REQUEST["motorista"];}?>
    </div></td>
    </tr>
  <tr>
    <td colspan="2">1.11. LUGAR DEL LEVANTAMIENTO:</td>
    <td colspan="2" align="center" class="linea">&nbsp;<?php if(isset($_REQUEST["lugarlev_dep"])){echo $_REQUEST["lugarlev_dep"];}?></td>
    <td colspan="2" align="center" class="linea">&nbsp;<?php if(isset($_REQUEST["lugarlev_mun"])){echo $_REQUEST["lugarlev_mun"];}?></td>
    </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
    <td colspan="2" align="center" valign="top" class="small_font">DEPARTAMENTO</td>
    <td colspan="2" align="center" valign="top" class="small_font">MUNICIPIO</td>
    </tr>
  <tr>
    <td colspan="3" align="center" class="linea"><?php if(isset($_REQUEST["lugarlev_ciudad"])){echo $_REQUEST["lugarlev_ciudad"];}?></td>
    <td colspan="3" align="center" class="linea"><?php if(isset($_REQUEST["lugarlev_ba"])){echo $_REQUEST["lugarlev_ba"];}?></td>
    </tr>
  <tr class="small_font">
    <td colspan="3" align="center" valign="top"><strong>CIUDAD, PUEBLO, ALDEA, CASERIO</strong></td>
    <td colspan="3" align="center" valign="top"><strong>BARRIO, COLONIA</strong></td>
    </tr>
  <tr>
    <td colspan="6"></td>
    </tr>
  <tr>
    <td colspan="6" align="center" class="linea">&nbsp;
      <?php if(isset($_REQUEST["lugarlev_dir"])){echo $_REQUEST["lugarlev_dir"];}?>
    </td>
    </tr>
  <tr>
    <td colspan="6" align="center" valign="top"><strong class="small_font">DIRECCION  ESPECIFICA</strong></td>
  </tr>
  <tr>
    <td>1.12. FECHA DE MUERTE:</td>
    <td colspan="3" align="center" class="linea"><?php if(isset($_REQUEST["fecha_muerte"])){echo $_REQUEST["fecha_muerte"];}?></td>
    <td>HORA DE MUERTE:</td>
    <td align="center" class="linea"><?php if(isset($_REQUEST["hora_muerte"])){echo $_REQUEST["hora_muerte"];}?></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td colspan="3" align="center" valign="top" class="small_font">Fecha exacta(dd/mm/aaaa) o rango</td>
    <td>&nbsp;</td>
    <td align="center" valign="top" class="small_font">SISTEMA DE 24 HORAS</td>
  </tr>
  <tr>
    <td>1.13. COORDENADAS GPS</td>
    <td colspan="2" align="right">LATITUD:</td>
    <td class="linea"><?php if(isset($_REQUEST["latitud"])){echo $_REQUEST["latitud"];}?></td>
    <td align="right">LONGITUD:</td>
    <td class="linea"><?php if(isset($_REQUEST["longitud"])){echo $_REQUEST["longitud"];}?></td>
  </tr>
  <tr>
    <td colspan="6">EL LUGAR DONDE OCURRIO EL LEVANTAMIENTO ES EL  MISMO LUGAR DEL HECHO:<?php if(isset($_REQUEST["mismolugar"])){
		if($_REQUEST["mismolugar"]=="SI"){
			echo "SI";
		}else if($_REQUEST["mismolugar"]=="N"){
			echo "NO";
			}
		}?></td>
    </tr>
  <tr>
    <td>1.14. LUGAR DEL HECHO:</td>
    <td colspan="3" align="center" class="linea"><?php if(isset($_REQUEST["lugarhecho_dep"])){echo $_REQUEST["lugarhecho_dep"];}?></td>
    <td colspan="2" align="center" class="linea"><?php if(isset($_REQUEST["lugarhecho_mun"])){echo $_REQUEST["lugarhecho_mun"];}?></td>
    </tr>
  <tr>
    <td>&nbsp;</td>
    <td colspan="3" align="center" valign="top" class="small_font">DEPARTAMENTO</td>
    <td colspan="2" align="center" valign="top" class="small_font">MUNICIPIO</td>
    </tr>
  <tr>
    <td colspan="3" align="center" class="linea"><?php if(isset($_REQUEST["lugarhecho_ciudad"])){echo $_REQUEST["lugarhecho_ciudad"];}?></td>
    <td colspan="3" align="center" class="linea"><?php if(isset($_REQUEST["lugarhecho_ba"])){echo $_REQUEST["lugarhecho_ba"];}?></td>
    </tr>
  <tr class="small_font">
    <td colspan="3" align="center" valign="top"><strong>CIUDAD, PUEBLO, ALDEA, CASERIO</strong></td>
    <td colspan="3" align="center" valign="top"><strong>BARRIO, COLONIA</strong></td>
    </tr>
  <tr>
    <td colspan="6" align="center" class="linea">&nbsp;
      <?php if(isset($_REQUEST["lugarhecho_dir"])){echo $_REQUEST["lugarhecho_dir"];}?>
    </td>
    </tr>
  <tr>
    <td colspan="6" align="center" valign="top"><strong class="small_font">DIRECCION  ESPECIFICA</strong></td>
  </tr>
  <tr>
    <td>1.15. FECHA DEL HECHO:</td>
    <td colspan="3" align="center" class="linea"><?php if(isset($_REQUEST["fechahecho"])){echo $_REQUEST["fechahecho"];}?></td>
    <td>HORA DEL HECHO:</td>
    <td align="center" class="linea"><?php if(isset($_REQUEST["horahecho"])){echo $_REQUEST["horahecho"];}?></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td colspan="3" align="center" valign="top" class="small_font">DD/MM/AAAA</td>
    <td>&nbsp;</td>
    <td align="center" valign="top" class="small_font">SISTEMA DE 24 HORAS</td>
  </tr>
  <tr>
    <td colspan="6" valign="middle" class="txt_title">2. DATOS DEL  OCCISO/FALLECIDO</td>
    </tr>
  <tr>
    <td colspan="6">2.1. <div class="linea" style="width:450">&nbsp;
      <?php if(isset($_REQUEST["oestado"])){
		  if($_REQUEST["oestado"]=="C"){
		  	echo "CONOCIDO";
		  }else if($_REQUEST["oestado"]=="D"){
		  	echo "DESCONOCIDO";
		  }else if($_REQUEST["oestado"]=="S"){
		  	echo "SUPUESTO";
		 }
	} ?>
    </div></td>
    </tr>
  <tr>
    <td colspan="6">2.2. NOMBRE:<div style="width:395px" class="linea">&nbsp;
      <?php if(isset($_REQUEST["nombre"])){echo $_REQUEST["nombre"];}?>
    </div></td>
    </tr>
  <tr>
    <td colspan="6">2.3.TIPO DE IDENTIFICACION:<div style="width:310px" class="linea">&nbsp;
      <?php if(isset($_REQUEST["tipo_iden"])){echo $_REQUEST["tipo_iden"];}?>
    </div></td>
    </tr>
<?php if(isset($_REQUEST["tipo_iden_des"])  && $_REQUEST["tipo_iden_des"] != "") { ?>
 <tr>
    <td colspan="6">DESCRIPCION:<div style="width:388px" class="linea">&nbsp;
      <?php echo $_REQUEST["tipo_iden_des"];?>
    </div></td>
    </tr>
<?php }?>
<?php if(isset($_REQUEST["ovisual"]) && $_REQUEST["ovisual"] == "S") { ?>
 <tr>
    <td colspan="6">IDENTIFICACION VISUAL:<div style="width:332px" class="linea">&nbsp;
      <?php echo "SI";?>
    </div></td>
    </tr>
<?php }?>
<?php if(isset($_REQUEST["orelacion"]) && $_REQUEST["orelacion"] != "") { ?>
 <tr>
    <td colspan="6">RELACION CON EL OCCISO:<div style="width:330px" class="linea">&nbsp;
      <?php echo $_REQUEST["orelacion"];?>
    </div></td>
    </tr>
<?php }?>
  <tr>
    <td colspan="6">2.4. NUMERO  DE DOCUMENTO DE IDENTIFICACIÓN:<div style="width:190px" class="linea">&nbsp;
      <?php if(isset($_REQUEST["numdoc_iden"])){echo $_REQUEST["numdoc_iden"];}?>
    </div></td>
    </tr>
  <tr>
    <td colspan="6">2.5. FECHA  DE NACIMIENTO:<div style="width:200px" class="linea">&nbsp;
      <?php if(isset($_REQUEST["onacimiento"])){echo $_REQUEST["onacimiento"];}?>
    </div></td>
    </tr>
  <tr>
    <td>2.6. EDAD:<div style="width:150px" class="linea">&nbsp;
      <?php if(isset($_REQUEST["oedad"]) && $_REQUEST["oedad"] != 0){echo $_REQUEST["oedad"];}
	if(isset($_REQUEST["oedadrango"]) && $_REQUEST["oedadrango"] != 0){echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;RANGO ".$_REQUEST["oedadrango"];}	
	?>
    </div></td>
    <td colspan="2" align="right">2.7.  SEXO:</td>
    <td class="linea"><?php if(isset($_REQUEST["osexo"])){echo $_REQUEST["osexo"];}?></td>
    <td align="right">2.8.RAZA:</td>
    <td class="linea"><?php if(isset($_REQUEST["oraza"])){echo $_REQUEST["oraza"];}?></td>
    </tr>
  <tr>
    <td colspan="3">2.9. COMPLEXION:<div style="width:200px" class="linea">&nbsp;
      <?php if(isset($_REQUEST["ocomplexion"])){echo $_REQUEST["ocomplexion"];}?>
    </div></td>
    <td align="right">2.10.ESCOLARIDAD:</td>
    <td colspan="2" align="center" class="linea">&nbsp;<?php if(isset($_REQUEST["oescolaridad"])){echo $_REQUEST["oescolaridad"];}?></td>
    </tr>
  <tr>
    <td colspan="3">2.11. ESTADOCIVIL:<div style="width:195px" class="linea">&nbsp;
      <?php if(isset($_REQUEST["oestado_civil"])){echo $_REQUEST["oestado_civil"];}?>
    </div></td>
    <td align="right">2.12.OCUPACION:</td>
    <td colspan="2" align="center" class="linea"><?php if(isset($_REQUEST["oocupacion"])){echo $_REQUEST["oocupacion"];}?></td>
    </tr>
  <tr>
    <td colspan="6">2.13. NACIONALIDAD:<div style="width:185px" class="linea">&nbsp;
      <?php if(isset($_REQUEST["onacionalidad"])){echo $_REQUEST["onacionalidad"];}?>
    </div></td>
    </tr>
  <tr>
    <td>2.14. DOMICILIO:</td>
    <td colspan="3" align="center" class="linea"><?php if(isset($_REQUEST["odomicilio_dep"])){echo $_REQUEST["odomicilio_dep"];}?></td>
    <td colspan="2" align="center" class="linea"><?php if(isset($_REQUEST["odomicilio_mun"])){echo $_REQUEST["odomicilio_mun"];}?></td>
    </tr>
  <tr>
    <td>&nbsp;</td>
    <td colspan="3" align="center" valign="top" class="small_font">DEPARTAMENTO</td>
    <td colspan="2" align="center" valign="top" class="small_font">MUNICIPIO</td>
    </tr>
  <tr>
    <td colspan="3" align="center" class="linea"><?php if(isset($_REQUEST["odomicilio_ciudad"])){echo $_REQUEST["odomicilio_ciudad"];}?></td>
    <td colspan="3" align="center" class="linea"><?php if(isset($_REQUEST["odomicilio_barrio"])){echo $_REQUEST["odomicilio_barrio"];}?></td>
    </tr>
  <tr class="small_font">
    <td colspan="3" align="center" valign="top"><strong>CIUDAD, PUEBLO, ALDEA, CASERIO</strong></td>
    <td colspan="3" align="center" valign="top"><strong>BARRIO, COLONIA</strong></td>
    </tr>
  <tr>
    <td colspan="6" align="center" class="linea">&nbsp;
      <?php if(isset($_REQUEST["odomicilio_dir"])){echo $_REQUEST["odomicilio_dir"];}?>
    </td>
    </tr>
  <tr>
    <td colspan="6" align="center" valign="top"><strong class="small_font">DIRECCION  ESPECIFICA</strong></td>
  </tr>
  <tr>
    <td colspan="6" valign="middle" class="txt_title">3. HISTORIA MEDICO  LEGAL:</td>
    </tr>
  <tr>
    <td colspan="3">3.1.<div style="width:280px" class="linea">
      &nbsp;<?php if(isset($_REQUEST["tipo_muerte"])){
		  if($_REQUEST["tipo_muerte"]=="B"){
		  	echo "MUERTE BAJO CUSTODIA";
		  }else if($_REQUEST["M"]){
			  echo "MUERTE MATERNA";
		  }else if($_REQUEST["O"]){
			  echo " OTRO";
		  }
		  }?>
    </div></td>
    <td colspan="2" align="right">3.2. N° MUERTOS EN ESCENA:</td>
    <td align="center" class="linea"><?php if(isset($_REQUEST["numeros_muertos_escena"])){echo $_REQUEST["numeros_muertos_escena"];}?></td>
  </tr>
  </table>
  <p style="line-height:20px; text-align:justify;">
  <?php if(isset($_REQUEST["historia_medico"])){echo $_REQUEST["historia_medico"];}?>
  </p>
  <div class="txt_title">4. DESCRIPCION DE LA  ESCENA</div>
  4.1. TIPO DE ESCENA:<div class="linea" style="width:430px;">&nbsp;<?php if(isset($_REQUEST["tipo_escena"])){echo $_REQUEST["tipo_escena"];}?></div>
  <p style="line-height:20px; text-align:justify;">
      4.2. DESCRIPCION DE LA ESCENA:<br/>
  <?php if(isset($_REQUEST["descripciontipoescena"]) && $_REQUEST["descripciontipoescena"]!=""){
            echo $_REQUEST["descripciontipoescena"];
      }else{
          echo $_REQUEST["NO HAY DESCRIPCION"];  
      }?>
  </p>
  <p style="line-height:20px; text-align:justify;">
      4.3 POSICION DEL CUERPO:<br/>
  <?php if(isset($_REQUEST["posicioncuerpo"]) && $_REQUEST["posicioncuerpo"]!=""){
	  echo $_REQUEST["posicioncuerpo"];
   }else{
       echo $_REQUEST["NO HAY DESCRIPCION"];
  }?>
  </p>
  <table>
      <tr>
          <td>
              4.4. ZONA<div class="linea" style="width:500px;">&nbsp;<?php if(isset($_REQUEST["zona"])){echo $_REQUEST["zona"];}?></div>
          </td>
      </tr>
      <tr>
          <td>
              4.5. CLASE LUGAR DE LOS HECHOS:<div class="linea" style="width:355px;">&nbsp;<?php if(isset($_REQUEST["clase_lugar_hecho"])){echo $_REQUEST["clase_lugar_hecho"];}?></div>
          </td>
      </tr>
  </table><br/>
<div class="txt_title">5. PORTA ROPAS: <?php if(isset($_REQUEST["portaropa"])){
		  if($_REQUEST["portaropa"]=="S"){
		  	echo "SI";
		  }else if($_REQUEST["portaropa"]=="N"){
			echo "NO";
		}
		}?></div>
<p style="line-height:20px; text-align:justify;">
5.1. DESCRIPCION  DE LAS ROPAS<br />
  <?php if(isset($_REQUEST["descripcionropa"])){echo $_REQUEST["descripcionropa"];}?>
  </p>
<div class="txt_title">6. PORTA PERTENENCIAS: <?php if(isset($_REQUEST["portapertenencias"])){
		   if($_REQUEST["portapertenencias"]=="S"){
		  	echo "SI";
		  }else if($_REQUEST["portapertenencias"]=="N"){
			echo "NO";
		}
		}?></div>
 <br />6.1.DESCRIPCION DE  PERTENENCIAS:<br />
 <table width="100%" border="1" cellspacing="0" cellpadding="0" bordercolor="#CCCCCC" style="border-radius:5px;">
        <tr>
          <td><strong>ENTREGAS </strong></td>
          <td><strong>PERTENENCIAS</strong></td>
        </tr>
        <tr>
          <td><div style="width:300px">Entregadas  en la Escena   (a  Inspecciones Oculares o familiares con Visto Bueno del Fiscal)</div></td>
          <td><div style="width:420px; line-height:20px;  text-align:justify">
          <?php if(isset($_REQUEST["descripcionper_entregadas"]) && $_REQUEST["descripcionper_entregadas"]!=""){echo $_REQUEST["descripcionper_entregadas"];}else{echo "Ninguna";}?>
        </div></td>
        </tr>
        <tr>
          <td><div style="width:300px">No entregadas en la Escena (sin poderse extraer del cuerpo, se envían a  morgue con el cuerpo)</div></td>
          <td><div style="width:420px; line-height:20px; text-align:justify">
          <?php if(isset($_REQUEST["descripcionper_no_entregadas"]) && $_REQUEST["descripcionper_no_entregadas"]!=""){echo $_REQUEST["descripcionper_no_entregadas"];}else{echo "Ninguna";}?>
        </div></td>
        </tr>
      </table><br />
  <table width="100%" border="0" cellspacing="3" cellpadding="10">
  <tr class="txt_title">
  <td><div style="width:400px;">7. FENOMENOS  CADAVERICOS:</div></td>
  <td align="right">HORA DE EVALUACION FC:</td>
  <td align="center" class="linea"><?php if(isset($_REQUEST["horaevaluacionfc"])){echo $_REQUEST["horaevaluacionfc"];}?></td>
  </tr>
  <tr>
  <td></td>
  <td></td>
  <td align="center" valign="top"><strong class="small_font">SISTEMA DE 24 HORAS</strong></td>
  </tr>
  <tr>
    <td colspan="3">7.1. ESTADO DEL  CUERPO:
      <div style="width:348px" class="linea">&nbsp;<?php if(isset($_REQUEST["estado_cuerpo"])){echo $_REQUEST["estado_cuerpo"];}?></div></td>
    </tr>
  <tr>
    <td colspan="3">7.2. TEMPERATURA  CORPORAL:</td>
    </tr>
  <tr>
    <td colspan="3">7.2.1 CALOR CORPORAL:
      <div style="width:360px" class="linea">&nbsp;<?php if(isset($_REQUEST["calor_corporal"])){
		  if($_REQUEST["calor_corporal"]=="S"){
		  	echo "SI";
		  }else if($_REQUEST["calor_corporal"]=="N"){
			echo "NO";  
			  }
		  }?></div></td>
    </tr>
  <tr>
    <td colspan="3">7.2.2 ENFRIAMIENTOCADAVERICO:
      <div style="width:305px" class="linea">&nbsp;
        <?php if(isset($_REQUEST["enfriamiento_cadaverico"])){
		  if($_REQUEST["enfriamiento_cadaverico"]=="A"){
		  	echo "+";
		  }else if($_REQUEST["enfriamiento_cadaverico"]=="B"){
			  echo "++";
		   }else if($_REQUEST["enfriamiento_cadaverico"]=="C"){
		   	echo "+++";
	 		}
			}?>
    </div>
    </td>
    </tr>
  <tr>
    <td colspan="3">7.3. RIGIDEZ:
      <div style="width:422px" class="linea">&nbsp;
      <?php if(isset($_REQUEST["rigidez"])){
		  if($_REQUEST["rigidez"]=="A"){
		  	echo "AUSENTE";
	  	   }else if($_REQUEST["rigidez"]=="C"){
		  	echo "COMPLETA";
	  	   }else if($_REQUEST["rigidez"]=="I"){
		  	echo "INCOMPLETA ";
			if(isset($_REQUEST["rigidez_iuno"])){
				 if($_REQUEST["rigidez_iuno"]=="S"){
		  			echo "MUSC. MASETEROS";
	  	   		 }
				 if($_REQUEST["rigidez_idos"]=="S"){
		  			echo "; CUELLO";
	  	   		 }
				 if($_REQUEST["rigidez_itres"]=="S"){
		  			echo "; MUSC. SUPERIORES";
	  	   		 }
				 if($_REQUEST["rigidez_icuatro"]=="S"){
		  			echo "; MUSC. INFERIORES";
	  	   		 }

			}
	  	   } 
		}?>
  </div>
    </td>
    </tr>
  <tr>
    <td colspan="3">7.4.1. LIVIDECES:
      <div style="width:399px" class="linea">&nbsp;
      <?php if(isset($_REQUEST["livideces"])){
		  if($_REQUEST["livideces"]=="S"){
			echo "SI".", ";
			if(isset($_REQUEST["livideces_des"]) && $_REQUEST["livideces_des"] != ""){
			echo $_REQUEST["livideces_des"];
		         }else{
			echo "NO HAY DESCRIPCION";
			}
		   }else if($_REQUEST["livideces"]=="N"){
			echo "NO";	  
		   }
		  }?>
    </div>
    </td>
    </tr>
  <tr>
    <td colspan="3">7.4.2. MODIFICABLES:
      <div style="width:374px" class="linea">&nbsp;
      <?php if(isset($_REQUEST["modificables"])){
		  if($_REQUEST["modificables"]=="S"){
		  	echo "SI";
		  }else if($_REQUEST["modificables"]=="N"){
		  	echo "NO";
		  }
		  }?></div>
    </td>
    </tr>
  <tr>
    <td colspan="3">7.5.1. SIGNO SOMMER:
      <div style="width:369px" class="linea">&nbsp;
      <?php if(isset($_REQUEST["signosommer"])){
		  if($_REQUEST["signosommer"]=="S"){
		  		echo "SI";
	  		}else if($_REQUEST["signosommer"]=="N"){
		  		echo "NO";
	  		}
		  }?></div></td>
    </tr>
  <tr>
    <td colspan="3">7.5.2. SIGNO STENON LOUIS:
      <div style="width:336px" class="linea">&nbsp;
      <?php if(isset($_REQUEST["signostenon"])){
		  if($_REQUEST["signostenon"]=="S"){
		 	 echo "SI";
		  }else if($_REQUEST["signostenon"]=="N"){
			echo "NO";  
			}
		  }?></div>
    </td>
    </tr>
  <tr>
    <td colspan="3">7.6. ESPASMO CADAVERICO:
      <div style="width:337px" class="linea">&nbsp;
      <?php if(isset($_REQUEST["espasmocadaverico"])){
		  if($_REQUEST["espasmocadaverico"]=="S"){
		  	echo "SI";
		  }else if($_REQUEST["espasmocadaverico"]=="N"){
		  	echo "NO";
		  }
		  }?>
    </div>
    </td>
    </tr>
  <tr>
    <td colspan="3">7.7. INTERVALO POST MORTEM:
      <div style="width:320px" class="linea">&nbsp;
      <?php if(isset($_REQUEST["intervalopostmortem"])){echo $_REQUEST["intervalopostmortem"];}?></div></td>
    </tr>
  </table>
  <p style="line-height:20px; text-align:justify;">
  <div class="txt_title">8. ALTERACIONES:</div>
  <?php if(isset($_REQUEST["alteraciones"])){echo $_REQUEST["alteraciones"];}?>
  </p>
  <p style="line-height:20px; text-align:justify;">
  <div class="txt_title">9. EVIDENCIA  EXTERNA DE TRAUMA:</div>
  <?php if(isset($_REQUEST["evidencia_trauma"])){echo $_REQUEST["evidencia_trauma"];}?>
  </p><br />
  <table width="100%" border="0" cellspacing="3" cellpadding="10">
  <tr class="txt_title">
  <td colspan="3"><div style="width:400px;">10. MUERTE EN HOSPITAL</div></td>
  </tr>
  <tr>
    <td colspan="3">10.1. N° DENUNCIA POR MALA PRAXIS:<div style="width:285px" class="linea">&nbsp;
      <?php if(isset($_REQUEST["num_denumcia_praxis"])){echo $_REQUEST["num_denumcia_praxis"];}?>
    </div></td>
    </tr>
  <tr>
    <td colspan="3">10.2. EXPEDIENTE HOSPITALARIO:<div style="width:305px" class="linea">&nbsp;
      <?php if(isset($_REQUEST["expediente_hospitalario"])){
		  if($_REQUEST["expediente_hospitalario"]=="O"){
		  	echo "ORIGINAL";
		  }else if($_REQUEST["expediente_hospitalario"]=="C"){
		  	echo "COPIA";
		  }
	}?></div></td>
    </tr>
  <tr>
    <td colspan="3">10.3. EPICRISIS:
      <div style="width:405px" class="linea">&nbsp;
      <?php if(isset($_REQUEST["epicrisis"])){
		   if($_REQUEST["epicrisis"]=="O"){
		  	echo "ORIGINAL";
		  }else if($_REQUEST["epicrisis"]=="C"){
		  	echo "COPIA";
		  }
		 }?></div></td>
    </tr>
  <tr>
    <td colspan="3">10.4. HOSPITAL:<div style="width:405px;" class="linea">&nbsp;
      <?php if(isset($_REQUEST["m_hospital"])){echo $_REQUEST["m_hospital"];}?>
    </div></td>
    </tr>
  <tr>
    <td>10.5. SERVICIO:<div style="width:132px;" class="linea">
      &nbsp;<?php if(isset($_REQUEST["m_servicio"])){echo $_REQUEST["m_servicio"];}?>
    </div></td>
    <td>Nº  DE EXPEDIENTE:
      <div class="linea" style="width:100px">&nbsp;<?php if(isset($_REQUEST["m_num_expediente"])){echo $_REQUEST["m_num_expediente"];}?></div></td>
    <td>Nº  DE FOLIOS:
      <div class="linea" style="width:100px">&nbsp;<?php if(isset($_REQUEST["m_folio"])){echo $_REQUEST["m_folio"];}?></div></td>
    </tr>
  </table>
  <br />
  <table width="100%" border="0" cellspacing="3" cellpadding="10">
  <tr class="txt_title">
  <td>11. DATOS DE LA MUERTE</td>
  </tr>
  <tr>
   <td>11.1. CAUSA DE MUERTE PRELIMINAR:<div style="width:285px" class="linea">&nbsp;
      <?php if(isset($_REQUEST["causa_muerte_preliminar"])){echo $_REQUEST["causa_muerte_preliminar"];}?></div></td>
  </tr>
  <tr>
    <td>11.2. MANERA DE MUERTE PRELIMINAR:<div style="width:278px" class="linea">&nbsp;
      <?php if(isset($_REQUEST["manera_muerte_preliminar"])){echo $_REQUEST["manera_muerte_preliminar"];}?></div></td>
    </tr>
  <tr>
    <td>11.3.INSTRUMENTO O MECANISMO UTILIZADO:<div style="width:240px" class="linea">&nbsp;
      <?php if(isset($_REQUEST["inst_utilizado"])){echo $_REQUEST["inst_utilizado"];}?></div></td>
    </tr>
  </table><br />
  <table width="100%" border="0" cellspacing="3" cellpadding="10">
  <tr class="txt_title">
  <td>12. DESTINO DEL  CADAVER: <?php if(isset($_REQUEST["destino_cadaver"])){echo $_REQUEST["destino_cadaver"];}?></td>
  </tr>
 <tr>
    <td>ENTREGA  EN ESCENA AUTORIZADA POR:<div style="width:390px" class="linea">&nbsp;
      <?php if(isset($_REQUEST["entrega_autorizadapor"])){echo $_REQUEST["entrega_autorizadapor"];}?>
    </div></td>
    </tr>
  <tr>
    <td>CUERPO ENTREGADO EN  LA ESCENA:<div style="width:410px" class="linea">&nbsp;
      <?php if(isset($_REQUEST["entregado_ecena"])){
      if($_REQUEST["entregado_ecena"]=="3"){
        echo "SI";
      }else if($_REQUEST["entregado_ecena"]!="3"){
        echo "NO";
      }
      }?></div></td>
    </tr>
  </table>
  <?php if(isset($_REQUEST["entregado_ecena"]) && $_REQUEST["entregado_ecena"]=="3"){?>
      <table width="100%" cellspacing="0" cellpadding="0" style="border-width:1px; border-radius:5px; border-style:solid; border-color:#CCC;">
      <tr>
        <td><p>CAUSA DE MUERTE:</p></td>
        </tr>
      <tr>
        <td><p>PARTE I</p></td>
        </tr>
      <tr>
        <td class="linea">A)<div style="width:700px; line-height:20px; text-align:justify">
          <?php if(isset($_REQUEST["causa_a"])){echo $_REQUEST["causa_a"];}?>
        </div></td>
        </tr>
      <tr>
        <td class="linea">B)<div style="width:700px; line-height:20px; text-align:justify">
          <?php if(isset($_REQUEST["causa_b"])){echo $_REQUEST["causa_b"];}?>
        </div></td>
        </tr>
      <tr>
        <td class="linea">C)<div style="width:700px; line-height:20px; text-align:justify">
          <?php if(isset($_REQUEST["causa_c"])){echo $_REQUEST["causa_c"];}?>
        </div></td>
        </tr>
      <tr>
        <td class="linea">D)<div style="width:700px; line-height:20px; text-align:justify">
          <?php if(isset($_REQUEST["causa_d"])){echo $_REQUEST["causa_d"];}?>
        </div></td>
        </tr>
      <tr>
        <td><p>PARTE II OTROS  ESTADOS PATOLÓGICOS SIGNIFICATIVOS QUE CONTRIBUYERON A LA MUERTE</p></td>
        </tr>
      <tr>
        <td class="linea"><div style="width:700px; line-height:20px; text-align:justify">
          <?php if(isset($_REQUEST["causa_partedos"])){echo $_REQUEST["causa_partedos"];}?>
        </div></td>
        </tr>
      <tr>
        <td>MANERA  DE MUERTE:<div style="width:700px; line-height:20px; text-align:justify">
          <?php if(isset($_REQUEST["causa_manera_muerte"])){echo $_REQUEST["causa_manera_muerte"];}?>
        </div></td>
        </tr>
    </table>
  <?php }?><br />
  <div class="txt_title">13. OBSERVACIONES:</div>
  <p style="line-height:20px; text-align:justify;">
  <?php if(isset($_REQUEST["observaciones"]) && $_REQUEST["observaciones"] != ""){echo $_REQUEST["observaciones"];}else{ echo "NINGUNA";}?>
  </p>
  <br /><div>
  <table width="100%" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td>FECHA  DE FINALIZACION DEL LEVANTAMIENTO:</td>
        <td align="center" class="linea">
          <?php if(isset($_REQUEST["fecha_finalizacion"])){echo $_REQUEST["fecha_finalizacion"];}?>
        </td>
      </tr>
      <tr>
        <td align="center" valign="top"><p>&nbsp;</p>
          </td>
        <td align="center" valign="top"><span class="small_font">DD/MM/AAAA</span></td>
      </tr>
      <tr>
        <td>HORA  DE FINALIZACION DEL LEVANTAMIENTO:</td>
        <td align="center" class="linea">
          <?php if(isset($_REQUEST["hora_finalizacion"])){echo $_REQUEST["hora_finalizacion"];}?>
        </td>
      </tr>
      <tr>
        <td align="center" valign="top">&nbsp;</td>
        <td align="center" valign="top"><strong class="small_font">SISTEMA DE 24 HORAS</strong></td>
      </tr>
    </table>
    </div>
</page>
